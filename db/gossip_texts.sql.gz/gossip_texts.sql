SET search_path TO world;
COPY gossip_texts (text_id, text) FROM stdin;
1	Greetings $N
2	Hey there, $N. How can I help you?
68	Greetings $N
197	Hey citizen! You look like a stout one. We guards are spread a little thin out here, and I could use you help...
328	Greetings $N
384	Greetings $N
401	Wildhammer dwarves might have fast steeds, but can those Aerie Peak gryphons stand the heat of The Great Forge?  I think not!
447	Valley of Trials will temper even the weakest into a warrior worthy to join the Horde. Those who cannot rise to its tests will be left to bake in the scorching desert sun.
759	Do you mock me while I am unable to defend myself, bound to this ball of iron?
760	One of the humans has the key to this infernal contraption. Eston I think they said his name was.
761	Get away from here, $c, or they'll put you in chains as well.
762	Marlgen... One of the jailors. He has the key to my bonds.
767	Stupid snow... Hey, you're, $n, aren't you? I've just received a message asking for you.
768	You've been summoned by Lago Blackwrench, warlock master of Ironforge. You'd do yourself well to report to him immediately. You'll find him in the Forlorn Cavern district of the city.
781	Tirth's not himself these days, and neither is his assistant.
900	You want to talk to Osborne then. No finer teacher of the stealth arts than him in Stormwind. Look for him over in Old Town.
943	Yes, I have seen the shaman you seek. Last I saw her, she was to the west of here. She hides in the hills above the Razormane tribe. If you're clever, you'll be able to find a path to her hut in the hills. It is not too far north of here. That path should allow you to find her without fighting through the quilboar.
1119	I've not seen finer armor made in many years $N. Not since I trained under Grumnus Steelshaper in the Great Forge. I bet he could teach ye things about makin armor that would spark yer interest.
1120	If ye want to find Grumnus, the first thing ye should do is head to Ironforge. Go to the very center of the city and look for the Great Forge, ye should find him there.
1121	That's some impressive skill ye have there $N. The blades and hammers ye make surpass even my own, hard as that is to admit. Only person I ever met with skill even greater is Borgus Steelhand, I bet he could teach ye a thing or three.
1122	Want to train with Borgus? Aye, I can tell ye where to find him. Head through the Square northwest of me forge, then take the western road. Ye'll find him in the second building on yer right.
1124	The Shattered Hand's influence dominates these lands. We are the veil which covers Kalimdor: The protectorates, the police, the judges, the jury, and ultimately, the executioners. We see all, we know all.$B$BYou have grown much in the time which you have spent in service of the Hand, $N. The time has come to send you into the field.$B$BAre you prepared to undertake your next mission?$B
1128	Nice form $N, I bet a full mug at Bruuk's Corner that the function is just as solid. Ye know, ye might want to talk to Myolor Sunderfury. He'll set ya straight.
1129	Course I can show ye where Myolor is. Right over there near the anvil of the Great Forge, that's where he does his work. Listen to his words well $g lad:lass;, Myolor is as skilled as they come.
1130	Ye have my approval $N, ye can forge blades better than any I've trained in years. If ye want to make a real weapon though, ye need to talk with Myolor Sunderfury. That Dwarf will set ya on the right path.
1131	So, off to see Myolor, eh? He's right o'er there... behind ye! Er, maybe in front of ye! Near the Great Anvil!
1136	$N, was it? That is a mighty fine piece of work ye have there. I'll take ye on, train ye how to make armor fit fer King Magni himself.
1138	About five months ago, the Venture Co.'s Stranglethorn division got their hands on a special poison from a shady merchant in Booty Bay named Crank Fizzlebub. Fizzlebub had apparently stolen the poison from Zanzil!$B$BYes, Zanzil the Outcast - the troll that was exiled from his own tribe due to the nature of his 'experiments' in necromancy.$B$BNaturally, once they had the poison, they proceeded to test it on each other. The results were disastrous.
1158	Grand Foreman Puzik Gallywix finally intervened, taking the surplus of poisons to his tower, here at the Sludge Fen, in order to study and research the unstable nature of the toxins. A decision was finally reached to share the secret of the poison with the Defias Brotherhood in exchange for a very large supply of a stable, usable poison.$B$BKlaven Mortwake of the Defias Brotherhood was tasked with the job of altering the chemical properties of Zanzil's mixture.
1159	Fast forward to the present: The resultant formula works, allowing for the creation of a more controlled drone, however, the drawback is that the inactive compound is extremely volatile.$B$BGallywix, everyone in this tower and everyone outside are infected with the poison. It's affecting our minds and our bodies. Our internal organs have become soft and extremely fragile. This is your chance, $N. I don't have the strength to carry on and I sense that soon I will become one of 'them.'
1160	The tower's defenses are at their weakest right now. The patrollers, sentries, lookouts, and even Gallywix himself are all infected and highly vulnerable to your special abilities and attacks.$B$BI want to see you enter that tower and when you exit, I want to see you covered in the blood of your enemies, the head of Grand Foreman Puzik Gallywix in your hands, and the last of that poison in your pack. Take what you recover to Shenthul. He'll know what to do... I hope.$b
1228	Greetings $N.
1569	Greetings $N.
1599	Now that's a piece of steel worth wearing. Form and function lad/lass, I am impressed. Only ever seen it's match once, a Master in the Great Forge named Grumnus Steelshaper. I bet he has learned a few things since then, could probably teach some to ye.
1600	Go to the Great Forge at the very center of Ironforge. He works there, alongside the other Masters of our kind.
1609	Travel to Orgrimmar, to the Valley of Honor. There she lives with her husband and two daughters. All of them are smiths of great skill, but the spirits tell me that she will best guide your learning.
1610	You guide the spirits in the steel to protect and defend with far more skill than I ever could. The student has surpassed the teacher and now I must send you to where your education may continue. $N, you must seek out Shayis Steelfury in Orgrimmar. She is the finest Armorsmith I have ever known, and she can teach you much.
1616	Go to Orgrimmar, you will find her and her brood in the Valley of Honor.
1617	Armor like the kind you make could stop even the sharpest axe. I'm impressed $N, that doesn't happen often. Seek out an Orc named Shayis Steelfury, she makes the best armor outside of that cursed Dwarven stronghold.
1620	Go to the Orc city of Orgrimmar, find him in the Valley of Honor at a shop called the Arms of Legend.
1621	These are good blades you make, $N. Cut a stone and still sharp enough to slit a throat. I have seen better though, an orc named Kelgrum Bloodaxe makes them, go and learn all he can teach you.
1633	Welcome back to the Great Forge, $N. Ye come to visit an old Dwarf or do ye think yer ready for the next step in yer training?
1634	Good steel $N. Grab a hammer and come over here, let me show you the secret to forging a legendary weapon.
1637	Back to learn more, $N? Come over here and show me you are ready.
1638	How are your travels, $N? $g Sumi and Tumi missed you, you should say hi after your lesson : I have heard tales of your adventures, sounds like you have been busy;. Now let's see what you've learned while you were away.
1655	The Matrix Punchograph Technologic Huerist-o-meter has detected your aptitude in engineering.  You may now choose from the following option(s):$b$b01000111 01101111 00100000 01100111 01101111 00100000 01100111 01101111 00100001 00100001
1656	Accessing...    Void -- engineer <skill_level == n3wb>     01000111 01100001 01101101 01100101 00100000 01001111 01110110 01100101 01110010    ACCESS DENIED!
1657	Data access granted.  Have a nice day!$b$b01001110 01100001 01110100 01100001 01101100 01101001 01100101 00100000 01010000 01101111 01110010 01110100 01101101 01100001 01101110 00100000 01010010 01101111 01100011 01101011 01110011
1673	Please, a moment, $N. Kindal is down below in the Grimtotem camp trying to free the faerie dragons from captivity. We were just lucky that help came along when it did. Who knows what those foul tauren would have done to them.
1874	You are well on your way, $N.  But you still have much to learn.  The southern Barrens may be where your next lesson is found.
1973	I give unto you cordial salutations, $r.  You've come far off the beaten path merely to speak to someone dwelling inside a cave.  I trust there is a reason for your strange, yet not unforeseen visit here.  Yes?
2034	Belgrom sent us here from Orgrimmar to aid him in an unwise Alliance, but if his gamble pays off, then it will be to the great benefit of all the Horde.$B$BToo many orcs have already perished because of his desire to please women, but he still commands us, and our honor dictates we make the best of this situation.
2114	Hm... yes, I do have a recipe you might find useful.  Let me teach you!
2174	Your skills in alchemy aren't yet high enough to benefit from my teachings.  Perhaps if you speak with me later...
2277	Thank you again for helping Hilary, $g mister : miss;!  When I grow up, I wanna be a hero just like you!
2293	Ahoy, $N! Not a pretty picture, is it?$B$BThe Horizon Scout at the bottom of the sea, my crew in shambles, and our cargo and passengers strewn about like so much debris that you'd think this was one of Stormwind's canals after a festival.$B$BAnd that's not where the trouble ends...
2368	Welcome to Camp Mojache, brave $C. How may I assist you this day?
2473	Get it over with you filthy $r.$B$B<Kharan lowers his head, exposing his stubby neck.>
2475	Do I look stupid to you, $r? I may as well sign her death warrant myself! Why should I trust you?$B
2476	<Kharan sighs.>$B$BI suppose... I suppose you are right.$B$BGor'shak told me that your Warchief has big plans. Plans that may change the way the Alliance and Horde interact. What do you know about this?
2604	You wish to learn the old craft?  You wish to smelt dark iron?$B$BAppease me, $r.  Show me a sacrifice and I will consider it!
2605	Your will is strong, and your intent is clear.$B$BPerhaps you are worthy...
2606	You have shown me your desire, and have payed with precious stone.  I will teach you...
2635	Thanks, $N! You're the hero of Ungoro Crater!
2724	Your knowledge is lacking.  Return to me when your skills in smelting have grown!
2726	The corruption of Felwood has trapped my spirit here... I may never rest...
2735	Hmm, I don't have any mithril casings. I'm all out. Is that all you need to get to fix A-Me? Oh, that would be fantastic!$B$BMithril casings aren't too hard to find back in civilization. Just ask any skilled engineer to make one for you. I think it takes a few bars of mithril, but if you could help me out, I'll make sure you're well rewarded!
2809	I have suffered, but now I can feel it slowly fading from me. I feel... free.
2818	I can get back to the Stronghold on my own -- I just need a hand getting the blazes out of this hive!$B$BWho... who are you?
2845	\\"Darnassae?\\"$B$BThe night elf druid looks at you expectantly, but it is clear you cannot verbally communicate with her.  Undaunted, she points to herself and smiles.  She points at you and smiles once more.  She finally motions several times down the path to the north.$B$BPerhaps she is indicating that there is a druid you can speak to further up the road?
2873	The large shrine was built many years ago by the night elves that once inhabited this land.$B$BWhat secrets could it hold?
2953	This songflower plant stands out as a rock in the sea of corruption that is Felwood.  Its petals have a powerful fragrance that bolsters your spirits and strengthens your resolve.
2955	This windblossom plant stands out as a beacon of light in the darkness that is Felwood.  Plump and juicy berries hang from the plant, ripe for the picking.
2956	This healthy whipper root plant stands as a polar opposite to the sickly taint of corruption that dominates Felwood.  Tender and healthy roots yield delicious tubers that lay on the ground next to the plant.
2957	This vibrant night dragon plant stands in stark contrast to the demonic taint that sunders Felwood.  Rare and luscious fruit, known as Night Dragon's Breath, hang heavily from the plant.
2981	Hail, $C. In my years I have seen many eager tauten who wish to prove their worth to the tribe. It should not be forgotten thet eagerness is no substitute for wisdom and experience.
2996	Give me the arcana and I shall craft the amalgamation, mortal.
3049	Speak with Regthar.  He is wise and can help you find what you seek.
3061	Do you prefer guns or bows?
3073	You'll have to give me a moment, $c, the naga are attacking us right now. I'll speak to you as soon as the attack is done!
3098	Look at these samples! What does it mean? What does it mean? I'm going to need time, time to look at all this information. And I'll need more information. Information I can't get... damn! Think, Laris, think!$B$BWhat are you going to do? What?!$B$BThere has to be a solution!
3100	No, not that I can tell. It seems to be mostly based on region. Some races have labled them slimes, some oozes. It seems to be preference mostly.$B$BEvery time I've encountered ooze, sludge, or slime they have basically been the same creatures. The differences seem to be based on their environment, which is why we need a pure sample.
3101	A pure sample would be one that's uncorrupted by unintentional influences. We need to find the creatures in the most basic, normal environment we can.$B$BThat means somewhere devoid of civilization or the effects of the dominant races of Azeroth. Someplace... untouched.
3102	It'll definitely not be anywhere in the Eastern Kingdoms, that's for sure.$B$BIt'll have to be somwhere on Kalimdor, but still far enough away from the Horde and other races. Someplace unaffected by the Sundering--that means no where near the Night elves' civilization either.$B$BI would guess it'd be someplace protected also... like a valley, or a crater. I don't know. I'm just guessing now. I'm sorry I couldn't help you more.
3297	May your skills in smelting dark iron serve you well, $N.  But do not let your knowledge corrupt you... as it corrupted us.
3298	Kar Aman, $N. You look to be a strong $c--you would do well to mind yourself in this area. Touching things you know nothing about, or showing disrespect to your elders is just cause for punishment.$B$BYou may not respect me or my companions, but you will learn to respect our power if you prove foolish enough.$B$BNow, enough with the pleasantries, was there something I can do for you?
3299	Ah, a fellow warlock who has proven $ghis:her; worth to some degree.$B$BI am pleased to meet your acquaintance. My name is Menara Voidrender... and not without just cause.$B$BYou seem powerful and well-learned enough that other tools... more powerful tools... would be welcome and not foolishly imparted. If this is true, then speak to me further. If not, well then, you know your way  back to the docks and off into the ocean.
3321	Dis ain't no game mon. Joo want to use da axe, joo got to say da line. Say it wif me???Say hello, to ma little friend.
3358	Ah, one of my favorite customers. You look to be of a warlock of some power, $N. I am pleased to meet you. If there is anything I can do for you, please, just ask.$B$BMy brother and I feel that it will be your kind who lead us into the next great era. One with such power... such control... it's only a matter of time before the Legion itself bends to your will.$B$BI am but a little envious.
3382	Da Cache of Mau'ari holds great secrets... The shards used ta make it are reflective, and you can use its shiny surface ta siphon power from other tings and den reflect it onto yourself.$B$BKeeping da charm in your inventory lets you collect e'ko, da spiritual power from the beasts you fight. Once you find e'ko, you bring it ta Mau'ari.
3396	Here for training eh? Just began my training meself, but I would be glad ta teach ye what I can.
3397	Ye learn fast $g lad : lass;, much faster than I can keep up with. If ye want ta continue yer training, I suggest ye see my teacher. His name's Rotgath, Rotgath Stonebeard and ye'll find him in Ironforge at The Great Forge.
3399	Ye've got a little skill on ye. Enough to learn ye a few things I wager. Let's see what I can teach ye, shall we?
3425	Ah am very surprised that one wit such a careless nature has gotten dis far...$B$BYah, you may have another charm, but Mau'ari is very displeased wit your actions!$B$BGo, now. 
3457	Sorry $g lad : lass;, ye aren't quite up to the challenge of learning from me. Go see my son Groum, it would make his day to get a new apprentice.
3458	Yer skill is not without merit, but I need to put one last test to ye before I take ye on.
3462	Hmm, your work is allright but it's nowhere near the quality I look for in a student. Go talk with Smith Argus in Goldshire, I'm sure he can teach you some basics. Then when you're done, come on back to me and I'll give you a little test to make sure you are ready.
3464	You do fine work, but it's a bit rough around the edges. Don't worry about it, it will come with practice. Speaking of which, how about we see what you've been working on?
3465	Now I'm the one who feels rough around the edges, I honestly don't think there's anything left I can teach you. But you know who can? Bengus Deepforge in Ironforge, now there's a dwarf that knows his steel. Go look him up in The Great Forge of Ironforge, see if he's up to having a new trainee under him.
3484	I can't say enough about yer work, truly amazing things that ye can do with a hammer and an anvil. Now, don't be tellin anyone that I suggested ye go find a goblin to teach ye but that's exactly what I'm gonna do. Brikk Keencraft is his name, and last I heard he was operating a shop down in Booty bay.
3495	You've become quite the hunter, $N! Not only have you proven your skills, you also bested Daryl, which gets you extra points in my book!$B$BYou're welcome here any time.
3522	Get that head and it's sure to give Daryl a fright. Not that he doesn't deserve it, the bloody arrogant bastard. But ha! I can't wait to see the look on his face when you show it to him.
3525	You're always welcome here, $N. Thanks for the laugh -- and don't worry about Daryl, he had one coming!
3540	Oh, ok!  Here you are, $N.  It's the least I can do for all the help you've given me.
3586	Listen to your elders, $N. If you are strong of will and dedicated, there is no power you cannot control.
3587	Not all Forsaken are driven by Sylvanas' will, $N. Some of us are driven by true power--power we earn for ourselves.
3589	It... is... not... the best... time, $N. I must concen... trate.
3591	The infernal is one of the most powerful demons a warlock could hope to have at $Ghis:her; side in battle. The creature is stong, well-armored, and delivers devastating blows upon any foe. If you were to choose to put the spirit of an infernal into your weapon, you would gain some of those benefits--greater health and regeneration and the like.$B$BIf you wish to know more about felhounds, then you should speak to Wytula across from me.
3592	The felhound... a vicious creature indeed. It is not as physically strong as an infernal, but a wise warlock knows that brute force is not always the answer--if it was, you would have chosen the path of a warrior instead, wouldn't you?$B$BThe felhound draws upon the mana of its foes, using that and its quickness to overcome enemies. Its strength comes from the arcane and using that arcane power for its own ends.$B$BIf you wish to know more about infernals, then you should speak to Magaz across from me.
3594	Have you spoken to either of my acolytes inside the tower yet, $N? We cannot complete your orb until you've done one of their tasks. Speak to them now, if you're ready.
3693	The title of this book reads with a handwritten flourish: Maureen Dalson's Diary.
3734	What have you got there, $N?$B$B<Malyfous points to the unfired plate gauntlets hanging out of your pack.>
3759	Bite your tongue, $r, lest I rip it from your skull case and use it as a horn warmer.
3760	What it is that I do, of course. I brood. I lament. I hate. I plot. When that cycle is complete, I brood again. What is it you want from me? I have much on my mind.
3761	You?$B$B<Lorax laughs.>$B$BThat is doubtful.$B$BI stand in these ruins and dream. Dream of the day that I catch that miserable thief, Goraluk Anvilcrack.$B$BWe had a deal, him and I. A deal that he broke. Betrayed.
3762	I would teach him how to demon forge in exchange for his soul. The soul of a Blackrock orc is worth very little but in these trying times, a soul, any soul, is better than none at all.
3763	He took the unforged rune covered breastplate, used in the making of the demon forged breastplate and ran away without making payment. A fool, I am not, however... the unforged chest piece is useless without knowledge or the recipe to apply said knowledge.$B$BI wonder... does he sit safely in his city of Blackrock Spire and attempt to create the item from the raw material? I know he dare not leave!
3804	Oh hi! My name's Sarah. What can I do for you?
3855	Presumed to exist. Only a greater chromatic dragonkin or dragon could possess such a carapace.
3856	Commonly found on the lesser chromatic flight: Whelps, broodlings, lesser wyrmkin.
3857	Legend claims that in places of extreme conflict, across what is now known as the Plaguelands; clean and holy springs may erupt from the ground. The water from those springs has been named 'Blood of Heroes,' by artisans and commonfolk alike - in honor of those that fell in the war against the Scourge.
3859	Used by the Barov family of the Scholomance as a mirror into the souls that they no longer possess. A valuable keepsake.
3868	Have you seen Watcher Backus? So brave...$B$BI think he's the toughest of all the Night Watch. I wonder if he even notices I'm around....
3938	Your skill in blacksmithing is exceptional, $N. The time has come to make a decision. There are two paths you may choose: The way of the weaponsmith or the art of the armorsmith.$B$BBe warned, when you have chosen to dedicate yourself to a path, there is no going back. The discipline each path requires leaves no room for hybrids.
4114	As you inspect the cage and the Night elf inside, you get an odd sense of deja vu. For some reason she does not make eye contact with you--it is almost as if you are not there to her.
4117	They don't realize that they're dead, $r. They are cursed to relive the last memory they had before the town was eaten alive from the inside out. Most of them, anyway. Some were less fortunate.$B$BYou thought the Scourge did this? The Scourge did not yet exist and if they had, we would have at least put up a damned fight.$B$BNo, this was the result of a plague that came out of Scholomance and ravaged the town. It was horrifying and devastating. None survived.$B$BNow leave me to my sorrows.
4258	Greetings $N.
4444	I be a messenger from the Eastern Kingdoms, $N. I be sent here to make sure da priests who travel here be given proper direction.
4697	Come, take a trip to the wonderful, gorgeous, tropical jungles of Stranglethorn. That's right, you too can be spending your time sunbathing by the crystal blue waters while I stand here in this unbearable heat with nothing to look at but my brother Frezza all day! Enjoy your trip!
4713	The Nightmare is finally over!  Darrowshire, forgive me!
4715	The spirit looks intently into your eyes and grasps your hand.  You feel a warmth shoot through your body, almost knocking you to your knees.$B$BAs the warmth passes, you feel the slight presence of an ursine spirit within your being... bolstering your resolve.
4732	Greetings $N
4776	The battle is over, and the people of Darrowshire are saved.
4777	The battle is over, and the people of Darrowshire are saved.$B$BThey are saved, $N, because of you.  You are truly a hero of Darrowshire.
4778	A darkness had fallen over my eyes, but you tore me from my unholy reverie.  You saved me, $N.$B$BAnd now I beg you... to forgive me.
4787	Thanks again, $n! I'm very pleased with what we found.$B$BGood luck to you!
4864	Let me train you in the ways of the hunter.
4915	If you're looking for a flight back to Thunder Bluff, then you should talk to my tauren counterpart, Bunthen Plainswind.
4917	If you're looking for a flight back to Rut'theran Village, then you should talk to my night elven counterpart, Silva Fil'naveth.
4977	The Shrine of Remulos is a sacred place for us in the Cenarion Circle here in Moonglade... so please conduct yourself in a manner befitting a visitor.$B$BA visitor who doesn't want my scimitar buried in them, that is.
5013	Good day, $gsir:ma'am;. I'd shake your hand, but as you see, I'm in the middle of something. May I be of assistance?
5014	You've made a good start, but you still have a great deal to learn, $N.
5029	I don't suppose you're here to talk about my lovely Kali. Fine, then. Potions it is. Anyone ever tell ye you've got a one-track mind?
5032	Put your back into it, $glad:lass;. Hard work and determination--that's the way! Don't let anyone tell you book learnin' is all ye need.
5035	Ready for another lesson? All right, then. First, relax. You gotta stay loose to stir a potion just right.
5036	You got questions, but they be too big for me to answer, $N. You be needin' to have words with the orc Yelmak in the Drag of Orgrimmar. He'll help you out.
5041	I must have broken hundreds of vials when I first began brewing potions. The glass was so fragile in my clumsy hands. I hope you are more cautious than I was.
5047	Very well. Cut another lump of flesh from one of these specimens. Let us test what you've learned so far, and we can progress from there.
5051	I'm sorry, $N, but I have no time to spend on novices. You want someone closer to your own skill level. Try the night elf Milla Fairancora, in the Craftsmen's Terrace of Darnassus.
5057	That's nice, $N. Go show whatever it is to Vosur over there. He'll answer any questions you have.
5060	Teaching is not a one-sided trade, $N. As I teach you, I learn more myself, and my understanding grows.
5075	I've got plenty of great recipes for you to take a look at, and at discounted prices, too!
5080	Can you not sense the anguish of the Earth Mother for her lost children, the undead? Speak quickly, $N. Every second costs me dearly. We must help them find their way back to her!
5081	I cannot in good conscience spend time training novices while our allies, the undead, are suffering so terribly. Please speak with Kray over there instead; he can help you for now.
5087	Don't waste my time. I have research projects older than you. Go talk to Doctor Martin Felben in the Apothecarium of the Undercity. He's a Forsaken who can probably manage to teach you the basics.
5088	Another student. Wonderful. This is why Lydon belongs to the Royal Society of Snobs and gets to do research, and I'm stuck being an instructor. If I win another teaching award, I'll never live it down!
5092	I'm not amused by your audacity in coming to me for training. Go through the archway and down the ramp to the southeast, and talk to Doctor Martin Felben. He is a Forsaken who can teach you the basics.
5111	How dare you ask me for training, maggot? What were you hoping for, you slack-jawed yokel, a lecture on the proper uses of silverleaf? Out! You're lucky I don't thrash you senseless for wasting my time.
5113	I would train ye if I could, but ye need the services of someone a bit more... what's the word? Brainy! Look for Trixie Quickswitch in Ironforge. Tell 'er Bronk sent ye!
5114	Lookin' to be an engineer, eh? Well, by Muradin, ye've come to the right place!
5116	Your current aptitude exceeds my instructional capabilities. You should enquire further with my fellow Gnome Trixie Quickswitch in Ironforge!
5117	I would be delighted to aid you in the commencement of your pursuit! Let me grab my spinner and we'll get started...
5122	Oh, you've got oodles of things to learn still. I would teach you everything if I could, but I'm still learning too! Why don't you talk to Trixie Quickswitch in Ironforge, she'll help you further your education!
5123	You want to train? With me? Fantastic! The only thing better than assembling bullets and explosive devices is to share that knowledge with someone else! Let's get started!
5126	This kind of work isn't for the faint of heart. I have an uncle who lost a hand! Poor old Stumpy... anyway, if you're still interested I might be able to show you a few things.
5129	Yeah, I'll show you a few things. We'll see how you do, maybe you'll surprise me!
5130	(Sniff, sniff) You smell that? Don't you just LOVE the smell of grease?
5131	I'm afraid you're out of my league, friend! You should go see Nogg in Orgrimmar, he'll take you to the next level!
5134	You know who can really show you some things? Nogg! You go find him in Orgrimmar.
5135	I know a few things. You want me to show you?
5137	You know who's really smart? Nogg! Smarter than me, even. You go tell Nogg Thund sent you! You can find him by the control panel over there.
5140	You are ready for greater things! See Franklin Lloyd, to my right. He will guide you from now on.
5141	Engineering will provide you with the skills and knowledge to dismantle your opponents! Let me show you how...
5143	You're working your way up??? higher than me, at this point! You should talk to Springspindle Fizzlegear in Ironforge! He'll show you more than I ever could!
5144	I can show you a few tricks... if you don't mind doing a little something first, that is.
5145	Hmm well, I can't help you quite yet! You have to learn the basics first. Why don't you go see Sprite Jumpsprocket in Stormwind!
5146	Fantastic! Aren't you the industrious one? Well, let's get started, shall we?
5149	Quid pro quo! I'll teach you what I know, but first I want you to perform a small task?
5150	You can learn from me in time, but not yet! Why don't you start out by talking to Sprite Jumpsprocket to my right here. You can check in with me after you've gotten your feet wet!
5155	Close, but no cigar! I'm afraid you'll have to talk to my sis, Jemma first. After she's gone over the basics with you, come see me and I'll show you the juicy stuff!
5158	You have earned the privilege of training with a higher instructor. Go see my pal Roxxik there.
5159	Every day is a test, and this day is no different. If you pass this test, I will share some of my knowledge...
5160	You have not yet earned the right to train with me. See Thund first, over by the table. Come back when he says you're ready!
5161	You have passed your test, well done! Your training may now continue.
5163	What do you think I could teach you? Roxxik would do a much better job. You can find him in Orgrimmar. Now be off!
5164	Let's see how competent you are, shall we? If you perform this task to my liking, I'll spend the time to teach you!
5165	This is a waste of time, mine and yours! Go see Graham Van Talen if you want to begin your instruction! He's standing to my left over there.
5170	The things I would teach you would turn your brain to jelly! Come back when you've learned sufficiently!
5173	I can't teach what I don't know! If only there was someone else who knew more than I do... wait, there is! Go see Buzzek Bracketswing in Gadgetzan!
5175	Nice try, but you'll need some more experience before training with me! Back to the trenches!
5176	Nice going! I knew I was right about you, no matter what those other people said. Ha! I'm kidding! Okay, on with your lessons.
5183	Hmm... well you seem capable enough. If you truly desire to learn, then nothing will stand in your way! I will guide you through your first steps on what I hope will be a long and fulfilling path.
5185	Ye're a fine enchanter indeed! Now it's time fer ye to move on. I want ye to talk to Gimble Thistlefuzz, upstairs. He's a bit of a character, but he'll steer ye in the right direction from here on out!
5188	Your skills are beyond my reach. It is time for you to face new challenges. Taladan will help you prepare. He is standing by the table there.
5189	I will teach you what I can. Each lesson is a gift from the Goddess herself. Use her gifts wisely, and you shall not falter.
5191	You have truly accelled in your knowledge of enchanting. There is much more to learn, if you are willing. Speak to Taladan, in the Craftsmen's Terrace in Darnassus.
5192	Open your mind, wanderer, and we shall begin.
5194	Eh, well you've made it this far... go see Lavinia Crowe by the other bookshelf there. If you don't mess things up with her, maybe you can learn some more.
5195	You don't look like much to me, but who knows, maybe there's an enchanter hidden in there somewhere!
5200	You come to wrong place. Talk to the expert Godan over there. You learn more from him.
5201	To die in battle is glorious! But, with what I teach you, maybe you not die so quickly, hm?
5203	What do I look like, the Grand Poobah of enchanters? Your skills require the guidance of an Artisan! Go find Kitta Firewind at the Tower of Azora.
5204	Great, let's get started... ha! Fooled you! Surely you didn't think it would be that simple. You'll need to prove your mettle just like everyone else!
5209	You seem confident. Surely you wouldn't mind a test of your skills?
5210	You are not ready. Speak to Betty Quinn, she's standing by the stairs over there. Return to me when you have achieved a higher enlightenment.
5214	You are an exceptional enchanter. Beyond my talents as a teacher, I fear. Seek out Kitta Firewind at the Tower of Azora. Only she can qualify as your instructor now.
5215	I believe you are up to this task, will you accept the challenge?
5216	You have not yet learned the basics, wanderer. Have you spoken to my assistant, Lalina Summermoon? Perhaps you should.
5218	If you are seeking a truly rewarding pursuit, then a life of enchanting is for you!
5219	I know many things, stranger, but your knowledge rivals my own. Enchanters who wish to hone their skills further are known to travel to the Tower of Azora, where an artisan named Kitta Firewind resides.
5220	Why don't we see just what you're capable of? If you complete the task I shall be happy to further your training!
5226	Surely Mot didn't send you to me? He knows better. You are not yet capable of understanding what I would teach you. See my son Mot, just outside there, and finish training with him.
5227	Ah, very good. I am satisfied that you are a worthy student. Now, your training with me may begin???
5230	Hmm, you scratch my back, I'll scratch yours. If you do what I ask, and do it well, maybe we can discuss your training.
5231	No, no, you'll need FAR more training before you're ready to learn from me! Go talk to that uptight dabbler Malcomb Wynn. He's the one buried in books over there.
5232	Well, I've seen better. But, you have potential, I won't deny it. Pay attention and you just might learn something!
5240	You may have what it takes. Let's find out!
5241	You are unfit to train with me, stranger. Spend some time with my assistant Jhag over there.
5242	Well done! You have that spark in your eye, I know it well, it's the same spark I had when I was but a pup! Now, let's see if I can't teach you something.
5244	You have nearly reached the pinnacle of your training. To become the greatest enchanter you can possibly be, you have one more instructor to seek out. Her name is Annora, and you may find her in Uldaman.
5246	You are eager, that is good. However, you are not yet ready to train with the likes of me.
5247	Your skills are truly becoming extraordinary. Now, let us continue your training...
5251	Train hard, train every day. And when you have perfected your skills, return to me.
5255	Your education is nearly complete. One final task is all that stands between you and the culmination of all your efforts.
5256	There are still lessons you must learn from others before my knowledge may be shared with you. Be diligent, and do not give up hope.
5258	Gosh, I'm sorry. I don't have anything new to teach you. How about you go talk to Simon Tanner in the Old Town section of Stormwind? He's a human with big muscles and dreamy red hair.
5259	How's it going? I love the smell of leather; don't you?
5264	My apologies, but you have already learned everything I know. The night elf Faldron could offer you further training, however. Look for him in the Craftsmen's Terrace of Darnassus.
5278	Oh, goody, something else to do while I wait! You're a real life-saver, $N!
5316	My teachings would be too advanced for you at this stage. If you wish to learn more of potions, speak with Tel'Athir here instead.
5318	Even I have my limitations! Go talk to Lavinia Crowe in Undercity if you wish to further your training.
5333	Well, I declare! It's a new student! I'll gladly teach you everything I know once you have a little more skill. Go talk to Gretta Finespindle over there, would you? She'll have you up to speed in no time.
5361	Training you further is beyond my abilities. Speak to Telonis in the Craftsmen's Terrace of Darnassus. He is always glad to help talented students.
5363	I only teach students who have already mastered the basics. You must seek out the night elf Darianna in the Craftsmen's Terrace of Darnassus. Her skills will be a perfect complement to yours.
5373	The waters of Westfall is where you must search, due west-northwest of where the Gold Coast Quarry meets with the shore.  An anchor shows where a boat has sunk beyond it, deep within the water.  The underwater pressure is fierce here; swimming too far will crush even the mightiest swimmer from fatigue.  $B$BLook for a natural formation to aid you, $N - a bubbly fissure is near here, offering deep-water swimmers a chance for renewed breath.$b
5374	In the Silverpine Forest along the edges of the North Tide's Run, a derelict boat rests on the shore.  Out to the west of this lies what you seek; swim too far and the ocean will crush you from fatigue.  It resides on the ocean floor in a lockbox, waiting for you to claim it.$B$BYou'll be hard pressed to survive a dive to such depths without aid, so take heart; a bubbly fissure offers renewed breath to divers seeking this half of the pendant.  Use it wisely.
5376	In the northeastern Barrens lies a pool of water sickened by pollution.  The locals call it the Sludge Fen; the Venture Company has turned the once crystal-blue waters into a mire of industrial byproducts and waste.  In the heart of this fen lies what you seek, $N.$B$BBe warned - the Venture Company does not tolerate trespassers, and they consider anyone who does not work for them as such.  You'll especially be a target as a protector of nature, something they vehemently oppose.
5394	You have advanced beyond my skill to teach you. Journey now to Aerie Peak in the Hinterlands and speak with the dwarf Drakk Stonehand. His work is magnificent, far better than my own.
5405	I love a good challenge; don't you? Aye, of course ye do. An' that's why you're about to do exactly what I say.
5406	I'm not here to teach babes fresh out of the cradle. Ye've nowhere near the amount of skill I require in my students. In fact, ye're a sad figure of a $glad:lass;, an' I'll thank ye not to stand there jibber-jabberin' at me.
5408	I only wish I had more students like you. Not many will venture so far into enemy territory. I salute your courage.
5414	I'm a simple man who knows a few things about tailoring, but you need more assistance than I can provide. I have heard of a Night Elf who is quite an accomplished tailor. He resides in Stormwind, in the Magic District.
5415	So you would like to learn a few things? I would be happy to get you started!
5418	Very well, let your journey of tailoring begin.
5420	It is time for you to journey to Darnassus and speak to Me'lynn. She will guide you from now on.
5421	I would be happy to take you under my wing. Let us begin.
5427	I will teach you what I can.
5429	You seek a higher knowledge. Tepa is blessed with such knowledge. She should be standing somewhere nearby...
5430	With the Earth Mother's blessing, we shall begin.
5439	You will not be disappointed, traveler. Tailoring is a joyous endeavor.
5441	At dis point you know as much as I do, mon. Maybe you go see Magar in Orgrimmar. He not be da happiest tailor around, but he help you anyway.
5442	Dat's da attitude! Grab a needle and thread and let's get jammin'!
5498	Are you here to help with the delivery? Miran's just about ready.
5501	This is a dangerous line of business!$B$BMiran just left with a delivery. He should be back in a few minutes.
5520	You are beyond my level of expertise. Georgio Bolero, the master of Duncan's Textiles around the corner could help you advance your skills.
5522	Speak with Lawrence Shneider at Duncan's Textiles around the corner to the left. He is adept at dealing with beginners.
5523	A fine display of worthiness. Your instruction may now continue.
5531	You need to learn from someone who knows more than I do. Go talk to Josef Gregorian in Undercity. Well, what are you still doing here?
5533	What? Why are you bothering me? Why, I bet you can't even create a high quality robe! Go talk to Snang and come back when you're worthy of my talents!
5535	They say a stitch in time saves... what, eleven? Ah, I can't remember. Stupid saying anyway.
5536	Not bad... for an amateur! Still, you know about as much as I do. If you wanna' learn more you're gonna' have to talk to Josef Gregorian in Undercity.
5539	Well well, not too bad. Maybe I CAN show you a few things...
5543	There are basics that must be learned. Trianna is standing nearby, speak with her and return to me later.
5544	You have done well, traveler. I am proud to call you my student!
5546	Your knowledge is great, traveler. You must learn from one who is wiser than I. Many tales have been told of the wisdom of Josef Gregorian. You may find him in Undercity.
5549	Expertly accomplished! Now, let us continue your education...
5552	My knowledge is limited, though I am still learning. It is time for you to move on, traveler. Find Josef Gregorian in Undercity and tell him you are ready.
5554	There are fundamental things you must learn before I can aid you. Speak to my apprentice, Vhan. He is kind and patient and will teach you what you need to know.
5555	You are truly a determined student. I will be happy to provide you with instruction!
5557	You have worked your way up, time to see the boss. Go to Josef and tell him you are ready.
5559	How can I share my secrets with a beginner? Try speaking with Victor Ward first.
5564	You'll need more training before I can share my knowledge with you, I'm afraid.
5565	Good! I can tell that my efforts will not be wasted!
5567	You require the instruction of a true master! Go to Daryl Stack in Tarren Mill and embrace your destiny!
5570	Good! I can tell that my efforts will not be wasted!
5574	I cannot help you until you have learned more of the essentials. Come back to me when you are ready.
5577	You're doing very well in the art of tailoring, I must admit. Now, let's see how good you REALLY are...
5578	Who sent you here? You're not ready for my instruction yet! You'll be told when you're ready.
5818	While nothing can change the past, time can heal all wounds. Thank you for showing me that it is possible, $N. I wish you well.
5822	Now, answer me this, $N:$BWhich creature became the Lich King before spreading the plague across Lordaeron?
5833	Yeah, you know a few things! If you wanna' learn more you're gonna' have to talk to Georgio Bolero in Stormwind.
5842	I'm sorry $g mon : sis;, but I won't be sellin' my raptors to someone who hasn't proven themselves to be exalted to the Darkspear tribe.  When ya make a stand and show yourself to be no less than exalted to us, then I'll make my raptors available to ya.
5843	You are not known to my people.  A kodo is a mighty steed, and it is the product of love and care by my people; such is not given onto strangers.  Until the elders of Thunder Bluff consider you to be exalted, I cannot offer you the sale of a kodo.
5853	Stay back! Children should not be here! Be gone, child!
5861	You need to be exalted with the humans of Stormwind before I will teach you a riding skill, $c.
5865	You need to be exalted with the trolls of the Darkspear tribe before I will teach you a riding skill, $c.
5879	I do not believe you possess the mental acuity to grasp the nature of portal magic.
5880	As a mage, you are one of a select group that can conjure a portal to transport you back to this very place.  I can teach you if you are ready.
5935	Missing US text
5939	You're shaping up nicely, $N. I've heard good things...
5940	Missing US text
5995	$N, this came for you this morning.
5996	Messengers from Ravenholdt delivered this letter to me this morning. It is addressed to you, $N.
6062	This monument is dedicated to all those who have fallen in the protection of Stormwind. Our people have weathered unbelievable hardships to retain their freedoms and to control their own destinies. It is here we remember every sacrifice our citizens have made during the first war that riddled our people.
6100	I have made contact, $N. It is Lokholar the Ice Lord. He has deemed our cause worthy - our earth bound sacrifice sufficient. He comes soon... prepare yourself.
6104	The pages of the journal seem to be filled with information about trades, buyers  and other miscellaneous business related events.
6107	The fleet is ready, $N. You must take this beacon and place it at the eastern crater of the central battlezone. Defend the beacon from attackers until the fleet is able to lock on to its coordinates!
6109	$N, it is good to see you.  Our war with the other elemental lords yet rages, but your efforts help ensure our victory.
6110	The fleet is ready, $N. You must take this beacon and place it at the western crater of the central battlezone. Defend the beacon from attackers until the fleet is able to lock on to its coordinates!
6134	$N, what are you waiting for?  Find Field Marshal Teravaine in the Field of Strife and give him the assault orders.  Once he gets the orders, he and his troops will charge into the Horde and take no prisoners!
6161	Speak with Hydraxis.
6162	Greetings, little one.  You have business with the Waterlords?
6163	Perhaps you will tell me of your deeds, $N.  I would be honored to know them.
6167	The All Seeing Eye must be recovered!
6173	We have been sent here from Darnassus to aid the Stormpike in their time of need.
6175	I have been lost in the Dream. I sense his lifeforce but my powers have not yet grown strong enough to make contact.
6176	Yes. $N. I have located the Forest Lord. We must redouble our efforts! More crystals are needed!
6177	The Forest Lord is aware of the destruction in this valley, $N. Soon we must make our way to the Circle of Calling. Prepare yourself!
6223	I cannot store any more supplies.  I have all I can handle!
6276	Ah, $N!  You're just the person I was hoping to see!  We have enough supplies to send a ground assault against the Horde!  Field Marshal Teravaine is waiting in the Field of Strife for orders...$B$BYou're a brave veteran who's proven himself time and again.  Do you want to deliver Teravaine the orders?
6284	$N!  Our supplies are dwindling and until we get more we can't launch large ground assaults into the Field of Strife!$B$BSpeak with the Stormpike Quartermaster.  He'll tell you what you can do to resupply our assault forces.
6315	Awaiting orders from my superiors!
6384	As the toxins lurking within Maraudon seeped into my mind, I began to lose my grip on reality. Worried that it would be used for evil, my dryad sisters secretly took the scepter from me, breaking it into two parts and hiding it within the caverns.$B$BSoon they fell victim to the madness as well, and the two parts of the scepter, left unguarded, came to be in the possession of Vyletongue, himself. The satyr entrusted one part to Noxxion, an evil elemental, and the other he still has to this day.
6385	Without knowledge of the incantations required to unite the two parts, Lord Vyletongue was unable to use the scepter. However, now that I am free of the curse of Vyletongue's corruption, I will be able to assist you, if you'd like to bring me the two parts -- both the head and the rod of the scepter.
6433	Hail, $N!  It is good you came to see me.  We are prepared to launch a ground assuault through the Field of Strife!  Once Warmaster Garrick gets his orders, he and his reavers will cut a swath through the Alliance!$B$BDo you want to deliver those orders, $N?  Garrick is waiting in the Field of Strife...
6435	It's good to have veterans like you in Alterac Valley, $N.  Our supplies are too low to launch a ground assault through Alterac Valley... speak with our quartermaster - he'll tell you how to increase our supply base.
6437	You!  $N!  What are you doing wandering around the village like this?  There are Alliance foes in Alterac!  We must drive them out!$B$BOur supplies are too low to launch a large ground assault, so speak with our quatermaster.  He'll tell you how you can increase our supply base.
6491	It is not yet your time. I shall aid your journey back to the realm of the living... for a price.
6555	You have completed Teronis' mission, and I appreciate all you have done, $N.
6658	Then listen well, $c.$B$BCan you feel the power radiating from me? Does your morale not swell? Aye, it is the same for the other side. To disrupt their defenses and thin out their troops will be no easy task, but it must be done! Victory will be ours!
6659	Six Lieutenants control the front line's defenses. They must be destroyed first and fast! We cannot risk one of their priests returning the fallen Lieutenants to life.$B$BShould all of the Lieutenants be killed in quick succession, the morale of the front lines will falter! It will be shattered! Their troops will run in fear, leaving the remaining soldiers without backup.
6718	We have a lot of supplies, but we still need a lot more in order to send a ground assault into the Field of Strife.
6719	$N, we have enough supplies to launch ground assaults into the Field of Strife.  If you want to send the orders, and your rank is high enough, then speak with Sergeant Yazra Bloodsnarl in Frostwolf Village.
6720	We have some supplies, but not many.  We'll need a lot more in order to send a ground assault into the Field of Strife.
6730	$N, we have enough supplies to launch ground assaults.  If your standing with the Stormpike Guard is high enough, then speak with Corporal Noreg Stormpike.
6731	We have a lot of excess supplies, but we still need more before we can send an assualt into the Field of Strife.
6732	We have excess supplies, but not many.  We'll need a lot more before we can send a ground assault into the Field of Strife.
6778	I almost have enough supplies to upgrade our troops.
6779	I almost have enough supplies to upgrade to veteran units.
6781	I have about half the supplies needed to upgrade to veteran units.
6783	I have about half the supplies needed to upgrade to champion units.
6791	I cannot store any more supplies.  I have all I can handle!
6794	Your skill exceeds mine, though  I've heard that Old Man Heming in Booty Bay has copies of The Bass and You.  That is sure to help you increase your skill.
6795	Please, please, please tell me you are here to get me out of these shackles.  There's got to be a key somewhere...$B$BAt the very least, maybe you can take out Guard Slip'kik.  I think I might be able to help you out!$B$BSee that broken trap over yonder?  The ogres are too stupid to figure out how to fix it.  Clearly, it needs a thorium widget and some frost oil.  If you fix it, I bet you could lure Slip'kik into it, and BLAMMO - trapped ogre guard!
6833	Tower Point holds the pass between the Field of Strife and the Horde territories to the south.$B$BIt is controlled by neither side.
6846	Both the Horde and Alliance captains have taken to the field.  Our Captain Balinda Stonehearth directs the Stormpike forces from the Stonehearth Outpost, and the enemy Captain Galvangar barks orders from within Iceblood Garrison.$B$BTo battle!
6851	Captain Galvangar has been slain!  Honor our fallen captain, and unleash yourself again the Alliance!
6854	The Stormpikes uncovered ancient artifacts within Alterac Valley, but the Frostwolf orcs don't take kindly to explorers.  If the dwarves have to fight for knowledge of their ancestors, then so be it!$B$BTo win this battle, defeat the orc, Drek'Thar, in Frostwolf Keep.  Fortune be with you, $c!
6875	You found a key?  Well, is it THE key?  I mean, is it the key to unlock these shackles?  Well $G sir : ma'am;, there is only one way to find out!
6883	Well, from what I've gathered while waiting to be eaten by these yokels... it might not be necessary to kill every ogre you find here.$B$BThe ogres were going on and on the other day about how King Gordok came to power; specifically, he killed the previous king and took his place.  Well, the king's henchmen - those that Gordok spared - immediately swore fealty to the new king.$B$BWho knows - the ogre you save could very well be your own... figuratively speaking, of course!
6913	What you doin' wanderin' around here?  Why them small fries not in da shackles?!
6915	Do I see them with weapons still?  Why you let them keep their weapons?!
6932	<You are well versed in the creation and function of this robot.>
6938	You honor us with your presence, my lord.
6954	<Demitrian falls to his knees.>$B$BYou have recovered my Master's eternal prison!$B$BOh long have I waited for this day and finally, it is realized.$B$BHe must be released!
6955	I hold the vessel of his rebirth. Should you be prepared to take on this task, you will be required to fortify the vessel and ultimately, break the hold of Ragnaros himself!
6956	The vessel of rebirth must be fortified with elementium. I know of only one source of the mineral: the elemental planes, at the core of our world.$B$BThere is one, an Earthshaper, who may know more than I about the acquisition of such things. You must find this Earthshaper!
6958	The corporeal form of Ragnaros must be destroyed. From the remnants, his essence shall emerge. In this weakened state, Ragnaros' grip on the prison of Thunderaan is loosed. The essence itself acting as a key...
6974	Bluegill Marsh north of Menethil Harbor in the Wetlands holds many locked boxes from the wrecks offshore that have washed ashore.
6975	The waters of northern Sar'theris Strand in Desolace or the Angor Fortress in Badlands have locked boxes that can be picked open.
6976	The Pool of Tears in the Swamp of Sorrows holds ancient locked boxes that were lost in another age.
6977	The Dark Iron dwarves of the Slag Pit in Searing Gorge have a great number of locked boxes.
6978	Both Lost Rigger Cove in Tanaris and the Bay of Storms in Azshara have boxes that can be picked to improve your skill.
6979	The Scarlet Crusade of Tyr's Hand in the Eastern Plaguelands have many lockboxes that will challenge your skill.
6981	Many locked supply boxes were lost when the Naga overran the Zoram Strand in Ashenvale.
6982	The Venture Company based around Windshear Crag in Stonetalon keeps their supplies in locked boxes.
6983	The Syndicate keeps many locked boxes of supplies in Durnholde Keep in Hillsbrad.
6996	So, you have found me. I suppose that you have come to learn of suppression and control.$B$BI will teach you much more than that... you will also learn of sacrifice.$B$B<Daio grins.>
6997	That will be the choice of the demon you wish to conjure and enslave. We wield dark powers and we pay grossly for the use of said powers.
6998	We must first craft a prison to confine the beast, if you wish to progress further.
7019	Wulan in Shadowprey Village can sell you the \\"Expert Cookbook\\".  You will need that if you are to better yourself.
7177	Ragefire Chasm consists of a network of volcanic caverns that lie below the orcs' new capital city of Orgrimmar. Recently, rumors have spread that a cult loyal to the demonic Shadow Council has taken up residence within the Chasm's fiery depths. This cult, known as the Burning Blade, threatens the very sovereignty of Durotar. Many believe that the orc Warchief, Thrall, is aware of the Blade's existence and has chosen not to destroy it in the hopes that its members might lead him straight to the Shadow Council. Either way, the dark powers emanating from Ragefire Chasm could undo all that the orcs have fought to attain.
7182	These papers are guarded.  Speak with Zamek to create a distraction!
7187	Once the greatest gold production center in the human lands, the Dead Mines are now inhabited by the Defias Brotherhood, who have turned the dark tunnels into their private sanctum. It is rumored that the thieves have conscripted the clever goblins to help them build something terrible at the bottom of the mines - but what that may be is still uncertain. Rumor has it that the way into the Deadmines lies through the quiet, unassuming village of Moonbrook.$b
7191	Ragefire Chasm can be found beneath the Shadow Cleft in the center of Orgrimmar.
7227	The Deadmines can be found beneath Moonbrook in the south of Westfall.
7248	If you wish to become a swordsmith, just ask.
7250	The theory behind it is that we completely destroy you with a massive explosion wherever you are and send those particles through a dimensional rip and then re-implode you at the maschine here. Instant Transport! It might not work ALL the time, but what kind of goblin engineer are you! If survival was your first priority you could never be a real Goblin Engineer! Here is the recipe you will need to make the Dimensional Ripper and try it out!
7252	Once you have built the device, you simply activate the device to be whisked away to lovely Gadgetzan!    Nearly everyone who has used the device has arrived on the pad here looking just the way they did when they began!    There have been some reported problems with transportees being replaced by their evil selves from an alternate universe, but I'm sure we will have that worked out soon...
7394	$N, it's good to see you again!  Are you having fun at the Faire?$B$BWant to arm wrestle?  No, of course not... you want to keep your arm!
7415	Greetings young $c. It is here that your Warchief challenged Orgrim Doomhammer! Although it happened so many years ago, it is an image still fresh in my mind.
7416	$966w, young $c.
7436	$964w, young $c.
7437	$962w Stormpike Commander(s) and $950w Stormpike Lieutenant(s).$b
7455	The strength of your resolve shines, $N. You continue to prove that you are an asset to our people. Someday the world will realize the extent of your great deeds.
7456	The burgeoning hero returns! It is good to see you again, $N. You are always welcome at our village.
7479	I'll patrol the pass leading up to Frostwolf Keep. Just give me the word and I'll take flight, Commander.
7495	There are several battlegrounds from which to choose.  To which battlemaster shall I send you?
7496	I know just the one that you speak of $c.  You must seek out Brogun Stoneshield on the Warrior's Terrace.
7497	Aye, and which battleground be ye looking for?
7498	Warsong Gulch you say?  Well then, you'll be wanting to speak with fair Lylandris over in the Hall of Arms.
7499	Which battleground are you interested in?
7500	Then it is Thelman Slatefist that you wish to speak to.  You can find him in the presence of the King at Stormwind Keep.
7501	Indeed, Silverwing Hold is in need of your assistance.  Speak with Elfarran in the audience chamber at Stormwind Keep.
7502	We must eliminate the elves and their cowardly Alliance from Warsong Gulch.  Go to the Hall of the Brave in the Valley of Honor and speak with Brakgul Deathbringer if you have what it takes to aid the Horde.
7503	Which battleground do you seek your glory in?
7504	And to which battleground do you wish to journey?
7505	Then it is to Taim Ragetotem that you must speak.  Seek him out on the Hunter Rise.
7506	Kergul Bloodaxe on the Hunter Rise stands ready to help you get to Warsong Gulch.
7507	What battleground you want?
7508	It cold there!  You go in Royal Quarter, talk to Grizzle Halfmane.
7509	Think him in Royal Quarter.  Kurden Bloodclaw is little orc.
7595	A friend of the Zandalrian! You have ventured deep into the lair of the Blood God, $c. You will do well to listen to what I have to say.$B$BMany thousands of years ago, while the indigenous trolls of the Zul'Aman empire were battling the invading high elf heathens, great magic was stolen from Zanza. This magic was used by the high elves to enchant their weapons and armor to assist in conquering the trolls of the region.
7635	The markings of this tablet show ancient diagrams and hold dire words of power, but their meaning is inscrutable to you.
7636	The markings on this tablet show ancient diagrams and dire words of power, used to create  Gurubashi Mojo Madness...
7639	Thanks again for returning my lucky measuring tape, $N.  I swear it helps me catch bigger fish!
7640	To catch Gahz'ranka, you'll need a special Mudskunk lure.  I make 'em myself!$B$BBut you need more than just the lure; you need some mudskunks too... you need to place them in the lure to give it a rank old smell!$B$BWhen you have the mudskunks, throw the lure off Pagle's Point in Zul'Gurub... and then grab a drink and wait... but not too long, because Gahz'ranka is sure to come a'stomping!
7645	Mudskunks are a particularly smelly breed of fish that likes tropical waters.  The Zulian Mudskunk - the smelliest of them all, can only be found in the steamy waters of Zul'Gurub.$B$BThe Zulian Mudskunks are what I believe attracted Gahz'ranka to the place, though trolls will probably tell you he's one of their gods...$B$BBelieve what you like, but mark me - fill one of my lures with Zulian Mudskunks and that old boy will come, for sure!
7669	Gri'lek, of the Iron Blood$B$BThe wanderer.  May his strength and lust for battle pierce the ages.$B$BGri'lek now lingers near the edge of madness...
7670	Hazza'rah, the Dreamweaver.$B$BHis is the power of nightmares, and may his foes ever sleep.  $B$BHazza'rah now dwells far from here.  One day, he may return...
7673	Renataki, of the Thousand Blades.$B$BPain is his lifeblood.  Fear, his ally.  May he one day return and bring joyous bloodshed with him.$B$BRenataki now dwells near the edge of madness.
7678	You are not yet powerful enough, $c.  Move along.
7680	I am so glad that you asked.  You will find Sir Malory Wheeler at the Royal Quarter in the presence of our Dark Lady.
7681	Of course, of course.  Please speak with Deze Snowbane at the Hall of the Brave in the Valley of Honor of this city, $c.
7685	Honor to your house and ancestors $c!  You will find Kartra Bloodsnarl inside the Hall of the Brave in the Valley of Honor.
7687	Very good $N.  You will find Grizzle Halfmane in the Royal Quarter of the Undercity.  May you find great honor in Alterac Valley.
7690	Then it is with great pride that I tell you that Brakgul Deathbringer stands ready in the Hall of Arms to aid you on your way to Warsong Gulch.  Seek him out in the Valley of Honor.
7691	You have chosen wisely $N.  Seek out Kergul Bloodaxe on the Hunter Rise.  He will assist you on your journey to Warsong Gulch.
7692	Honor and praise will be yours for the taking $c!  Look for Kurden Bloodclaw in this city's Royal Quarter.
7697	You've made the right decision $c.  You'll find our battlemaster, Glordrum Steelbeard, in the Hall of Arms.  Good luck $N!
7701	Thank you $N!  You will find Keras Wolfheart on the Warrior's Terrace near the trainers there.  He will guide your way to Arathi Basin.  Good luck and great honor upon thee.
7702	We shall be in your debt $c.  Look for Donal Osgood in the Hall of Arms.  He will be more than happy to aid you in your journey to Arathi Basin.
7703	Excellent!  You shall be doing the League of Arathor a great service in ridding Arathi Basin of The Defilers and their Horde thugs.  Seek out the Lady Hoteshem in the royal audience chamber of Stormwind Keep.  She has been expecting you $N.
7706	The Light of Elune shine upon thee $N!  You will find Aethalas, our battlemaster, on the Warrior's Terrace.  She will aid you on your way to Warsong Gulch.
7708	You show wisdom beyond your years $c.  Thank you.  You can find our battlemaster, Lylandris, standing at the war table in the Hall of Arms.  She can assist you in traveling to Warsong Gulch.
7709	The Silverwing Sentinels shall be in your debt $c.  You will find Elfarran, our battlemaster, inside Stormwind Keep, attending the boy-king's audience.  Goddess watch over you!
7749	How dare you commune with a Duke of the Council, worm!
7773	A clear voice rises from within the stone...$B$BYou come to us with title and so we will listen, but do not try our patience, $c.  The council has no time for idle gossip from one such as you.
7774	A thunderous voice bellows from the stone...$B$BGreetings, commander. What news of Silithus do you bring the Lords of the Council?
7775	Missing US text.
7776	A thunderous voice bellows from the stone...$B$BWhat is this?  I sense a little cultist scurrying about!  Run along, vermin, or face the wrath of the lords of the Council!
7780	Hail $c. Didn't I see you recently at an exclusive gathering? You look familiar, but then again this city is a busy place.$B$BIf you attended that convention, then surely you were given a secret code. Tell me your code and I will give you a special prize in return.
7781	$N!  I hope you're ready to get to work, because there is much for you to do here on Sunstrider Isle.$B$BEver since the destruction of the Sunwell by Arthas and the Scourge, we have been a race adrift on a sea of uncertainty.  We teeter on the edge of oblivion.  This will change, $c, and you will learn and aid our recovery at the same time.$B$BThe Outland awaits us!
7783	The ghostly figure looks at you with mistrust in her eyes and remains silent.
7784	The Sunspire held a beautiful vantage of the Sunwell... once.  Our lives have been turned upside down, $N, but we nonetheless carry on.  It is our way; we are survivors.$B$BIf you are to survive this upheaval... to carry on in your own right, then you MUST learn how to survive.  All blood elves must do this.  You must master your insatiable hungering for magic before it masters you.
7785	Your continued service to the Blood Elves is paramount to our survival!  We must all pitch in and pull ourselves out of the mire we all find ourselves in.$B$BIf you're ready to work, then let's get started.
7786	Knowledge is power - TRUE power, my young friend.  You'll be wise to acquire as much of it as you can, and pay proper heed to those who have already done so.$B$BBefore the razing of the Sunwell, we fooled ourselves into thinking we had neared the apex of our civilization.  It took the Scourge to bring us to our knees... and in a way, back to reality.
7787	You've caught me at a critical time in my research!  No worries, you're welcome to join me in quiet contemplation... emphasis on \\"quiet\\", if you don't mind though.
7788	If you're heading toward the city, then I have something important for you to do!
7800	Greetings, $N.
7825	You see large cavernous tunnels and corridors reflected inside the crystal. You recognize the area as the Molten Core.
7827	Greetings, $r. Wonderful day to be alive, is it not?
7828	Not all Tauren despise your kind, $r. Alas, I am forbidden to offer you my services.
7855	Alas $N, I am much too busy to talk.  As I mentioned, I need time to think on the situation at hand.$B$BI wish you luck in your travels.  Good day.
7869	$N, it is good to see you again.$B$BRemember to stay focused on your learning.  You represent our future, and should you falter our future will be dark indeed.
7872	Welcome to the Falconwing Square Inn. May I prepare a meal for you, or ready a room?
7882	There is more to magic than just arcane gesticulations... but I am speaking to someone who already knows this, yes?$B$BYou've come to me to learn, and learn you will... just so long as you pay attention and do as I say.  The secrets of the demons do not cater to fools, and neither do I.
7898	I said GOOD DAY!
7903	Your path does not match mine. You must seek training elsewhere, $c.
7904	You seek further instruction in the manipulation of the naaru's power, $n?
7998	The buzz around here is that we've collected everything that we need. Now it all comes down to the Horde gathering up their stuff. Once they have we can all ship our goods over to Silithus and the war can begin.
8007	As expected, the Horde has completed all of their preparations well in advance of you and your so-called Alliance. You are all holding us up as we cannot take final measures to begin the war until you finish your promised responsibilities.$B$BNow go and pull your weight, $r.
8085	Have you heard the good news, $c? The Alliance has completed all of its war effort collections! Now we simply await the Horde to finish theirs. When they do, we'll begin shipping all of the war materiel over to Silithus, and it shouldn't be long after that until the Ahn'Qiraj War begins.
8175	Elder Bellowrage watches over the Dark Portal from a ridge in the Blasted Lands.
8226	Long have we toiled to see our land returned to its former glory, $c. Ever shall we remain vigilant against those who have invaded and defiled Quel'thalas. We will not rest until they are driven from our sight.$B$BLet none exist who stand in the way of the sin'dorei!
8227	It's all a mess, $c, and it's all my fault! I was warned to get out of dock while there was still time, but did I listen? No.$B$BWhat am I going to do now? Those sickly blood elves, the Wretched, have made off with my magical goods, and ate them I think. I'm pretty sure that means they can't be retrieved. And the Grimscale murlocs pirated away the rest of my goods in the dead of night! Furthermore, to kick an honest merchant when she's down, my crew abandoned ship!$B$BI think I'm going to cry.
8228	Hello, $c. These are troubling times indeed if this is what is to become of our beloved Quel'Thalas.
8229	The Wretched are a constant thorn in my side, $N.  When they're not being a danger to themselves by tapping unstable arcane sources to satisfy their cravings, they're cooking up half-brained schemes against our respectable society.
8232	I hope that Loralthalis is alright, $c. Maybe I should go up to Duskwither Spire myself? Maybe I should have done that in the first place?
8233	A man can only live with himself and his shame for so long, $c, before he must take action to undo the mistakes he's made.
8234	A mess, that's what this is!  All of these creatures sprung up out of nowhere, and are running around out of control!  And where've the Magister, and his apprentices, run off to?  Leaving me here all alone without as much as a, \\"Hello there Wyllithen, would you like to come with?\\"$B$BThe nerve!
8239	What are you looking at, $glad : lass;?  Never seen a dwarf before, then?$B$BYou'd best be on yer way if you don't want any trouble.
8240	Ah, you must be the $glad : lass; assigned to show me around the Eversong Woods.  Took your sweet time getting here, didn't you?$B$BVery well, off we go.  Let us not waste one more minute.
8269	Hail $c. Didn't I see you recently at an exclusive gathering? You look familiar, but then again this city is a busy place.$B$BIf you attended that convention, then surely you were given a secret code. Tell me your code and I will give you a special prize in return.
8292	What?! How did you sneak past my jail...er, minion out there? Well, I suppose it's for the best. Sales have been a little slow lately.$B$BHow may I fulfill your infernal needs, $c?
8326	The assortment of images, shapes, and markings come together before your eyes. The book seems to know your skill with leatherworking and offers you a choice - but be warned - you may only select one and once you have done so, may not change your mind!:
8327	I cannot teach you dragonscale leatherworking, $N. You must go to Tanaris and find the home of Narain Soothfancy. Once there, consult the book \\"Soothsaying for Dummies.\\"
8374	Oh, hello there.. um, what's your name?$B$BNo matter, what brings you to my home-away-from-home here out in the beautiful countryside?
8375	Hello, $c. I trust that you are enjoying youself? What do you think of the party? I do so hope that we aren't running out of anything. Nothing kills a fete faster than running out of drinks and hors d'oeuvres, wouldn't you say?$B$BYes, well, I must be about attending to my other guests. Do enjoy your stay.
8378	Greetings, my $g lord : lady;. I trust that you are having a pleasant time?
8379	Isn't this just so much fun? I'm so glad that Lord Saltheril throws these parties every night, especially with all of that nastiness occurring to the south. Kind of just makes all of that go away, don't you think?
8402	We're too merciful with the Wretched.  We ought to drive a sword through each of them.$B$BTheir boldness in Sunsail Anchorage is unpardonable.
8403	It's been a long day of cutting down the mindless Scourge that endlessly parade down the Dead Scar.  I hope you're here to lend a hand and not to waste my time with idle chatter.
8410	Another lovely, gloomy day here in Tranquillien, wouldn't you say, $c?$B$BWhat can I do for you?
8411	No greater freedom than to soar through the skies, $c. What can I do for you today?
8412	Hello, friend. How may I be of service to you today?
8417	$C, look what they've done to our beloved land. The Scourge must be destroyed!
8418	It's going to take a bit of work, but I think we can save this blood elf's life.
8419	Who are you?  I feel... so... cold.
8421	It is shameful that we sin'dorei have lost so much of what we used to call home.  It shall not be long before we regain our strength and retake our southern lands back from the Scourge!
8423	The high executor and Dame Auriferous are making me wait, but I don't have time for this! My friends are out there dying, $c!
8424	I sent Ranger Salissa south to the enclave and Ranger Lethvalin west to Tranquillien more than a day ago! Have you seen either of them? Are you the aid that's been sent back?
8425	Sometimes it feels like I'll never go back to being a simple functionary in service to Dame Auriferous. I'm not cut out for war.$B$BThankfully there are those like you who burn to see Quel'Thalas restored to its former beauty. Crush the Scourge, $c! Crush them wherever you can!
8426	Ah, here's the $g hero : heroine; of the hour now! Good to see you again, $N! I trust that you're still destroying the Scourge wherever you find them?
8428	I received word that you were able to help Ranger Valanna and the lieutenant at Zeb'Sora.$B$BThank you, $c. I suppose I should make my way back to Farstrider Enclave now.
8429	What business brings you here, $c?
8431	Ah, hello there, $r. As you can see, I'm not open for business quite yet. Now, if you'll excuse me, I'm very busy.
8433	Welcome to Tranquillien, $c. I apologize for the state that you find it in. As you can see, we've been having some trouble, but the Forsaken, and their Lady Sylvanas Windrunner, have been gracious enough to lend us a great deal of assistance in our time of need.$B$BIf you can lend a hand please do not hesitate to do so. We can use all of the help that we can get in our struggle against the myriad forces arrayed against us.
8435	Don't be afraid of the sword, nubling. It's the mutton that gets ya!
8439	It is very important that we find out what the the night elves are up to, $c! Please concentrate all of your efforts toward that end.
8440	We are most pleased with your actions against the night elves. When you uncovered their plot to use the ley-line nexi and their so-called moon crystals to spy upon us, you strengthened our position here by an order of magnitude.$B$BYou have our gratitude, $N.
8441	Are you the reinforcements? The night elves have been routed!
8442	Good thing that you deactivated the moon crystal at An'owyn when you did, $c! Come around any time you feel like pitching in with my research here.
8445	How can I work under these conditions?! And all of these disgusting Forsaken around here! I weep for Tranquillien and Quel'Thalas!
8447	$R, report! What news of significance do you bring? Be quick about your business... Dame Auriferous and I are in the middle of a strategic discussion.
8456	<The blood elf quickly regains consciousness as you pour the draught into his mouth.>$B$BI owe you my life, $c.  Without your help I would've succumbed to the Scourge's painful torture.
8457	<The blood elf lies on the floor in some manner of induced torpor.>
8459	<The Forsaken female is curled up on the floor, her face in a grimace.  She does not appear capable of getting up on her own at the moment.>
8460	Ahhhhggg... this pain in my head is killing me.$B$BThey must've sent you to rescue me.  Took them long enough!  Do you have any idea of the things they do to prisoners here?
8461	<The blood elf lies limp on the table.  While he's still breathing, he appears to have been the victim of potent sedative toxins.>
8462	Well met, $r. I am here as a resource of advice for the High Executor to make use of as he will. I am confident that together we can forge the Horde into something that is even stronger than before and turn back the Scourge menace once and for all!
8463	<Varnis coughs violently as the restorative draught takes effect.>$B$BThank you for rescuing me.  I must go back to Tranquillien at once!
8466	If it is a matter of import that you wish to speak on, $c, it may be more appropriate to seek an audience with Dame Auriferous. I warn you though, she is very busy and you may be in for quite a wait.
8467	Normally it would not be my place to speak with you directly; rather, you would seek an audience with milady. However, I did give you a task directly, so what is it that we need to discuss?
8468	$C, Dame Auriferous has conveyed to me her great pleasure in the service that you have done us in the past. She wishes to extend to you her hope that you will continue to be a champion of sin'dorei interests here in the Ghostlands.
8470	We've important work to do, $N.  Let us attack our enemies while their guard is down.  Let us show them that sin'dorei vengeance never forgets nor forgives.
8472	Well this is troublesome! How am I supposed to collect the ore samples for the magisters if the mines have been overrun with gnoll vermin?
8474	Where could she possibly be? I sent my apprentice, Shatharia, to the Underlight Mines to the west quite some time ago. We need those ore samples back, and fast or our experiment is going to fail!
8475	Without delivery of the Underlight ore in such a timely fashion, our research would have failed.$B$BJust wait until Shatharia shows her head here again. I've got some interesting tasks for her, you can be sure of it!
8476	Sin'dorei have lost far too much in the past years.  Our land, our homes, even our identities...$B$BIt's about time we started taking it all back.
8477	Before we can overcome external obstacles like the Scourge and the Amani trolls, we must overcome obstacles from within.  The Wretched have been a nuisance for long enough; it is time we vanquished them.
8478	Think you could help me to get out of here?
8479	Amongst the various pieces of parchment containing checklists and other information from the Farstriders, one stands out. It is a drawing of a hideous troll, perhaps the most fearsome creature that you have ever seen!
8485	Many an advantage can be gained from getting to know your enemy.  Take that lesson to heart, $N.$B$BThe more we learn about the Scourge the better prepared we are to defeat them.
8487	You're welcome to stay at the Farstrider Enclave for as long as you'd like, $c.  We welcome any who would aid us in our endeavors in the Ghostlands.
8488	Stray arcane forces can do strange things to the land, the elements and even the spirits of the dead.
8490	You've done us exemplary service, $N. Between dealing with the gnolls at the Underlight Mines, and the mummified trolls in the Amani Catacombs, you've dealt a mighty blow to our enemies!$B$B$G Good job! : We should get together for drinks sometime, what do you say?;
8491	Good to see you again, $g man! : gorgeous!; We work well together; $g see you around. : I hope we get to continue to do so.;
8492	Word got back to me through channels concerning Lady Sylvanas's reaction to you and the recovery of her necklace. I still think you did the right thing; don't worry too much about how the lady reacted.$B$BNow, state your business.
8493	What can I say, $c? You're a true $g hero : heroine;! Not only have you personally saved many of my rangers, but you've dealt a decisive blow against the Shadowpine trolls. Are you sure that you don't want to stay here and be one of my Farstriders?$B$BFare well, $N.
8495	Your help with the Shadowpine trolls is proving invaluable, $c. Keep this up and maybe we'll be able to turn our attention back to dealing with the Scourge.
8496	You've dealt the decisive blow against the Shadowpine trolls, $N. I only hope that we can muster our forces quickly enough to finish them off before they receive reinforcements from Zul'Aman.$B$BIt would be nice if Tranquillien were to reinforce us.
8501	The situation is more grim than many have been led to believe. The Forsaken are here as allies in the fight against our common enemy, the Scourge.$B$BTrust me when I say this, without them the Ghostlands would be lost and the Scourge would already have overrun all of Eversong Woods!$B$BBut more than anything else, we need your help in reclaiming our once proud lands!
8504	These Runestones protect the lands in Eversong from becoming tainted by the Scourge.  The Western Runestone failed long ago, forcing us to burn the ground around it.$B$BAs long as I live I won't allow the remaining Runestones to fail us.  That is my oath.
8505	Well, you didn't come all this way out here to jaw over a cup of tea. Let's see how you might be able to help get us out of this situation.
8506	There are those who would say that the Argent Crusade is a thing of the past. I am one of them, but not because the Scourge have fallen.$b$bNo... it is because of their stubborn ways.  They've become too much like the church that they seceded from: too rigid, too governed by honor and order.  This is what I'm trying to tell Barthalomew, anyhow.$b$bSure, it may sound a bit jingoistic, but it makes for a good debate.
8534	Our Sanctums syphon arcane power from ley-line currents that traverse our lands invisible to the naked eye.$B$BWith the Sunwell gone, they provide us with a steady and reliable source of energy.
8535	It's a testament to our race's tenacity that Fairbreeze Village still stands.  We shall never concede defeat to the Scourge ever again.
8541	You've served our cause with great loyalty, $N.  Allow me to present you with an unending source of our elemental quintessence.
8550	Is that a list from Saltheril's Haven?  No doubt, his lordship will require a bottle of my finest.  And, of course, any friend of Lord Saltheril deserves a special price on such a fine vintage.
8552	If you have the coin, I have the food and drink to keep that appetite of yours satisfied.  Every copper goes to keeping the Retreat in tip-top shape.
8553	Is that a list from Lord Saltheril that you have there? Yes, I can sell you a batch of appetizers, fresh off the fire.
8556	I have all manner of goods for sale, $c.  Browse at your leisure.
8557	A list... how intriguing.  Ah yes, the shipment of fireworks for Lord Saltheril.  He hasn't paid for them; are you here to purchase them on his behalf, $c?
8558	Is there no end to these undead?  It seems that for every ghoul or skeleton we kill, two take its place.
8561	$C, you didn't happen to see a courier on your way here? We are awaiting word from Silvermoon City and their messenger is late!
8564	Sometimes I stand here, looking into the forest beyond the lake, and I see the land as it once was... green and full of life.
8565	We really must perfect a way to deal with those smelly Shadowpine trolls!
8566	I must say, you delivered my poison and dealt with those trolls most ruthlessly, $c. You've got the makings of quite a talented young $g man : lady;!
8569	We must maintain a state of vigilance, $c! Between Dar'Khan the Betrayer and his Scourge, and the Shadowpine trolls backed by the might of Zul'Aman, we're barely keeping our heads above water here. We really shouldn't have to be dividing our attentions!$B$BI hope you're here to help.
8570	I'm glad that you're here to help, $c. The faster we can deal with these trolls, the faster we'll get to send the scourge back to where they came from.
8571	One set of trolls dealt with, one yet to go. You have no idea how much I appreciate what you're doing, $N! Before you came along I didn't think we'd ever get the Shadowpine problem under control.
8572	You wouldn't believe some of the rabble that we've had come through here lately. Most are more trouble than the supposed help that they provide. Nothing at all like you.$B$BYou sure you don't want to sign up with the Farstriders?
8575	What brings you here, $N?  We don't see too many people around these parts.  With good reason, I suppose.
8576	Do you wish to learn the blacksmithing profession or is there something else you wish to tell me?
8579	We are very fortunate to be alive, you and I!
8580	You don't see too many apprentices around these parts, do you?  I'm beginning to think it's because the magisters give us all the dangerous work they'd rather not do themselves.
8584	We are one in the Light, $g brother : sister;, but I cannot train you.
8585	You come in search of training, hunter?
8587	Do you seek further training in the ways of the warrior?
8589	We practitioners of the arcane and elemental ways follow a never ending path of discovery. Is that why you seek my counsel? You wish further training?
8591	In the Light we all cast shadows, my $g brother : sister;.  Do you seek further guidance today?
8617	As you gain renown with our town, I can make more goods available to you, $N.  With equipment in such short supply we can only afford to provide it to those we trust.
8619	It is so good to see you, $g brother : sister;!  This place gives me the creeps.  While you're here, be sure to avail yourself of the many opportunities that these so-called Forsaken are providing.
8620	It's not my fault... IT'S NOT MY FAULT!!!$B$BIf they'd just done what I told them to do everything would have been fine. But no! They wouldn't listen.$B$BNow they're all dead.$B$BI just want to go home. Home to Silvermoon. I'm so tired.
8638	Hello, $c. If you haven't already, you really should speak with Farstrider Solanna.
8650	I am most grateful for your help, $c!
8656	Missing US text
8659	Though we've arrived at the promised land, $N, much work remains to be done.  Our people won't reach Kael'thas if we lunge desperately across Outland.$B$BSafe routes must be found, resources must be secured and our enemies must be avoided or destroyed.
8663	Thank you for delivering that list!  My leg is almost recovered enough that I'll be able to walk back to the crash site.
8664	How are we ever going to get out of here?
8665	Thank you for taking care of the lake, the lashers and the owlkin, $c.
8666	None will question your actions, $c.  You did what had to be done.
8667	It is good to see you alive and well, $N!
8669	Thank you again for replenishing our healing crystals. I hear that you're helping out all over the place. Keep up the good work!
8674	Here's to hoping not all of Outland is as barren as this region.  This is quite a change from the green grasslands and forests of Eversong.
8675	There exist in Outland demonic presences much more powerful than anything we'd ever seen in the old world.$B$BGreat power shall come to those who do not shy away from it, but learn to harness and master its strength.
8676	UDB Missing US text
8678	How may I serve?
8680	Outland just oozes with magical energy, it's in the very air.  Can you feel it, $N?  I can't think of a place better suited to our race.  Soon the sin'dorei shall have a new land to call our own!
8681	My husband's been missing for days.  We went on this pilgrimage together; we were supposed to finish it together.$B$BAll this worry has gotten me tapping into mana crystals more often than I really should.
8682	Dragonhawks, if raised properly, are really quite tame.  Don't you think that is fascinating?  To be so friendly and companionable if raised right and so vicious and deadly in the wild...I just love them so much.
8683	Don't... worry... about me...
8684	I really don't think our situation is so bad.  I am certain it will all be rectified soon and the Sunwell's power will be restored.  It just can't possibly be as bad as everyone is making it out to be.
8685	Befriending the Sunstriders has paid off; I get to conduct research with subjects I can only find in Outland and they get... my charming personality and rugged good looks.
8698	You think I'm being cruel to this worm?$B$BThey've killed two of my men this month!  We're too kind to this Wretched scum.
8699	Welcome to Fairbreeze Village.  Silvermoon's all but given up on us, but we refuse to leave.  This is our home.
8700	My job consists of one task and one task only: ensuring that the West Sanctum runs smoothly.$B$BYou'll have to excuse my temper but, as you can see, the situation here is a bit out of hand.
8712	If you're looking for work, $c, grab yourself a pick and get to digging. There're ruins out there as far as the eye can see!
8713	Greetings, $N. My fellow Sons of Lothar and I have been stuck on this miserable world for close to twenty years now. We held on as best we could, but it still amazes me that the threats we face today are just the shadows of our past failures.$B$BPerhaps you will help us atone for them?  $B
8715	The extent of the corruption in Outland is truly astonishing, $c. The Cenarion Circle hopes to understand how these creatures have managed to survive. Studying this broken, tortured land and its inhabitants may yet teach us how to heal ailing parts of our own world.
8717	You look lost, $c. Don't make me put you to work on the walls with the other peons.
8718	Well met, $c. Your arrival in Thrallmar could not have occurred at a better time. The warchief is depending on us, since he cannot be here himself.
8719	Thrallmar needs you, $c. The warchief needs you. Stand ready to do your duty.
8724	Few bouts are won by sheer strength.  It is cunning, reflexes and knowledge of your weapon that wins the day in the end.
8733	Another hero? The fates smile upon us on this day, $N. 
8740	I've heard something of your exploits, $N.  I know that while you're here in Forsaken lands that you'll comport yourself with dignity and as a true hero of the sin'dorei!
8750	I bid you welcome, $c.
8751	I haven't time for idle chatter, $c. I must see to the pilgrims and ensure they are prepared for the long journey ahead.
8752	Welcome to Falcon Watch, $c. I see to the needs of the pilgrims and help them in continuing their long journey. If you haven't yet undertaken the pilgrimage, I can provide you with the information you will need.
8754	Walk always in the Light, $N.
8755	Welcome to the Farstrider Retreat.  We are rangers sworn to defend our people from enemies both near and far.
8756	I think I'm beginning to regret undertaking this pilgrimage. I anticipated that the road would be rough and I'm no stranger to travel, but I wasn't prepared for the rigors of Outland.$B$BOn top of everything else, that Taleris seems to want to push me out of here before I've regained my strength completely.
8759	Oh... do I know you?
8760	Hi, $N!  Enjoying the party?
8767	I've managed to work myself into quite a spot here. Far Seer Regulkut tried to warn me, but my carelessness has finally caught up with me.$B$BI came down here to study the ruins of Zeth'Gor, but ran afoul of the Legion on my way. Now, all I have to show for it is a nasty gash on my leg.
8769	It is very important that we find out what the the night elves are up to, $c! Please concentrate all of your efforts toward that end.
8775	This emitter is driving me nuts!  I'm missing all sorts of parts that I need to fix it.
8776	$N!  Thanks again for all the help.
8777	Nope, still not done with these repairs.  Shouldn't be long though.
8787	Hello!  So good to meet you!
8788	Greetings.  You are here to help?
8789	Just remember, $N, it's in our best interests that you do as much as possible for these... these people.
8790	Greetings, $r!  I trust this day finds you well?
8791	Any news from home, $c?
8794	Hello.  I trust that this day finds you well?
8795	It's so good to see another sin'dorei $g brother : sister;!  As you can imagine, there's not much in the way of conversation around here.
8797	So good of you to speak with me.  Please, help the Alliance in any way that you can.
8799	While we have much to teach the other races of the Alliance, we have as much to learn from them.  Keep your eyes, ears and mind open, $c.
8800	Hail to thee, $c.
8801	Is this city not beautiful, $c?  It warms my heart that we have found such good friends in these night elves.
8802	Greetings,  I am Vindicator Palanaar, a traveling paladin of the Light.  I am here to be of assistance to the night elves.
8803	It is my fervent hope that we will be able to bring the Light to those places in Ashenvale where it has been forsaken.
8805	This is going to be such fun!  Don't you think, my dear?
8808	Did Balandar Brightstar send you to rescue me?
8809	Oh, most excellent!  That was great fun, was it not?  Little by little I've been cursing more of those disgusting Lost Ones.  Soon enough I'll be ready to try it on the draenei!
8810	May the spirits guide you, $r.
8811	Strength to the Clans, $c!  What brings you here?
8813	You are welcome among us, $c.  At least for the time being.
8821	Isn't that adorable! How did you make it out of the Vale? Maybe you should get back there before someone sends a search party after you.
8822	I haven't got anymore work for you, $N. I do want you to know that the red snapper we shared was something special that I'll never forget...
8823	Of course I've got a job for you! We're always looking for hunters. Hopefully you'll fare better than the draenei we had to send back to the Exodar -- for burial.$B$B<Acteon laughs.>$B$BI'm joking! You should have seen the look on your face. They got sent back to the Exodar for treatment of minor wounds. Nothin' that they won't recover from...
8824	Return to your people and tell them to send one of your shaman to me.
8825	Return to the draenei and tell them to send me one of their shaman.
8827	Do you have the understanding to continue, shaman?  Do you know why you are here?
8829	It is a good day to be alive and one with the elements.
8830	And why would I speak with you, $r?
8836	I WILL have my revenge!
8846	Hello.  What brings you to Chillwind Camp today?
8847	Good day to you, $c.$B$BI'm waiting to hear from one of the High Thane's advisors about an audience. It was a struggle just to get the opportunity to present my credentials.$B$BI've heard the Wildhammer described as 'wary of outsiders,' but that's proven to be quite an understatement.  Hopefully, things will improve once I've had the opportunity to meet with Featherbeard, whom I'm told favors closer ties with the Alliance.
8848	What do you want?$B$BIt's a bit rude to walk up to strangers for no reason, don't you think?
8851	Light be with you, $c.
8852	It looks like help has finally arrived!  The Omenai welcome you to our remnant camp, $N.
8855	Welcome, $N. I am Landro Longshot - manager of the Black Flame. Perhaps you've not heard of the Black Flame until now. That doesn't surprise me; we work to keep things that way. We prefer to avoid... factional entanglements.$B$BThe Black Flame specializes in providing the finest services and entertainment money can buy, whether they happen to be hard to find items, gladiatorial combat, or lucrative games of chance.$B$BAre you here seeking something specific?$B
8856	Ah - oddities and rarities. We specialize in Azeroth's more unique items for the discerning adventurer.$B$BSince you're speaking with me, you must already have an idea of what you're looking for. So, $N, which item are you interested in?
8858	Do you need something, $c?  Perhaps I can assist you.
8861	<Priestess Il'dinare eyes you suspiciously.>
8862	I am a night elf, stranger. While you may know nothing of my kind, we know much of you and your progenitors. You may not call yourself eredar but, in appearance, you share many similarities.$B$BYou have helped my allies, and for that I am thankful; but for the time being, you walk a tenuous path. Perhaps in time, you will be able to dissolve the doubts and fears that I hold in my heart.
8865	You've been a great help thus far, $N. You would do well to help out the others at the encampment.$B$BAnd don't worry about those goblins, I'm taking care of everything.
8866	It is good to see you again, $N. Perhaps once things have settled down, I can talk to you about the priceless treasure that we have lost...
8867	What are you lookin' at?
8868	I am Adamant Ironheart of the great city of Ironforge. As you could probably guess by looking at my uniform, I was once part of the Ironforge elite guard. Yep, I was Magni's right hand man! At least until I retired. Now I dabble in archaeology. It's a hobby really; plus I figured it would be a great way to see the world!
8869	<Cowlen sobs.>
8870	What could I have done to give the gods cause to lash out at me with such ferocity? All that I cherished is gone - dead or destroyed. My family taken from me by the brutes of the forest. My home razed. My ship sunk.$B$BI am a broken man, stranded on a broken island.$B$BPerhaps you are you here to finish the job? Make it quick, I will not resist. Take my life, stranger; I am too cowardly to do it myself. My hand shivers... the blade will not strike true.$B
8871	If not the gods, who? How? What could cause such strife?
8872	Legion? Demons? They hunt you? My people have also been hunted by Legion: Targeted by their dark masters for damnation.$B$B<Cowlen wipes the tears away.>$B$BIt is the reason that I moved my family here oh-so-many years ago.
8873	Greetings, $c. Before the night elves invited the draenei to join them here, this glade was all but forgotten.$B$BThe kaldorei are deeply tied to these lands, and we draenei are honored that they have asked us to share in the task of revitalizing Forest Song.
8874	It's good to see a new face out here. Our outpost is small and our enemies plentiful. We are surrounded by those who seek to destroy us: the satyr to the west, the orcs of the Warsong Lumber camp to the south, and the demons of Felfire Hill.$B$BWe're grateful that the draenei have accepted our invitation to join us in fortifying Forest Song against these myriad threats.
8875	It's good to hear the voices of others here in Forest Song again. I'd begun to feel as though I might be the last of the kaldorei ever to set eyes on these lands before their descent into corruption.
8876	Can you feel the evil to the south?  By the Hand, it must be cleansed!
8880	With you and your people as allies, we have decided to stay on this island and rebuild. Elune bless you, hero.$B$BWhile the sadness still comes and goes, I think we will survive.$B
8881	You're a $r, right?  I am heartened to see you here!  We can use all of the help that we can get.
8883	There are demons to kill, $c.  Do you have the backbone to do what needs to be done?
8887	With a good portion of their demons slain, the Legion will think twice about attacking our lumber camp again.  However, I still sense demonic evil stirring.
8893	All hail the exalted hero!
8934	Hi there, $N. How may I help you?
8939	Welcome to Forest Song, $c. If there is anything I can do for you, please let me know.
8952	<The footman stand resolute, muscles tense.>
8954	What brings you all the way up here, little $r?
8956	Greetings, $c.  I get so few visitors up here.  To what do I owe the pleasure?
8959	I have been expecting you.
8962	Keep your voice down, $c!
8964	How fares your search for the Mark?
8965	This is a great day, $c!
8966	I cannot thank you enough for making my pilgrimage possible!
8974	The infected nightstalker runts seem to be coming from the north. If I were you, that's where I would start my hunt.
8975	Wow, you totally bombed out there. Let's think of that as a rehearsal, shall we? Ready to go out again?
8981	Rough audience, but you'll win them over. Ready for another shot?
8990	How can I help you, stranger?
8991	Gurf is my name, stranger. Gurf the Brave!
8992	I am Moordo, elder hunter of Stillpine.
9002	I'm afraid I'm rather busy fixing horseshoes at the moment.  Would you mind coming back at another time?
9004	You know about the Violet Eye then?  Maybe I'll have time for you later.$B$BI have to get back to my work.
9005	<Eralan appears to be chewing on some deathweed.>$b$bIf you're looking to make a love potion, you've got the wrong place.  Blinding, crippling, and killing is my business and hopefully yours.
9006	I can sense your desire for power, $c.
9007	The Light gives us the strength and magic to triumph.
9008	Welcome to the Registrar of Guilds.  How can I be of service to you?
9009	Hello, my child.
9010	The better to hear you with, my child.
9011	The better to see you with, my child.
9015	Together we will deal with this corruption of the water.
9016	You have done a great thing, $N.  You are welcome here at any time.
9019	Come for some blacksmithing supplies, have ya?
9020	I've got fresh meat, fish and mushrooms.  And plenty to drink!
9034	Everything that has happened since the crash is little more than a blur. It seems like a lifetime ago that I was aboard the Exodar.$B$BNow, my reality is restricted to this island with its mutant creatures and endless sea of blood elf agents. Soon, it will be as if I've never known anything different...
9038	Thanks for the warning, $N! We shall prepare!
9039	Promised One, we thank you for the warning. The Stillpine tribe will be prepared.
9040	Thank you for the warning, $N. We will prepare our defenses.
9044	What it means to be a Hand of Argus... We are agents of the Light. We serve without question. We die without question.
9045	Did they send you to find me? Well I'm not going back without my men.
9050	Yes, I am one of the 'Broken'.  I trust that this does not bother you?  Broken or draenei, we must endure the ridicule that some in our society may throw at us.  A better understanding and communication with the elements of this world is all that matters.
9056	Are you mad? Look around you, mortal. Do you not see that you stand upon sundered earth? Leave this place lest you suffer as my people and I have...
9057	Are you blind as well as insane?$B$BI am a ghost - a cruel reminder of a civilization that has long since ceased to exist - anchored to a land that I failed to protect.$B$BLong ago - ten-thousand years past - I was flesh and bone, just like you. I was prince of this land and a dragon rider, blessed by Ysera of the Dream.
9058	Have you not heard of Ysera? Guardian of nature? Aspect of the Dream? She is the matron of all green dragons! Aye, it was Ysera herself that gifted my kingdom with her brood. We stood shoulder to shoulder with the noble creatures and they allowed us to ride them into battle against our enemies. All was well for many centuries... until...
9059	Deathwing's brood... Ysera's benevolence raised the ire of Deathwing - patron of the black dragonflight. They attacked us in our sleep! Many died on the initial surge but the greens rose to protect us.$B$B<Prince Toreth points around the island.>$B$BThe bones are all that remain of the once great dragons. None were spared.
9060	I was the last to die. As I felt my spirit leaving my mortal shell, I swore a blood oath.$B$B<Prince Toreth shakes his head.>$B$BA pact was made between this land and I: My blood for this world. I became the sole keeper of the history of my people.$B$BI cannot rest until I am secure in knowing that the story of the dragon riders of Loreth'Aran is not lost in the passages of time.\r\r\n
9061	Students are a bit like sheep.  They're useful and even likeable when you guide and pay close attention to them.$B$BYou leave them alone for a minute and they end up falling down a cliff or drowning in a shallow river.
9062	This sign contains various announcements and notices of rewards for performing dangerous sounding tasks.  Nothing particularly catches your eye; perhaps you should check again at a later time.
9067	Stay away from me, $r! There's no telling when the sickness will take me again.$B$BJust leave me alone before it happens again.
9070	Examining the corpse, you conclude that this must be Blood Knight Dawnstar, the leader of the failed assault on Deatholme.
9072	A search of the corpse's clothing and equipment reveals the insignia you need, undamaged by the battle and foul environment.
9073	Elune's grace upon you.  How can I serve?
9074	Greetings, $c.  It is good you've decided to visit us.
9077	Greetings, $c. I am Kuros, second of the Triumvirate of the Hand.
9079	I watched as they beat him without mercy. Their ruthless lieutenant acted as if such cruelty was an act of normalcy. Through the savage beatings, I could feel myself breaking.$B$BAs I watched Vindicator Saruan take their blows, I began to weep. Not out of fear... I wept out of sadness. To see a draenei of the Triumvirate treated in such a manner. If only I could have broken free of my bonds. If only...$B
9080	After what seemed an eternity, the Vindicator lost consciousness. The torture was too much, even for him. The cruel one - Matis as I found out he was called - attempted to wake Saruan by splashing contagion laced water across his ravaged body. But Saruan did not wake.$B
9081	I wanted to scream but only a low gasp escaped my lips. I was promptly beaten for this act of rebellion. As I lay on the ground, I could see Matis pacing in front of Saruan's body. He seemed visibly concerned. He stated that Sironas or Sirona or some such entity would have his flesh flayed from his bones if Saruan had perished in the beatings. $B
9082	That the Sironas entity had plans for Saruan... $B$B<The writing stops abruptly and a long line scrolls off the page. This draenei died while making the entry.>$B
9097	Begin your search to the north, $N. Our scouts have spotted the Warp Piston near the shoreline.
9106	If our enemies would see that we only wish to live in harmony with them, maybe we wouldn't have to attack them for our own survival?
9107	Their day will come, $N.$B$BAnd when it does, I will be there.
9108	With new enemies on our doorsteps, we must not allow our ancient enemies to take advantage of our situation!
9109	Can you believe this place?  'Course, it's a mite stuffy up here if you ask me.
9110	Say, you happen to see that arch in the lake to the west?  I wonder where that goes?  I should go divin' over there.
9112	If only I hadn't twisted my ankle coming into this place, I'd be in there with my friends.  Hmmm, now that I think about it, maybe it's better that I'm out here?
9113	Fhwoor like little sporelings.  They save Fhwoor.  Not eat them.$B$BFhwoor hate naga.  Fhwoor smash!
9117	I am Aesom, third of the Triumvirate.
9118	Here lie the remains of Weeder Greenthumb, one of Watcher Jhang's druid companions.  By all appearances he was killed quick and clean while trying to make his escape from the Slave Pens.
9119	I almost made it!$B$BI came in here to prove the existence of Quagmirran, that most mythical of fungal giants.  I got my wish, sort of.$B$BYou must let me free!  In return I will grant you a boon to help you to deal with Quagmirran.
9121	Thank goodness for you!  Claw and I were investigating this place when we were jumped by Swamplord Musel'ek.  He can control animals, even druids!$B$BUnfortunately, Claw was caught in bear form at the time, and is now the swamplord's pet.  I don't dare change into cat form or he'll get me too!$B$BI'm afraid you'll have to fight Claw in order to save him.  Just keep heading west; you can't miss him.
9122	As the only apparent surviving 'Broken', it is both my duty and honor to carry on the shamanistic teachings of Farseer Nobundo.
9123	Damn those blood elves and their reckless magic!
9124	Do not waste my time.  What is it you want?
9127	May the Light bend to your will in all endeavors.
9136	<The captured Sunhawk agent eyes you suspiciously.>$B$BI've never seen you before. Who are you?
9143	I am patiently awaiting orders, $c.
9144	Now that the rude interruption is over, as I was saying, Quagmirran is nearby!$B$BAs promised, I can fortify you with a magical boon that should aid you in your fight with him.
9145	[In broken Common] It is time celebrate we do.
9149	You've come a long way, $N. A long way indeed... But I knew you were destined for great things.  We all knew. All hail $N!$B$BAnd thanks again for taking care of our gnome problem...
9160	I wanted to thank you once more for what you did for me. You gave me the courage to take back my home from the beasts of the forest. In doing so, I found Magwin!
9162	The draenei champion walks among us. This is a celebration for the savior of Azuremyst and Bloodmyst!
9168	I have no idea who you are, but your presence is most welcome. Archimonde and his Scourge army could attack at any time, $C. Will you stand with us against this evil?
9169	Thank you, $R. Now prepare yourselves. Archimonde is on the march, and we must hold off the inevitable for as long as we can.
9170	We must continue to hold on for as long as we can! Fight on!
9172	I am the leader of the Blood Watch defenses. What can I help you with?
9173	[In broken Common] Stillpine be ready! Many thanks!
9174	Welcome to the headquarters of the Blood Knights, the defenders of Quel'Thalas, the faithful servants of Silvermoon, and the true masters of the Light.
9179	Greetings, $N.
9182	How can my people fight when the elements are in such turmoil? Do they not see that without the support of the elements, the world simply cannot be.
9184	I can sense your desire for power, $c.
9186	I have no time for a sermon now, $c. Seek your knowledge elsewhere.
9187	It appears you took a wrong turn, $c.
9188	Greetings, $n. You were not followed here, I trust?
9189	We have little to discuss, $c. Perhaps you should seek other, more like-minded individuals.
9190	It's a pleasure to see someone sane around here. How can I help you?
9191	You clearly lack the capacity to grasp the intricacies of the arcane, $c. Off with you.
9192	What assistance can I offer in your studies?
9193	Ours is a path for those with an iron will and unfaltering resolve. You seem to possess none of these traits, $c.
9196	May the winds guide you, $N.
9197	This book contains information on the plant species of Outland.  Most of the plants detailed are native to Zangarmarsh.$B$BThe charts and diagrams are a bit beyond your understanding.  Perhaps the author could give you some pointers.
9199	I've always liked sorting and organizing things.  I guess I take after my mother.
9204	Thanks to you our young ones will be safe, $N.  Go to Sporeggar and meet my people.  They've all heard great things about you.
9206	The Defenders of Blood Watch protect this outpost from any threat. 
9221	$N!  I remember your hunting prowess all too well.  You might have gotten off to a shaky start in Stranglethorn, but you stuck in there and became one o' the finest when you bagged old Bangalash.$B$BBut listen, $g lad : lass;, the prey out here in the Outland is the real deal.  And I've the scars to prove it!
9230	The Burning Legion presses us hard, but our defenses hold. Every moment we keep Archimonde away from the World Tree brings us closer to victory.
9241	Do not be fooled by the ruins surrounding us, $c.  Dalaran is as powerful as ever.
9242	Karazhan is more than a mere building, $N.  If you traced the ley-lines traversing Azeroth you would find that they all converge right about there.$B$B<Alturus points at an invisible spot below the tower.>$B$BFascinating, isn't it?
9245	A thick red slash has been drawn across the words WANTED: Deathclaw.  \\"This bounty has been claimed by the heroic $N, who has overcome the fearsome beast,\\" declares more writing in the same red ink.
9246	This sign contains various announcements and notices of rewards.
9248	Welcome to Zabra'jin, $c. I am Shadow Hunter Denjai, overseer of this outpost and commander of the Darkspear forces in Zangarmarsh.
9249	Now don't you be thinkin' about tryin' to make off with me baby murlocs! I got the eyes of a hawk and ears like... ears like... like somethin' with mighty powerful ears!
9250	Tor'gash believes he can see the future in the entrails of birds, or by tossing the knucklebones of his ancestors. Really, all you need to do is ask the spirits. But don't try telling him that, $N. He's very stubborn.
9256	You've proven yourself a very capable game hunter, $N.  But there's still one beastie that haunts your dreams... Tusker!
9257	You've bagged them all: Bach'lor, Banthar, Gutripper, and even the mighty Tusker!  You're truly the finest big game hunter that I know!
9259	The first time I saw mushrooms taller than trees, I wasn't so sure I could call this place home. After a while you just stop noticing.
9260	Don't forget to take some time out to fish while you're in Zangarmarsh. You never know when you'll see water again.
9262	The view from the top of Telredor is magnificent, isn't it?
9267	Shadow Hunter Denjai sent me here with a small contingent of builders and warriors to establish this outpost. We've barely finished building it and he's already asking for reports!$B$BIf you need supplies, I can offer a few things, but we're still waiting for our first shipment.
9268	If you ever meet Witch Doctor Tor'gash, tell him his concoctions and charms don't work! I did exactly as he told me to and still Magasha has eyes only for Zurai.$B$BDon't believe a thing that sham witch doctor tells you!
9269	Reavij has all the subtlety of a kodo! What's funny is that he doesn't think he's being obvious. I see the way he stares at me when he thinks no one's looking.$B$BHe creeps me out. I really wish Shadow Hunter Denjai hadn't sent him with us. Setting up Swamprat Post was the perfect opportunity to get away from him.
9271	Garadar is in shambles, stranger. Since the Greatmother took ill, Garrosh has gone into a deep depression. He is most certainly not his father's boy.$B$B<Kurkush sighs.>$B
9274	Notices of reward for the naga leaders of the Darkcrest and Bloodscale tribes are listed here.
9275	They died. All of them...$B$BAs the Murkbloods cut through us, something took hold of me that I cannot understand. Tell me, have you ever felt a rage so great that the whole of your being burns? A heat that wilts the living? A heat that incinerates the blood in your veins? That is what I felt.$B$B<Saurfang's eyes glow red for a brief moment.>$B$BI was the last one left alive. 30 of them surrounded me... Murkbloods... I remember nothing beyond that vision. I blacked out and awoke some time later.
9276	Dark times loom ahead, stranger...
9277	The spirits are greatly agitated. We must find the cause of this disturbance.
9283	Hemet is the greatest hunter that I know.  We chanced upon each other in the hills of Winterspring back on Azeroth many moons ago.  He and I were stalking the same quarry: the great cat known as Rak'shiri.$B$BRather than fight each other over our prey, we made a wager out of it; whoever collected the frostsaber's skin would get to demand something of the other.  To my eternal shame, this is how I earned the nickname, Fitz.$B$BDo I look like a Fitz?
9284	The mighty hunter, $N returns.  Tell me the tale of stalking your latest prey.
9286	Yeah, yeah, I'm feeling better, but I kind of like it down here.
9289	Do you know who we are, stranger? We are Mag'har - brown orcs, as I have heard your kind call us. The Mag'har are survivors: Survivors of a fallen dynasty; Survivors of the Red Pox; Survivors of a shattered world...$B$BI am Jorin, son of Kilrogg; last of the lineage of Deadeye: Warchief of the Bleeding Hollow Clan.
9290	We wouldn't have crashed if Hemet could learn how to avoid shooting through the ailerons when he's trying to bag game on the ground!$B$BNo worries though, I'll have her fixed up quick enough.
9292	I am SO glad that evil Gankly Rottenfist got his just desserts!  I have lots of skins if you want some to give to Harold.
9296	Greetings $N.
9297	The Greatmother raised all of us. Any Mag'hari that you see has had their life touched in some special way by the Greatmother. We will miss her greatly when she passes.
9369	You will stage a series of events that will lead the Kil'sorrow orcs of Kil'sorrow Fortress to believe that the Warmaul ogres have attacked their base and then another series of events to make the Warmaul ogres believe the Kil'sorrow orcs are attacking their base.$B$BDo this and you solve both of our problems.$B$BThe Boulderfist will have their territory back and your people will be free from attack from Boulderfist, Warmaul and Shadow Council.
9373	Registrants are required to speak with Warden Bullrok before posting any task.$B$BThose found making unapproved postings will be prosecuted.$B$BPost no bills.
9375	Check the bulletin board if you're looking for work, $r.
9376	They have no respect for the dead, $r. The ogres must be taught a lesson.
9377	We must search for survivors. If anyone is still alive, we must at least try and get them back...
9383	Who are you?  What do you want here?
9384	I can instruct you in mining.  Interested?
9387	Amazing! Anatheron's defeat at your hands has delayed Archimonde from his objective, and brought us that much closer to victory. My forces cannot stay here, however. My troops and I are exhausted, and now is the time for retreat. If your strength has not waned, head east to Thrall's encampment. That is where we make another stand. Be well.
9389	We've got to get those supply crates back!
9392	This forest be a spooky place.  It's full of more bad juju than just the Alliance, so you watch out for yourself.
9393	The Horde isn't the only danger in this forest. Don't let its seeming tranquility fool you.
9395	Get out of my way, $r. Can't you see that we're in the middle of a battle!
9398	Outstanding! Killing a Pit Lord such as Azgalor is no small feat, my friend. If we had more time, I would love to hear the story of you and your companions. Archimonde will not give us that pause, however. My scouts have already reported that the Legion is amassing an immense force outside our camp, and Archimonde is very close to the World Tree. We are evacuating with the help of Lady Proudmoore. You should head to the World Tree at once. The fate of our world is still undecided.
9401	The corpse of one of the Broken lies here.  Mysteriously, the cause of its death does not appear to be from one of the mutated moths.$B$BPerhaps it has something to do with the strange object resting right next to its outstretched hand?
9403	Hail, champion! Have you ever thought about going into the gladiator business full time? You and I could make a mountain of gold.
9406	Now that I've been beaten to within an inch of my life what do you want?
9407	We'll get to the bottom of this massacre if it's the last thing we do!
9408	Your assistance fighting the Burning Legion would be most appreciated. Lady Jaina Proudmoore could use your help on the front lines.
9410	The moment we've been dreading is now at hand, $C. Archimonde has made his way to Nordrassil, and is beginning to devour the World Tree's energies. Malfurion needs more time for his plan to work, so we must do the unthinkable. You must attack Archimonde directly, while my own troops hold off the streams of Burning Legion forces approaching the top of the mount.
9414	Welcome to the Taverns of Time!
9425	Oh no, not you again!  Go away!
9427	This is what I have gathered from the information that you collected from the survey.$B$BThere are two primary forge camps: Forge Camp: Hate, directly west of where we stand and Forge Camp: Fear, directly southwest. Each camp has a Legion transporter, one forge, and several spell warding towers. Additionally, the camps are guarded by wrathguards manning fel cannons. Lastly, each camp has a pit lord overseer.$B$BRight then, this should be no problem at all...$B$B<Altruis laughs.>
9433	Twin Spire Ruins is not yet secure! My orders are to only give out battle standards when the two beacons are lit and the area is secure. Get out there and gain control of those beacons!
9444	Thank you again, $N, for helping me to uncover what happened here at the thicket.
9451	My job is to care for these poor souls.  I accept the help of any willing to lend a hand, be they Aldor or Scryer.$B$BWe are so understaffed, I wouldn't turn an ogre away if they knew how to apply a tourniquet.  The politics of the city are of little matter to me. 
9452	Can you believe it?  This ethereal does not have a single basilisk eye on him!$B$BAnd his leader has the gall to call himself \\"the Smuggler Prince!\\"
9472	Be wary, $c. The forest is full of hidden dangers and potential enemies.
9478	You are here to assist the Aldor?
9481	If you're expecting some kind of official welcome, you're going to be disappointed, $c. We don't stand on tradition, here. What works is what goes.
9482	One note stands out from the other various pieces of parchment that are tacked onto this wanted poster.  It's a call to slay the bonelashers of the Bone Wastes.
9484	No, don't feel bad.  I get that a lot.$B$B<Taela looks both amused and annoyed.>$B$BI'm a HIGH elf, not a blood elf.  Don't worry, I'm not going to suck all of the magic out of you.
9485	Bonelashers, I hate them all!$B$BIf it weren't for the loss of my eye, and the fainting spells that I get sometimes, I'd be out there shooting them down all the time!
9487	There's a whole vast forest out there, $c. Let the shaman play with the spirits and the warriors toy with their swords. Terokkar is where I'll make my fortune.
9488	Malukaz chatters incessantly about the historical importance of this forest, but I don't have the luxury of indulging in history until our present problems are settled.$B$BI'm not saying his work here isn't important, but someone has to see to the defenses and logistics of running the hold.
9489	Until I traveled through Nagrand and came to the forest, I feared that too much of our original culture was lost. I'm thankful to see that I was wrong.$B$BThere is so much to be done here!
9490	The opening of the Dark Portal brought news of my people's fate. In a way, my exile shielded me from sharing in their downfall, but to see the Farstriders throw their lot in with Kael'thas...$B$BI never imagined my one-time brethren capable of such a thing.$B$BThe homecoming I once dreamt of will never happen. This forest is the only home I have left.
9492	When I first arrived, I'd hoped to meet the town's namesake.$B$B<Ros'eleth glances around.>$B$BMost young high elves outgrow the 'I wanna be a Farstrider' phase by the time they're taken as apprentices. Then, it's onto the 'I'm going to be a magister' stage.$B$BI don't think I ever quite outgrew the Farstrider phase, to be honest. No one dreams of growing up to be a seamstress, but we can't have the Farstriders running around naked, as my mother used to say.
9494	<Kaide hisses at you.>$B$BBe quiet, or you'll bring the orcs and the Alliance down on us, you clumsy oaf!$B$BThat's right, nod your head, and when we're done speaking, you'll walk away and forget you found me here.
9495	We may be working together, but that only increases the need for discretion. Once again, be mindful of your words and actions.$B$BI can guarantee we're far from the only ones out here.
9502	Yes?  Darn it all, now I'll have to start over from scratch!
9503	Practicing!  Soon I'll be good enough to join the other summoners and take my turn inside the Shadow Labyrinth at Auchindoun.$B$BI hope that I'll get the chance to summon something big!  Maybe something as big as Murmur, though I wouldn't lose control of him!
9507	Hello, young $r.
9508	Hello, dear. I am Geyah, matron of the Mag'har.$B$B<Greatmother Geyah coughs.>$B$BIf you are here, it would be safe to assume that the portal has opened. Most of the orcs here were too young or too sick to remember the Dark Portal.$B$B<Greatmother Geyah points to the orcs around her.>$B$BMany of them were orphans or would soon become orphans. Aye, Blackhand would have it no other way. Keep the sick from the healthy. Only the strong would survive... Or so they say.
9509	They have grown up here. We kept them safe from harm. We did the best that we could in nursing them back to health. Many perished but many, many more grew strong. Like Garrosh...$B$B<Greatmother Geyah sighs.>$B$BHe has lost his heart, you know. He tells me that I am his balance. That without me, the blood lust that consumed his father and ultimately cursed our people would take him over.
9510	<Greathmother Geyah laughs weakly.>$B$BOf course not, dear. But it's not me that has to believe...$B$BGarrosh can lead the Mag'har. He is strong and wise. All of the spirits approve of him. He just needs to believe in himself. He fears so much... He fears so deeply that if he lets himself go, his rage will consume him and all that would be near him.
9511	I wish I knew, dear. He will not listen to you nor will he listen to me. In truth, it is why I am still here. It is why I have not left with Mother Kashur. He must find his heart. Our people will not survive through the winter without leadership.
9512	<Greatmother Geyah smiles.>$B$BI am old. It is my time. When I pass, my spirit will move on to the spirit realm. It is there that I will stand with my ancestors. It is there that we will watch over our people.$B$BWhen Garad was alive Mother Kashur's duty was the same as my duty now.
9513	The duty of a clan mother is to listen. To listen to the wind and the water and the fire and the earth. To gather information for her clan in the way others gather furs to stay warm. It is the spirits that I commune with... In my dreams, Mother Kashur speaks to me like the spirits that spoke to her once... When I pass, I will speak to Drakia and Celestine in this manner.$B$B<Greatmother Geyah smiles.>
9515	Here are more of the incendiary devices, $N. Be careful with these, they can cause a great deal of disruption to time if used improperly.
9520	We need to figure out what this shadowy group is doing here at Grangol'var Village!
9521	We've a duty out here, $g boy : girl;, to see to it that we don't let anyone surprise us.$B$BThat means proactive action!
9522	I must have made a misstep somewhere to be assigned here.
9546	Have you honed your skills enough to learn what I have to teach?
9563	Welcome to the Royal Exchange Bank, $g sir : ma'am;. How may I help you?
9564	Thank you for choosing the Bank of Silvermoon. What may I do for you today?
9566	Yes, $t citizen : citizen;, what matter of import do you have to bring to my attention?
9568	Hi!  Do you think you might help me to get out of here?
9574	Yes?  What is it?
9577	There is nothing to see here. Move along.
9583	Don't look so surprised to see me here, $r. The coming of the draenei and their alliance with my people was foretold by Kurz the Revelator.
9587	Please, don't say anything to me. I don't want to get into any more trouble with them.
9591	We've just arrived here and already we've buried too many of our friends and comrades.
9595	If you are not here to help the cause, get out.
9596	With your help, we might be able to win this thing!
9597	Tarren Mill lies beyond these trees. The commotion at Durnholde should give us a little time to find Taretha before the entire countryside is flooded with human soldiers. Let's check the nearby barn, then head into town.
9599	I can instruct you in skinning.  Interested?
9610	Thank you for helping Thrall escape, friends. Now I only hope you can help me as well. I awoke this morning to find myself trapped in this magical prison. A strange wizard told me that I would have to stay here for a while.
9613	Yes, friends. This man was no wizard of Dalaran. His clothes looked quite foreign, and his accent was unfamiliar. All he could mumble about was time this, time that. You'll have to find that wizard and convince him to release me.
9614	I'm glad Taretha is alive. We now must find a way to free her from her magical bindings.
9615	As a representative of the Lower City, I'm here to put forward our case that Auchindoun must be cleared of its Shadow Council infestation.  That is, if we're to have any hope for a future and stave off the possibility of a cataclysm greater than the creation of the Bone Wastes!$B$BAll of our peoples have suffered too much already.  I am here to see to it that the suffering stops!
9618	If you be wantin' ta rest here, ya just need to ask!
9619	Thank you for your help in making the salve, $N. Once it's had a chance to dull the pain, I'm going to see how far I can get on this leg.
9620	Welcome to Garadar, stranger. Are you looking for a place to rest?
9621	Ah... another shaman seeks enlightenment, perhaps? Are the spirits speaking unclearly? Do you wish my help in seeing what lies before you?
9622	I am Skaltesh, guide to the shaman seeking enlightenment here... but even those who follow different paths can be shown a thing or two. Do you wish to see?
9623	Drink from this vial, and the fog will be cleared for a short time. Go with the spirits, my friend.
9625	
9626	Greatfather Winter leaves toys for everyone under the tree in Ironforge during the feast of Winter Veil!
9630	My sister Silanna is naive to the growing danger in these woods. But like it or not, as soon as I get this wagon loaded we're moving within the city walls. $b$bIt appears that I've got more bags here than I need. Perhaps you could make use of them.$B
9631	Haven't got much time to talk, $r. That is, unless you're willin' to help with this mine trouble.
9632	Can't thank ya enough fer helpin' with the mines. Now, it's just a matter of convincing the miners to get back to work.
9634	<Isfar sighs.>$B$BA couple of treehouses don't make a home, but it was vast improvement over the Sethekk Halls.$B$BComfortable as it was in Shattrath, I can't bring myself to return to my true home in Skettis without my sister. She's still trapped in the Sethekk Halls, held prisoner by our older brother.
9636	Now's our chance! Let me out of this cage!
9637	The Ring of Trials was once of place of great glory and honor. But then, the Steamwheedle Cartel came, with their wagons of gold and quill pens sharper than any orc axe...
9638	The Sethekk believe themselves to be the true and most loyal followers of the master of all arakkoa. Do not ask about the master, $r, for his mysteries are for the feathered people alone.$B$BThe Sethekk interpreted the destruction of Auchindoun to be the arrival of our master on this planet. They set out for the ruins, taking with them the relics of our greatest hero, Terokk.$B$BThey still seek the master in the temple's ruins, but I came to see through their lies. I am no longer one of them.
9639	When I was last in the halls, Talon King Ikiss carried Terokk's Quill with him, as a sign of his authority.$B$BMy brother, Darkweaver Syth, wore Terokk's Mask during our rituals.$B$BAs for the Saga of Terokk, there's no way of knowing exactly where it is, but they usually kept it at the center of one of their rune circles in the great vaulted halls.
9640	'Talon King' Ikiss is one of the leaders of the Sethekk, along with my brother, Darkweaver Syth.$B$BIt was they who led the exodus of the Sethekk from Skettis to the ruins of Auchindoun. In the beginning, Ikiss was a charismatic leader, but he has descended into madness.$B$BNow, he openly proclaims that he is Terokk reborn! He truly expects the arakkoa to bend knee to him as their ruler. Can you believe his arrogance?
9641	He is the greatest hero the arakkoa have ever known.$B$BIt is said that in ancient times, he built the city of Skettis with his own claws. He was our greatest champion and defender, but he left us when we turned away from the veneration of Rukhmar.$B$BWe came to worship a new master, one who promised us untold power and status in the cosmos.$B$BThere are some who say that Terokk and Rukhmar are one, and he withdrew his presence from us when we turned away from him.
9642	All muscle and no brain, that's what peons are! They're great when you can motivate them, but they have to be 'kick' started, if you know what I mean.
9643	Like anything that you see, $c?
9644	If you have the money, I have what you need.
9645	Take a look around and let me know if there's anything that you're interested in.
9646	Take your time, look the weapons over.  I also repair weapons and armor if you need such services.
9647	I have just the thing you need to cast your spell.
9649	Are you looking for reagents or poison supplies? If so, you've come to the right place!
9650	I sell wares that crafters need. Just the basics, nothing fancy.
9651	
9652	Are you lost? Most of the town's vendors are situated near the center of town.
9653	I carry odds and ends, but mostly just odds.
9657	It is regrettable that, among our many enemies in Hellfire Peninsula, the orcs of Hellfire Citadel stand among them.$B$BBut... who better to challenge and hone the Horde... than orcs?
9659	Good to see you again, $N! Just a few more adjustments and the trajectory of the jump will be perfect!
9662	The Lunar Festival celebration being held by the druids is taking place in Moonglade. If that's too far for you to travel, they are offering transportation from the moonwell at the Park.
9688	Go to Ironforge's Mystic Ward and speak with the night elf druids there. They can transport you to Moonglade to join in the Lunar Festival celebration.
9692	The celebration of the Lunar Festival is in full swing in Moonglade. You can make the trek, or the druids in the Cenarion Enclave are offering transport.
9694	I have traveled countless worlds, but I have never seen as enjoyable a celebration as this feast of Winter Veil. You should travel to Ironforge, the dwarves' great city, to see it for yourself.
9696	The druids of Azeroth hold a great celebration in the Moonglade. If you find the lunar festival revelers in the city, they can transport you there.
9700	If you find the lunar festival revelers in Silvermoon, they can transport you to Moonglade to partake in the celebration.
9702	You'll find Greatfather Winter in the center of the Valley of Strength. Just look for the tree.
9706	The celebration of the feast of Winter Veil is a source of great warmth during the cold seasons, and its heart is in Orgrimmar.
9710	We still go through the motions, but the feast of Winter Veil feels empty now. In Orgrimmar they have the true celebration.
9712	To many of the Forsaken, the moon now holds the place in our hearts where sun once resided. However, if you choose to join the celebration, go to Moonglade in Kalimdor. You'll find druids in the throne room above Undercity that will transport you there.
9713	You - come here. Are these blades not the finest quality? Surely you wish to purchase from me. You will not find such workmanship and care wrought into such weapons anywhere else, $r.
9714	What are you staring at, $r?
9715	Go to Ironforge's Mystic Ward and speak with the night elf druids there. They can transport you to Moonglade to join in the Lunar Festival celebration.
9716	The most amazing of the Lunar Festival parties is in Moonglade. Don't walk there, though, the druids in the Valley of Wisdom can transport you.
9717	Greatfather Winter can be found in front of the Ironforge bank. The tree near him is where presents are given out.
9718	You'll find Greatfather Winter in the center of the Valley of Strength. Just look for the tree.
9729	The untamed plains of Nagrand offer some of the best hunting I've ever experienced. 
9730	Do you like fish, $r? I have fish here. If you like fresh fish, the freshest, come and sample my wares.
9734	Get out of my face, kid! Can't you see that I'm training? That's right, yours truly is going to be the next Warmaul champion.$B$BYep, I'm almost ready for the Ring of Blood up north in the old Laughing Skull Ruins. But don't even think about it, kid. You're way too weak. Gurgthock, the ring announcer, wouldn't even let you peek inside that ring let alone fight in it.$B$BNow beat it before it beats you.
9735	Well look at you. Aren't you big and tough... Maybe you think you're tough enough to step into the Ring of Blood and face the Warmaul champion?$B$B<The pitfighter laughs.>$B$BNot very likely but if you ever wanna test your strength, the Ring of Blood is far to the north against the mountains dividing Nagrand and Zangarmarsh. Gurgthock runs the show at the old Laughing Skull Ruins and he also dispenses the prizes. Speaking of prizes, I hear the prizes this season are incredible!
9738	The interrogator is trying to find out what these blood elves are doing here in Nagrand. From what I hear, they're after crystal powder residue from Oshu'gun, the diamond mountain to the west.$B$BNo doubt to use in some insidious scheme or concoction...$B$BIf you are looking to help our cause and stop these blood elves, the conflict is happening right now to the northwest at Halaa. Blood elves and those Hand of Argus soldiers are battling! Join in and show them what's right!
9739	Draenei have come back! This group jumped two of my best wolf riders as they were out patrolling the western roads. Needless to say, we were victorious in that skirmish.$B$BNow I'm not sure what's going on but from what my scouts tell me, there are blood elves and draenei all over Halaa. I'm no blood elf lover but if it's one thing I hate it's a draenei. If you see draenei or any of their allies at Halaa, be sure to put a boot in their backsides for me.$B$BHalaa's to the west... In case you want to go now.
9749	We already have control of Twin Spire Ruins! Get out there and defend it!
9750	We already have control of Twin Spire Ruins! Get out there and defend it!
9752	Shadow Hunter Denjai uses this board to post important announcements and news of bounties on the foes of Zabra'jin.
9755	Ahh, ya couldn't resist, could ya? Want to be better, stronger, faster? Each one of these amulets be guaranteed to do just what I say they be doin'. Step up and buy one of these miraculous baubles! Cheap at twice the price!
9766	Welcome. Will you take your rest here, or perhaps a meal?
9769	We must discover what's behind the mystery of the giant crystal that fell from the heavens on Fallen Sky Ridge.
9770	Sometimes the straightforward approach to a problem is the best.
9771	If you're ever captured by the Legion, tell them \\"Xar il romath da tidesbi.\\" They will kill you instantly for insulting their god, saving you intolerable torture or worse...
9774	We're here to protect Gadgetzan interests in Un'Goro and that's none of your business.
9775	Hellfire Peninsula is a shattered realm - ruthless and unforgiving to its inhabitants. Be sure to repair and stock up on supplies before venturing out.
9777	Keep your voice low and your eyes open, $N. We're surrounded by enemies out here.
9780	You should recieve a pack of incendiary bombs from Erozion before I fly you to Durnholde. You wouldn't want to waste time, after all.
9805	She's a beaut', isn't she? Sky'ree... the faithful gryphon of our commander. Kurdran himself, he holds his audiences in th' stronghold. I care fer our Sky'ree here when he's busy. Gorgeous creature, she is; as strong and fierce as they come. She'd die fer Kurdran, she would. A more loyal soul ye've ne'er seen.'Tis an honor to care fer her, it is.
9826	'Netherstorm' was not always as you see it now.$B$BThere was a time when this crumbling land was known as the Plains of Farahlon. Little of those days has survived the evil that has taken hold here.
9827	$C, hold your attack, this is just a disguise!  I'm a spy working for the Lower City coalition out of Shattrath City.$B$BI hope you're here to help!
9828	Archmage Vargoth enstrusted me with his staff when he told me to flee from the blood elf attack on Violet Tower. I did as he told me, hoping to take refuge in the old draenei settlement of Arklon.$B$BThere was to be no respite. I had walked right into the leading edge of a Burning Legion force. The demons wrested the staff from me, but I managed to escape with my life.$B$BThough my master knows nothing of my failure, it still shames me.
9834	Long ago, in a dimension of the cosmos unfathomable to mortal minds, there was born - if such a term can be used for it - a being of such unbelievable power that its very entrance into existence shattered all reality around it.$B$BKnown only as Murmur, it was the essence of sound, and to hear it speak was to know death eternal!
9835	Existing only for chaos, its slightest whisper meant the destruction of whole worlds!$B$BYet still, there were those that would try to worship this mindless being.  There were even those more insane who dared to think to control it!
9836	The musty pages of the codex seem to magically turn themselves, guiding your attention to a specific chapter past horrors no mortal eyes should ever perceive.$B$BThe book opens to a page that somehow feels 'right,' yet so very wrong.
9837	And lo, how the mighty fell trembling at its feet, fearful that it might direct its words upon them.$B$BBut still did these charlatans, these worshipping pretenders to a non-existent religion, rail against the inevitable in a vain attempt to control their 'god.'  Uncaring, and likely not even noticing them, Murmur yawned and they knew oblivion.$B$BYet one somehow managed to survive, and in his insanity found a way to bring Murmur into the world.
9838	A mortal possessed of arcane and dark knowledge that none could surpass, he devised a method to enhance his summoning through the capture and use of souls untold.$B$BWhole civilizations were brought to extinction through his soul devices to fuel the ritual through which he and his conspirators would bring Murmur into their world.
9839	And summon forth Murmur they did.$B$BPowerful magics of containment and silencing were employed, held together by the constant supply of souls being fed into them.  Yet still they could not control the beast, could not bend it to their will.$B$BThese mortals began to devise different strategies, and one after the other they all failed.  And in so doing, they weakened the rituals, accidentally giving Murmur the slightest modicum of freedom.$B$BIt was all that was needed.
9840	Only this book survived the cataclysm that destroyed their world.  Those proud and foolish men who thought to control a cosmic being of untold power.$B$BWould you, the possessor of the codex, do the same?$B$BHave you devised a foolproof method to summon forth Murmur, or any of the other entities cautiously whispered of in these unhallowed pages?$B$BWe shall see.
9841	Hey there!  Good to see a new face - I don't get many visitors and the technicians aren't very good conversationalists.$B$BI bet you're on your way to Area 52.  Am I right?
9844	Rocket-Chief Fuselage, commander of B.O.O.M - the Braintrust of Orbital Operations and Mechanics - at your service.$B$BAre all systems go?!  It looks like the X-52 Nether-Rocket still needs a lot of work!$B$BCome on people... we're T-minus NEVER here!
9845	Welcome to the Allerian Stronghold, $N.
9846	This is delicate work out here, you know?  It can't just be rushed, or something's likely to get broken.$B$BLike Fuselage's head!$B$BYou might be wondering about my bots?  I'm always working on the Mk. I, and the Mk. II gained sentience for a split-second before his brain capacitor blew out and he went insane!$B$BI decided to skip III and IV, and went straight to the Mk. V - my pride and joy!
9847	Be careful among the ruins, $c. The Kirin Tor spirits you find there will not recognize you as a friend.$B$BThe custodian and I are the only ones whose spirits retained a strong enough tie to this place to preserve our full identities in death.
9848	Kirin'Var survived 20 long years and countless orc assaults, but it could not withstand the forces of Kael'thas. A man who once called himself a member of the Kirin Tor murdered all of us, save one.$B$BArchmage Vargoth survived the attack, so Kael'thas imprisoned him within the Violet Tower, warding it with a magic that forbids the passage of any of the Kirin Tor.
9853	You read wanted poster to Grek?$B$BGrek want to help!
9854	Hello, what business brings you here?$B$BThis is an orphanage for the children of Outland who have lost their parents and have no one else to look after them.$B$BPerhaps you are here because you are considering adoption?
9863	What's your pleasure?  Pull up a seat and knock one back.$B$BI'm Boots, lead mixologist for B.O.O.M. and bartender extraordinaire!$B$BIf it's got kick, Ol' Boots can give it to ya.
9868	Are you the correspondent from the Gadgetzan Times? If you just follow me, I'll show you my experimental apparatus...$B$B<You tell the magus that you're not the reporter she's expecting.>$B$BOh, you're not? Well then, if you need reagents, find what you need and don't tarry. I'm expecting someone.
9869	Radiation?!$B$BNo, you don't need to worry about that!  Sheesh, the things that people believe these days.$B$BSo, what do you think of our operations down here?  State of the art, baby!  You better believe it.
9872	There are two prominent bills tacked up on the board here; one from Papa Wheeler and one from Rocket-Chief Fuselage.$B$BPapa's looks like it's a wanted ad for a machine part.  The rocket-chief's has something to do with a bounty on the head of an immense mountain giant!$B$BThe details for both are provided in very small goblin handwriting, which is, of course, barely legible.
9873	There are several prominent bills tacked up on the board here.$B$BHowever, the fine-print indicates that you're not quite ready for either of the tasks at hand.  You should definitely check back later!
9875	Shredders?!  They just won't cut it anymore.  They're so yesterday!$B$BIf we're going to build rockets - if we're going to get the X-52 off the ground - we need better tech!
9886	What is it that you want, $r?
9894	What's an \\"Ologist?\\" A better question might be what isn't an \\"Ologist.\\" It means I study everything! In fact, I'm so well versed in \\"everything\\" that I'm guaranteed to be the most intelligent ethereal you'll ever meet - or your money back.$B$BApologies. That's the dealer in me talking...
9895	I'm neither slim nor shady. As a matter of fact, I find both references insulting.$B$BNow, get out of my sight before I plant my staff up your backside.
9901	<The image's head blurs as it turns to take in its surroundings.>$B$BIf you had seen the Plains of Farahlon, you wouldn't believe this is the same place. Mere months ago, these fields would not have looked out of place in Westfall.$B$BAll that is gone now, but how and why?
9902	The orb behind me was once capable of glimpsing into the happenings on Azeroth.$B$BKael'thas's curse changed all that, of course, but during our years of isolation many of the mages found solace in its images.$B$BSome scried to remember; some scried to forget. 
9903	If you've been sent to kill me, please take a number and wait your turn.
9904	Keep it down!  I don't want them to see me over here.$B$BOoh, this really burns me up!  Who do these ethereals think they are?$B$BThis is MY claim!
9905	Please leave me to my sadness.
9914	That child gives me chills. He stands there all day long communing with his grandfather. He'll then turn to tell his mother what the grandfather told him and she - of course - just smiles and nods her head.$B$BLambs! Lemmings! All of them!$B
9918	If you become a friend of the Lower City, perhaps we can do business?
9919	Can you believe this ethereal technology?!$B$BI'm sure glad they let me stay out here with them.  I'm gonna learn a lot... and maybe get some of it for myself, too!
9923	Busy, busy!  So much to do, so little time!$B$BNow where did I put that pyrospanner?  I know it's around here somewhere... I burned my fingers on it just a moment ago!
9925	Knowing a little magic comes in handy in this line of work.  Illusions can't always fool everyone, but they're usually good enough to get the job done.
9926	What are you doing here?  Shouldn't you be working on the energy pipeline?$B$BWe've more than doubled the amount of energy we're sending to Tempest Keep and can't afford anyone loafing.  We don't want another Ultris to happen here.
9927	Manaforge Ultris, of course!  Where have you been?$B$BThe manaforge was overloaded and created a huge explosion.  It left a tear in reality and now void creatures have been pouring in through it.  You can see them all over the place towards the northeast.
9929	You ought to feel safe here; we've stepped up security at this facility after the attacks on Manaforge Duro.
9930	Manaforge Duro is the closest facility to Tempest Keep, so it handles most of the load.$B$BAs you should know, overloading these manaforges causes leaks in the pipelines.  The emanating energy attracts unwanted mana creatures.  We've had mana creature infestations at many leak locations; Manaforge Duro is being hit the hardest at the moment.
9931	Working with this technology is a huge headache.  Everything is constructed in such an alien way.
9934	Don't they teach you new recruits anything?  These manaforges were built from parts of Tempest Keep designed to siphon energy from the nether.$B$BThe naaru used this technology to power their vessel during its travels.  Some said the technology might not be safe to use on land.  They were promptly silenced.
9936	It's my passion, you know. In life and in death, armorcrafting is what I love. Please, treat me as if I were a living draenei, stranger. Let me know what it is to feel again... Allow me the honor of repairing your items.
9937	The Consortium will exact its revenge upon the Zaxxis betrayers!
9939	$N, the Sons of Lothar have fought here, on the Hellfire Peninsula, for two decades.  We are beset on all sides by indigenous orcs and hellish demons of the Burning Crusade, and though our hearts still beat fiercely, years of war have reduced our numbers.$B$BYou, and the influx of Azeroth's new generation of heroes, are a welcome sight indeed!
9941	Orcs. It seems I've been fighting them all my life.$B$BTwenty years ago we shattered the Horde and tore down the walls of their Hellfire Citadel. We drove the vile greenskins to the very brink! After that, other than a few skirmishes the broken orcs never again posed a threat to us.$B$BUntil now. $B
9944	The men and women of Honor Hold have shed such blood and have lost their youth in this monstrous land... and yet they still hold their spirits high!$B$BNow, you and your cohorts from Azeroth can help us turn the tide.  You give us hope that we may one day return to our homelands.
9948	My younger brother here is quite the rising star in the Consortium. Of course, he's too modest to acknowledge it.
9949	When he says, 'younger brother,' he fails to mention that we're twins. He's really only older by a couple of minutes.$B$BDon't let that 'rising star' bit of his fool you. I'll never be a trader of the same magnitude that he is.
9951	Hail to you, $r. What I am doing here is a story for another time. Oof, that was a bad one.$B$BMy brother and I are stuck here, between our time and the present. We dare not leave for fear of causing a temporal paradox. Patiently we wait until the dragons restore us to our proper timeline.$B$BHow long has it been you ask? I'm not sure really. Ask my brother.$B$BCare for some cheese?
9953	No, you aren't hearing things. I actually do have the voice of a young orc woman. But you listen here, $g boy:girl;, time travel does strange things to a body.$B$BBy the way, it's 250 years.
9954	Yep, I've been stuck here for as long as I can remember.$B$BIn my former life, I was an armorer. Perhaps I can fix something for you?
9955	Finally, someone came down to talk to me! Want to hear some of my rhymes?
9956	Walking down the street! Looking at my feet! Watching the leaves, fall off of the trees!
9958	This ethereal teleport pad is covered in brightly colored buttons and switches, but seems to have fallen into disuse.
9962	Smokeywood Pastures has set up shop in Orgrimmar and Ironforge. I wonder what they'll dream up this year?
9964	The druids are holding a great celebration of Lunar Festival in Moonglade. If that's too far to walk, they're transporting people from the big cities.
9968	I've never seen anything like these nether dragons. They seem to have inherited their sire's temperment, but they have become something entirely different.
9971	There are only 3 kinds of people in this world: competitors, customers, and employees. Competitors are to be crushed ruthlessly, customers indulged, and employees strictly supervised.$B$BIndependent contractors are a myth.They want to be paid better than employees, but treated like customers. Never trust one who calls himself by that title.
9978	It is good to see you again, $N. Would you like me to take you to the master's lair?
9979	Arathi Basin has been overrun by The Defilers.  Will you help us, $N?
9981	Go, $N, into Arathi Basin! Slay, SLAY, as you've never slain before!
9982	The entrance to Warsong Gulch stands before you. Will you fight the wretched Alliance there?
9983	Well met, $c. Even now, the Horde attacks Warsong Gulch. Will you fight alongside the Alliance there?
9984	What are ye doin' here?! Get yer chatty self ta Alterac Vallery, where ye're needed!
9985	BOAR'S DUNG! Why must I stay here to guide others to Alterac Valley, when I could be fighting there myself? You! Have you come to fight the Alliance?
9986	The forest sings with the seeds of change.  Our new friends, the draenei, are here, and we will help them to build a place of their own.
9990	I've arranged for your flight to Manaforge Coruu.  Are you ready, $N?  You will be dropped off behind enemy lines so make sure you bring everything you need.
9991	Another soldier on $ghis:her; way to Honor Hold... by Kurdran's beard, they can use the help!
9994	There is something that you wish to buy?  There is something that you wish to sell?$B$BThis is why we are here, my friend.$B$BPlease, tell me your pleasure.
9996	Throm'ka, $gbrother:sister;! Welcome to Outland. The Horde needs all the strength it can muster in this broken world. I promise you, if it's glorious battle you've come seeking, you'll have your fill of it here.
9997	Make it quick, $c - we've got a war to fight here, or hadn't you noticed?
10001	Ah, welcome back, hero. You have returned to protect the Guardian once more? Do not forget to take a chrono-beacon with you!
10002	Greetings, $N. Proceed with caution...
10005	Throm'ka, $c. You must be new. You look fresh and unspoiled by the horrors of this land.$B$B<Sergeant Shatterskull spits into the dust.>$B$BThat'll change.
10006	Our Expedition made it safely through the Portal and set up a new base called Thrallmar. Yet as you can see, the Burning Legion moved in and cut us off from our brothers. Clearly, the demons hope to retake the Dark Portal and prevent us from gathering reinforcements from Azeroth.
10009	My brothers in Stormwind told me not to join the military... I'm glad I didn't listen to them!
10011	Hawkstriders are noble creatures.  Make sure to always treat yours well; there are fewer things more dangerous than an angry hawkstrider.
10012	I am sure that, with our help, Botanist Taerix will be able to find solutions to our problems.
10018	Heading to Outland? Visit Vixton Pinchwhistle in Netherstorm's Area 52. As the Steamwheedle Fighting Circuit's official Arena Vendor, he has all sorts of incredible items for sale to those with enough Arena Points.
10019	Feel like helping me to take down the warp-gate in that Burning Legion camp to the south?
10022	These people arrived from Shattrath a few nights ago and they haven't stopped arguing since then.$B$BI'm glad to see that hasn't turned you away, I was beginning to think they were scaring off potential customers.
10025	Draenei forces and their Alliance allies are engaged with the Horde in the Eye of the Storm in Outland. Will you join them in an effort to turn the tide of battle in our favor?
10026	The Horde must not allow the draenei and their meddling Alliance to control all the mana cells in Outland. Will you join the blood elves in their assault on the Eye of the Storm?
10027	Hello, $c!  Are you reporting for a flight mission?
10031	If you've been to Zangarmarsh, you might've run into a fellow named Daniels. You know -- wears a strange helmet, only answers to \\"the Specialist.\\"$B$BOf course, I taught him everything he knows.$B$BDon't let the fine clothing fool you. I'm still a rogue at heart. Daniels and I spent a lot of time in the trenches together, but that was before I retired. As far as I know, he's still out there, giving 'em hell.
10039	$N, please make sure that you tell Gahruj of our success.
10040	Emissary Taluun brought me with him hoping I could teach our new allies about the elements of this world... but no one will listen.
10042	While the focus of the Sha'tar remains on Shadowmoon Valley and Illidan, we cannot ignore the threat that Kael'thas Sunstrider presents.
10044	I grow bored of guarding Ambassador Sunsorrow, $n. Care to spar a bit? Perhaps one of us will learn something.
10045	As you approach the console the access crystal you have with you begins to hum softly and pulse with light.$B$BA rush of information flows into your mind and all of a sudden you're aware of the manaforge's energy production levels, its stability and its output to different pipelines.  The console awaits your command.
10047	Hands off the cloak! Yes, yes, I know that you want one too. Everybody wants one of my cloaks. Believe me, person of low moral and social standing, one day I will make my fortune from the sale of my cloaks. Everyone from here to Ironforge will know the name of Bartolo Ginsetti. The Ginsetti label will be coveted by all!
10052	By Muradin's beard, $c. This land is on the brink of annihilation. I cannot imagine anyone survived here since the end of the second war.
10054	I'm looking for someone to help me with a task that is long overdue.$B$BYou look capable.
10055	The work that you did for me at the Ruins of Farahlon has got me back on schedule.  I'm assembling my team to head out there now.$B$BThank you, $N.
10056	Legion everywhere... they must be dealt with!
10057	Thanks to you, we'll be able to proceed with our plans for the Ruins of Farahlon.
10059	Missing US text
10060	The Ethereum have grown dark... twisted. Vengeance has become their only recourse and any that would stand in their way or not join their cause are considered enemies. Many saw that the Ethereum were plummeting into madness and left. Several of the Nexus-Princes of the Ethereum council abandoned the Ethereum to form other groups and factions with different goals. The Consortium are one such example of an off-shoot group. The Protectorate another... 
10061	Missing US text
10062	Yo. I'm Vixton Pinchwhistle, official Arena Vendor for the Steamwheedle Fighting Circuit. If you've got the rep, I've got the goods that'll make your mouth water.
10063	If you're feeling queasy, speak with Pestle.  He might have something for motion sickness.
10064	<The apprentice occasionally looks over his shoulder, apparently responding to sounds that you can't hear.>$B$BGood day, $N. Pardon me if I seem distracted, but I'm in the middle of a job for Farmer Natin. I want to have all of his horses shoed by the time he returns from the town hall. What can I help you with?
10065	Agent Ya-six and I were given a high priority mission from Protectorate command to eradicate all signs of void creature infestation at Ultris. These were to be tactical strikes. Our last hit before returning to the Protectorate Watch Post was to be on a void lord named Arconus who had been getting fat off the fleshlings of the area.$B$BUnfortunately, we arrived a bit late. Ya-six and I got separated in the firefight with the flesh beasts. Now he's trapped inside, pinned down behind enemy lines.$B
10069	Be sure to visit Vixton Pinchwhistle in Netherstorm's Area 52. As the Steamwheedle Fighting Circuit's official Arena Vendor, he has all sorts of incredible items for sale to those with enough Arena Points.
10101	You want what?! I've heard something about one of those odd draenei creatures in the Valley of Heroes. Maybe she knows; I don't.
10107	Us no like paladins. Elf lady come to city, stay in Royal Quarter. Her paladin. You talk, learn paladin things.
10108	Paladin? Have you been partaking of the Apothecary's concoctions or some such thing? I have heard a rumor that some elven contingent is visiting the Dark Lady within the Undercity. Perhaps one of them might know.
10109	Your help was invaluable, my friend.$B$BI can assure you that the Cenarion Expedition will do everything in its power to counter any future tainted crystals dropped from the heavens by Illidan.
10124	It's here... somewhere... I know it. Somewhere in this library is the knowledge I'm looking for...
10125	This tower is complete and utter madness. This isn't a library, it's a huge haystack of books and I don't think the needle even exists! Now, what was I doing?
10126	Your presence here is interfering with very important work. Please leave at once. Where was I, again?
10128	WAIT $c! Your search for the next boss isn't this way. Try another way.
10152	Greetings, fleshling. I am Navuud, chief researcher here at the Protectorate Watch Post.
10153	Leaving Kael'thas was the best thing any of us ever did.  His followers are too blind or too scared to realize where he's leading them.$B$BWe, however, are not.
10179	Among ethereals, certain members deal specifically with flesh and beings of flesh. Those individuals are known as flesh handlers.
10182	If you're looking to register a guild, I would suggest inquiring within the walls of Silvermoon City itself.
10202	Ameer might be worried about what the Ethereum are doing but I'm squarely focused on the real danger here: Dimensius.
10209	In a different time and place I would've been considered but a youngling.  Here I am a seasoned combatant ready to live and die for the glory of the naaru.$B$BTen of us went into Manaforge Ara.  All the others fell to the Legion.
10210	It is time to face Socrethar, $N.  Are you ready?
10211	Did the Scryers send you to contact me?  You do not look like a Scryer at all.
10212	Speak quickly; I don't have time to waste on idle chatter. The Forsaken have become a force to be reckoned with, but there is still much to do in a given day. This city doesn't run itself.$b$bWhat do you want?
10215	All right, $c. You think you have what it takes to make it in the Steamwheedle Fighting Circuit's arena battlegrounds?
10216	Ye'll find the battlemasters around the war table in the Hall of Arms.
10217	You will find the the battlemasters gathered at the Warrior's Terrace.
10218	You'll find the battlemasters in the war room of Stormwind Keep.
10220	Go to the Hunter Rise. You will find the battlemasters there.
10221	You will find the battlemasters inside the Hall of the Brave in the Valley of Honor.
10222	You go to Royal Quarter. They all there, in circle around room.
10224	Oh yeah, I got muffins!
10229	Fleshling, I am Captain Saeed of the Protectorate and these soldiers that stand by me are my avengers. We await orders from the fleshling who destroyed the void conduit. On that fleshling's word, we will make our way up to Dimensius's lair and wait for the word to make a final strike!$B$BToo long it has been... The void lord will soon face our combined might!
10230	The nether drake looks upon you approvingly.
10232	This is it, $N. We charge on your orders! Just say the word and my men and I will engage!
10233	Welcome to Eco-Dome Midrealm, traveler. I would warn you to be wary of dealing with that goblin, Shauly. I don't believe I've ever heard anyone use the word \\"buddy\\" as punctuation before.
10236	If you're going to come out here, make yourself useful because the shadowstalker over there isn't doing much.
10237	The Battle of Mount Hyjal is one of the most well-guarded events of this timeline.  Should an intruder alter its outcome, the impact would extend to all subsequent moments in history.$B$BAs the Aspect's prime mate I'm far more in tune with the flow of time than other bronze dragons.  I recently sensed a minute ripple in time emanating from the events surrounding the Battle of Mount Hyjal.  Someone or something is attempting to change this timeline and they must be stopped.
10239	What are you after? Speak up. I'm not about to trust you with one of my Elekks until you prove your dedication and friendship to our people.
10245	Our work in the Living Grove must not be endangered.  Our very lives hinge upon its continued health and growth.
10247	If I heard correctly, you're already doing good work for Sylvanaar.$B$BKeep it up and maybe we'll be able to keep our home here.
10249	Go and rest, wanderer. Our fires are yours.
10250	It is here that Gul'dan severed the tie between orcs and the elemental spirits. His unquenchable thirst for power could not be satiated with the complete annihilation of the draenei. He had to also destroy Draenor, razing the land and siphoning all of its energies for use in his war.$B$BNow all that is left are remnants of his madness.$B$BLook to the altar, $r - the land is forever haunted...
10251	I honor my ancestors in the time-honored shamanistic tradition.  We must never forget the sacrifices that they have made so that we can be here.$B$BAnd we, in turn, must make the necessary sacrifices so that our descendants will have a future.$B$BWhat brings you to me, $c?
10252	It was not so long ago that we had to wrest control of Thunderlord Stronghold from the nearby ogres.$B$BYou are here to help us maintain our defenses?  I know that Gor'drek is looking for assistance.
10253	How do you like the war, $n?  Just remember why we're here...that makes the fighting, and the dying, a lot easier.
10255	Expedition Point is a tough place to be stationed, but it's critical to the defense of Honor Hold.  The information gathered here, and the engagements our soldiers make against the Legion and the orcs of Zeth'Gor, are invaluable to the Alliance's Hellfire campaign.
10256	I hear that you've already begun to pull your weight around here.$B$BGood.  I was worried that we were going to have to 'convince' you to help out.
10257	The skin stretched taut between the bones is a call to arms against the main defender of the Alliance's Sylvanaar and the Living Grove to the west.
10258	Well met, I'm Azimi! I often make the walk out here to sell the men fresh fruit and water. Are you hungry, or perhaps thirsty?
10259	Bah!  Do I look like I have time for idle chit-chat?$B$BDo I?$B$BBe quick about your business.  There are ogres to be killed!
10266	Welcome to the Cenarion Refuge, $n. I've been instructed to offer you basic supplies for purchase, should you need them.
10269	Are you ready to fight the Stormpike Guard in Alterac Valley, $n?
10271	Borgrim might be correct.  Maybe we do need to take a break.$B$BBut now that we're here, I'm eager to get my hands dirty and study what this land has to offer.
10272	$n, I am pleased to see you. Our dwarven allies require our assistance in Alterac Valley. Will you help them?
10276	Even now, free-willed undead battle the League of Arathor in Arathi Basin.  Will you aid the Defilers in defeating the humans and their Alliance allies?
10277	Throm'ka, $n.  Warsong Gulch is in need of heroes such as you.
10279	Our friends in the Alliance gather to fight alongside the Silverwing Sentinels in Warsong Gulch. Will you travel there to help them?
10280	Greetings, traveler. I am Oronok. Please, sit by my fire and warm yourself.$B$BBeware the ravenous beasts of the shattered shelf below us!
10282	Do not forget, $c, battles still rage in Azeroth. Will you return to help the Horde in Alterac Valley?
10283	Throm'ka, $c. Did you know our fight with the Silverwing Sentinels in Warsong Gulch continues still? Your presence would be welcome there...
10284	I have traveled far in search of a way to ultimately defeat the League of Arathor in Arathi Basin, but that loin-clothed lummox Adam Eternum hounds my every move.$B$b$BStill, if slayers such as you were to return to Azeroth, perhaps we could defeat the Alliance once and for all!
10285	How are ye? Had yer fill o' Outland, and ready ta head back ta Alterac Valley and give the Horde what for?
10286	The Silverwing Sentinels still fight the Horde in Warsong Gulch, $c. What remains to be seen is if you will return there to help them.
10287	I came to Outland hoping to discover powerful artifacts to assist the League of Arathor against the Defilers in Arathi Basin... but all I've found is this smashing magical loincloth, a ridiculous gnome sidekick, and an egomaniacal undead stalker who insists I've stolen his grey skull, or some such.$B$b$BIn any case, would you care to join the League in their fight while I continue my search?
10288	<One gets the sense that Oric is here only in a sorry attempt at comic relief and shouldn't be paid attention to, as it will only encourage him.>
10290	<It's a giant, armored, saddle-bearing attack cat. Isn't that already silly enough without it talking, too?>
10291	Only a mage can learn portal magic, $c.
10292	A mage... you seek to learn the magic of portals, yes?
10293	The Royal Apothecary Society of the Undercity is eager to aid our orc allies here, in Outland.  It is an opportunity to strengthen our bonds, and to find new specimens and compounds for study.$B$BCompounds...such as poisons.
10299	Whitereach Post is something of an unintended stop for me, to put it mildly. My clients are counting on me to deliver my wares and I'm starting to wonder if I'm going to make it in time with all the delays involved.
10300	Hey, don't open the cage!  Okay?$B$BThese ogres have got me right where I want them.
10301	I am told that the dust and heat of Hellfire Peninsula is quite irritating... I would not know, but I will trust my esteemed, and still living, allies.
10302	Forgetting elemental leatherworking is not something to do lightly.  If you choose to abandon it you will forget all recipes that require elemental leatherworking as well!
10305	You'll be purchasing no hawkstrider here until you've proven your worth and dedication to our people.$bDo not return until you are considered exalted among the blood elves. Away with you!
10306	These orcs must really be eager to stake their claim in Outland! If I told you how much they were paying for my allegiance, you'd kill me out of jealousy!
10308	If you've the gold, I can teach you how to ride a hawkstrider.
10310	You must be exalted with the blood elves before I will teach you a riding skill, $c.
10322	I came to this place because of my study into the backward culture that used to be the Thunderlord clan.$B$BThey were weak and succumbed to the lure of power that came with being transformed into fel orcs through Mannoroth's blood.$B$BI have read all of their texts.  I am particularly interested in the recovery of an artifact, a drum, an arrow and a tablet that were lost when we crushed the Bladespire ogres and pushed them back down into their hold.
10323	Ar'tor's lifeless body remains suspended in mid-air by demonic magic. They take from him, even in death...
10324	I am pleased that you've decided to take up our cause.  As a reward I will infuse a ring with the remnants of the Well of Eternity you brought me.$B$BI offer you four different paths in which to unlock their power.  Choose wisely, $N.  The sands of time flow easily in one direction and not the other.
10327	I... died.$B$BWhy am I still here? Is there no great hunting ground that I ascend to?$B$BNo... I must first complete my task. Before I can leave this world, the second part of the Cipher of Damnation must be recovered.
10329	Forgetting your swordsmithing skill is not something to do lightly.  If you choose to abandon it you will forget all recipes that require swordsmithing to create!
10338	As you wish, $N. The spirit hunter is ready.
10339	I've done my time in the trenches, and spent many years training the pups. It's good to be home. No matter what has become of it, this is my home.
10341	The ogres, they bury me here up to my neck and then forget to come back.$B$BYah, mon, funny.  Laugh it up.  Disembodied ghost head here.$B$BOf course, if you want to help me out, I might be able to make it worth your while.$B$BBut no, keep laughing.
10350	Stand up straight, grunt! You're under the command of the Kor'kron Guard now.
10354	The feralfen that dwell in Zangarmarsh have wicker baskets with clever locks on them.  Surely they would challenge even your skill.
10355	The footlockers of Kil'sorrow Fortress in Nagrand would provide a considerable challenge to even a rogue of your notable skill.
10359	Toshley's Station is the best!  The solitude and supply of strange, Outland power sources is an ideal setting for extreme experiments!
10360	Have you talked to my clone--I mean... my twin?
10363	I cannot believe they made me move my transporter out of town!   Most of the gnomes affected by the accident regained some sort of humanoid form within a few weeks and it should have been an honor to be a participant in such a grand gnomish experiment!$B$BBesides, we needed the eggs!$B
10373	Thanks for getting me out of there. I owe you one!
10378	Just a small songbook that I thought you might like to have.  It contains the lyrics to a song known as the Lament of the Highborne; the one that Lady Sylvanas glamoured from the air.
10403	You will find mailboxes within or just outside the Aldor and Scryers banks and inns.
10404	There are stable masters just outside both the draenei and blood elf inns on Aldor Rise and Scryer's Tier.
10411	Inessera is a sharp woman who carries various gems as well as jewelcrafting supplies. You can find her shop in the northern part of Aldor Rise.
10412	Lisrythe may be a bit... intimidating at first, but she stocks what you are looking for. She sells her wares outside the large library on Scryer's Tier.
10415	High Enchanter Bardolan may be found in the Seer's Library on Scryer's Tier. A grand master of the art, he is surrounded by his students: masters, artisans, experts, and journeymen.
10419	Seymour, the principal skinner in Shattrath and grand master of the trade, may be found in the lower city's open marketplace.
10421	We will fight when you are ready, $N.
10422	I AM FLUENT IN OVER TWO LANGUAGES: DWARVISH, GNOMISH AND THE VERY COMMON TONGUE OF HUMANS.  BUT I HAVE NO IDEA WHAT YOU ARE SAYING!$B$BSPEAK UP; I CANNOT HEAR YOU OVER THE GRINDING OF MY GEARS!
10423	Yeah, yeah... welcome to my station.$B$BSo, what do you think?  Pretty nifty what we've done here, wouldn't you say?$B$BMakes me glad to be rid of those stuffy elves at Sylvanaar anyway.$B$BMake yourself useful around here; there're plenty of experiments and whatnot to help out with.
10424	Glory to the naaru, $N.  The Light will soon triumph over its enemies.
10434	<Dark magic ripples from the necrolyte.>
10439	<The orc wolf's frozen, snarling mouth shivers your bones.>
10444	I'm a scientist who studies both time and sound, so I'm not quite certain how I'm supposed to think, or find the time to get any work done around here, with all of this racket?!$B$BWhy can't these fools go blow themselves up somewhere else?$B$BAh well, at least I look good.  Say, $g boy : lovely;, have I seen you around here before?
10447	To many of my people I am known as a traitor... as Illidan's lapdog.  It is best that they continue to think that for now.
10448	All rewards for services rendered to be dispensed by Warcaller Sardon Truslice.$B$BPost no bills.
10449	All rewards for services renedered to be dispensed by Warcaller Beersnout.$B$BPost no bills.
10451	Are you interested in learning the intricacies of Jewelcrafting?
10454	What do you wish to know of Jewelcrafting?
10455	Until you have mastered the Apprentice level of Jewelcrafting we shall not speak again.
10456	My knowledge of Jewelcrafting I will share with you.
10458	I wish I had more time to teach all who came before me, but alas that is not the way of things. Until you have learned all that Padaar has to teach, I cannot help you.
10459	I am blessed to be able to help someone of your skills to learn more of Jewelcrafting. What do you wish to know?
10460	I'm extremely busy, $r.$B$BWe have a terrible problem on our hands that must be dealt with at once!
10466	When you run with Razak's Roughriders, you learn a thing or two about following orders.$B$BThe first thing is that you fight until you die.  The second thing is, see the first thing.
10467	Need your blade sharpened, or perhaps a new weapon? Better safe than sorry...
10468	If it's a hammer you're looking for, you've come to the right place.
10469	$G Son : Young lady;, I'm not going to lie to you; things aren't pretty around here.  We're under constant assault by the bugs and our very way of life, our freedom, is at stake!$B$BAre you going to be a responsible citizen and help out?
10471	Splendid! Marvelous! An excellent performance!
10473	When I was young I trained hard to become an anchorite in the priesthood.  Female exarchs were practically unheard of.$B$BNowadays gender matters little - it is courage and conviction that make all the difference.
10474	If you are ready and wish to quickly return to the normal time stream, I can transport you to Andormu in the Caverns of Time.
10491	Here to help with the disturbances?
10496	Be gone, mortal! Your kind is unwelcome here...
10500	You can take a man away from the Sons of Lothar, but you can't take the Sons out of him.$B$B<The smith shrugs.>$B$BIt's hard to explain, but I don't feel like I'm meant to be at Honor Hold right now, is all.$B$BPerhaps I'm meant to be part of something larger.
10505	\\"It is too soon for you to control me, for you have recently left the game.\\"
10508	Whatever advice I can give to aid in your fight against the ogres, you shall have it!
10509	The details of the posting call for the execution of an enormous wolf.  She apparently keeps her den to the south of the Jagged Ridge, near the Horde stronghold.
10530	Greetings, $c - I'm a Commendation Officer acting on behalf of Silvermoon City.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Silvermoon City for your duty and service.
10531	Greetings, $c - I'm a Commendation Officer acting on behalf of the Exodar.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Exodar for your duty and service.
10534	We've come to the Ruuan Weald to see if we can reestablish the balance of nature to these mountains.$B$BThe interference of the arakkoa and the wyrmcult is making this a difficult task, however.$B$BLuckily, there are those like you and Samia that are willing to lend us a hand.
10535	Haha, you're back?  You don't seriously expect me to change my mind do you?$B$BGet lost.
10537	I detect a charge in your paranarbulatric region!  You must have used the Zephyrium Capacitorium lately -- you can't use it again until the charge wears off...
10538	I am here at the behest of my master, Baron Sablemane, to help the Cenarion Expedition with its wyrmcult problems.$B$BI'm something of an expert on these things.
10539	Nuaar, are you feeling well?  You don't look like yourself today.
10541	Right, the meeting.  Let's get down to it then.$B$BThe fact is that the lumber and livestock being gathered from the Ruuan Weald, which you're responsible for, has slowed to a trickle.$B$BWe need those resources, but you've allowed the druids of the Cenarion Expedition to get in the way!
10542	I don't want excuses, I demand results!$B$BYou think what we're doing here is a joke?  If we don't do this right, then not only will the so-called do-gooders come calling, but we'll be found unworthy for elevation within the ranks of the Blackwing.$B$BIs that what you want?
10543	You could at least try to sound a little bit convincing.$B$BLook, Nuaar, I wasn't going to tell you this, but I might as well because it's going to involve you, too.  Maxnar is planning an all-out attack on the druids at Ruuan Weald.  And he intends to wipe them out.$B$BIt's bad enough that we've been fighting with the Boulder'mok ogres, so we can't afford another front to deal with.  I've arranged for a temporary truce with the arakkoa.$B$BWell, what do you think?
10544	We're putting the final preparations together even as we speak.  The rest will depend upon how quickly you can organize your forces at Ruuan Weald.$B$BDo you think that you can handle that and get it done quickly?
10545	That's the spirit!$B$BI'm glad that we had this little meeting.  I feel much better about the attack now.  With leaders like you on the front, how can we lose?$B$BAlright, you have your marching orders.  Now get back to the Ruuan Weald and make it happen!
10546	Karazhan wasn't always quite as... ominous.  The darkening of Karazhan only came with Medivh's death.  Or what we believe was Medivh's death.
10547	You look like you might be needing passage across the Great Sea. Well you have come to the right place, this here is the berth of the Maiden's Fancy, finest passanger ship to travel these waters. When she arrives just climb aboard and the next thing you know you will find yourself basking on the sandy beaches of Stranglethorn.
10548	I must say, Booty Bay has the best Clam Chowder to be had anywhere in the South Seas. Oh, not interested in cuisine eh? Well then let me be the first to welcome you to the berth of the Maiden's Fancy, the finest passenger ship to travel between the Eastern Kingdoms and Kalimdor. She's due back for another trip to Ratchet soon, so make yourself comfortable till she arrives.
10549	You made it this far, grunt. There is no turning back now.
10550	Slip a little coin into the boss's hand and look what it gets ya. I love my job. Though, if I could find a way to get that little firecracker Snurk reassigned to this port....well, I can't imagine it any better. But i'm betting that you aren't here about my bussiness practices. You're looking for a Zeppelin to Undercity, am I right? Well, that's great, because it docks rigt here behind me. Oh and hey, if you see Snurk, put a good word in for me, would ya?
10551	Hey there cutie, you looking for a ride to Grom'gol? I hear it gets mighty steamy down in those jungles, maybe I could join you for a short vacation, show you a real jungle cat.
10552	Of course there's no danger in everything catching flames and exploding like a huge helium bomb. This baby will get you to Undercity faster and safer than any boat, and the view is truly breathtaking. Speaking of breath, smoking is not allowed on board the zeppelin, and fire spells are banned from being cast during the trip.
10553	Hello, overseer.  Ready for the attack?
10554	These druids have tapped a tremendous source of power!  They can turn into animals... project  lightning and intense moonlight... I must discover how they do it!$B$BPerhaps they're wearing batteries underneath those robes...
10555	On the northern dock, you can board a ship that will carry you to Rut'theran Village and Darnassus. From the southern dock, you can find passage across the Great Sea to Menethil Harbor on Khaz Modan. Safe journeys to you!
10556	<The arakkoa favors you with a haunted gaze and alternates between looking at you and looking through you.>$B$BWhat have our efforts wrought, but a greater abomination than we sought to prevent?
10557	You can find passage to Theramore from this dock. Heed my words, those lands are rarely safe to travel for people of the Alliance. Watch your step and your back.
10558	In Outland, our forces fight against the Horde to control the Eye of the Storm. It is dangerous, fighting amidst the raging energies of the Nether. Do you have what it takes to join us?
10560	$N! Come here! Surely you know of the battle that rages within Alterac Valley. We need every able-bodied fighter we can muster. Fight with the Stormpike Guard and defeat the Frostwolves!
10561	This flight takes you to the far point of the Singing Ridge.  Very dangerous!$B$BFor this one, I'm going to need a signed waiver...
10562	We're always eager for more flight data!  Where do you want to go?
10563	What is it then? Can't you see I'm a busy dwarf?
10565	While exploration in these new lands is no doubt important, you mustn't forsake Azeroth! We need you now more than ever in the fight against the Defilers. Those resources must be secured!
10566	You, $c! We require your aid! The brutish Warsong orcs are destroying the wonder and beauty of Ashenvale, and we need your strength to meet them on the field of battle. Return with us to Azeroth and fight for the honor of the Silverwing Sentinels! Will you join us?
10568	There's an old saying, \\"Give a man a fish; you have fed him for a day.  Teach a man to fish; and you have fed him for a lifetime.\\"  Of course, you might want to cook that fish and that is where I come in.
10569	Hello, $n!  How goes your adventures? My experiments are progressing nicely...$B$BBe sure to check back with me later!   I might have more test flight opportunities for you!
10570	Strength and honor, $c. We need eager soldiers like you in Alterac Valley; the territory of the Frostwolves must be defended! Will you return to Azeroth and lend your aid?
10571	$R! Yes, you! Why do you waste time dawdling in this wreck of a city when your rightful place is in Arathi Basin? The League of Arathor is ruthless in its assault; your contribution is needed, and you will be rewarded!
10572	$C, back on Azeroth, the Silverwing Sentinels hamper our progress in the woods. We need you there on the battlefront to push them back! You will earn great honor and reputation with the Warsong Outriders for helping us - join us now!
10576	The goblin Steamwheedle Fighting Circuit is beginning soon. They're holding practice matches in their arenas now, but ranking fights begin in $4262d.
10578	The goblin Steamwheedle Fighting Circuit has begun. You can find Arena Organizers selling arena team charters in Gadgetzan and outside the arenas in Nagrand and the Blade's Edge Mountains.
10579	The goblin Steamwheedle Fighting Circuit has begun. You can find Arena Organizers selling arena team charters in Gadgetzan and outside the arenas in Nagrand and the Blade's Edge Mountains.
10595	The goblin Steamwheedle Fighting Circuit has begun. You can find Arena Organizers selling arena team charters in Gadgetzan and outside the arenas in Nagrand and the Blade's Edge Mountains.
10597	<The grizzled gladiator speaks in halting Common.> What? You have a problem with me? Take it to the arena. I don't waste my time with your little \\"hordes\\" and \\"alliances.\\"
10598	Gladiators earn the right to wear equipment like mine by winning ranked arena matches.
10599	<The veteran gladiator speaks in halting Orcish.> What? You have a problem with me? Take it to the arena. I don't waste my time with your little \\"hordes\\" and \\"alliances.\\"
10600	Gladiators earn the right to wear equipment like mine by winning ranked arena matches.
10601	Yo! Have you heard about the Steamwheedle Fighting Circuit?You can find Arena Organizers selling the arena team charters in Gadgetzan and outside the arenas in Nagrand and the Blade's Edge Mountains.
10602	Hey there.  Taking a break, overseer?  We don't get to see you around here much anymore since you were reassigned to Ruuan Weald.$B$BTake a look at what I have to offer.  It may not have changed much since last we spoke, but I've got plenty.$B$BAnd don't be such a stranger!
10603	My loathing of interruptions is overshadowed only by my hatred of Gruul the Dragonkiller and his seven sons!
10604	Ranked arena matches start in $4262d. Would-be champions are already busy honing their skills and acquiring the best gear they can. Are you going to be ready?
10605	You must... free... my children...
10606	They can't keep this up! Their wings will eventually give...
10608	Ah, another $c looking to be a gladiator, eh? Good!$B$BI sell the arena team charters you'll need to participate in ranking Steamwheedle Fighting Circuit matches.
10610	Spinebreaker Post is a great place to be stationed!  The Bleeding Hollow aberrations are so close you can smell their foul blood!  What better place to gather vengeance from a clan that has forsaken its brethren and made a pact with demons?
10612	Fairweather and I are up here representing Sylvanaar's interests.$B$BThe druids have been more than accomodating, but allowing the Horde to travel through here gives me the willies.
10625	The fight against Kael'thas and Illidan continues on all fronts.  Defeat is not an option.
10631	I realize you have only recently joined us, and thus may be unaware of our traditions. In Moonglade, a tremendous celebration is taking place. This is a time of year when we honor our elders, and you are certainly invited! Travel to one of our cities if you wish to join in!
10634	The Lunar Festival is in full swing on Azeroth! Return there and honor your elders in this wonderful celebration! The main festivities can be found in Moonglade, but we've provided easy transportation from Stormwind, Ironforge, Darnassus, Thunder Bluff, Orgrimmar, and the Undercity. We hope to see you there!
10636	There are mysteries in this place that we, the orcs, are desperate to uncover.  Mysteries of our past, mysteries of our future, and mysteries that offer glimpses inside us.$B$BIt is my hope to pierce these mysteries... will you walk that path with me?
10637	There's trouble in the woods.  We must uncover its source before it is too late!
10640	Soon I will plant roots and sleep.   Before I rest there are things that must yet be done.
10641	You brought the green to my land for a short time.  It is enough.  I am at peace.  I am ready for my long sleep.
10643	Success!  I have attuned myself to Hellfire Citadel and the magic within.  Ah, such power!$B$BThere are countless fel orcs in that place... but that is not all!  I sense demonic power within those walls as well...$B$BIf you open yourself, then I shall grasp your mind -- briefly, mind you -- and take quill to parchment and record my findings for you...
10645	Our enemies surround us.  I would have a better life for the Mok'Nathal, but the forces we are at battle with have chosen otherwise for us.$B$BIf you would prove yourself worthy to the Mok'Nathal, aid us in their elimination.
10647	Puzzled by what you see, stranger?$B$BWe give praise to the spirits of our ancestors by keeping the flame of their memory alive and paying it tribute.
10649	I can instruct you in alchemy.  Interested?
10650	I can instruct you in engineering.  Interested?
10651	I can instruct you in enchanting.  Interested?
10652	I can instruct you in tailoring.  Interested?
10653	I can instruct you in leatherworking.  Interested?
10654	I can instruct you in blacksmithing.  Interested?
10655	It is good to see you again, friend.
10657	It feels good to walk about and stretch all four limbs. Is there something I can help you with, $c?
10659	Greetings, $C.  If I might be so bold, may I remind you that -- while I attune myself to the magics of Hellfire Citadel -- there will undoubtedly be Hellfire wardens biting at my proverbial heels!$B$BSo, do be an upstanding member of your Horde and play the part of the hero... and protect me!
10661	The search for my people.  Our struggle against the Alliance.  The war with the ogres and their gronn masters.$B$BAll of these things weigh heavy upon my shoulders, $c.$B$BEven I can use some help from time to time.
10664	The Deathforge is run by the Shadow Council, under the watchful eye of the Legion.
10666	Below is the aptly named Deathforge. If left to their own devices, the Shadow Council would supply the Legion with an endless stream of infernals.
10667	We know that the wyrmcultists are massing on the other side of the tunnel.  We'll make our stand here.
10669	Welcome, $N. My expertise is in the art of working with primal mooncloth. Tailors interested in becoming mooncloth specialists often ask me to teach them our ways.
10670	I'm afraid there is little I can teach you, $c. You're free to browse my wares, of course, but you will not find them of use to you.
10671	Pleased to meet you! I'm Gidge, the resident spellfire tailoring expert here in Shattrath. Not that there's any competition, but if you're interested in learning to be a spellfire tailor and haven't settled on a specialization, I can help.
10672	If you're not a tailor, I don't think any of my patterns will interest you, but you're welcome to browse!
10674	I'm sorry, $c, but my wares are best suited to those who know which end of the needle the thread goes through.$B$BI can assure you, tailoring is about far more than monogramming handkerchiefs.
10675	These Tears of the Goddess have been blessed by Elune, and their power will help you combat Archimonde's vile magics. Use their power well.
10676	They fear my words. They make an example out of me. A mockery of the one true god, Neptulon.$B$B<Skar'this spits.>$B$BRetribution comesss, mortal. The glorious hand of the Tidehunter will one day sweep through the non-believers like a scythe against a new harvest.
10677	These wastes are scarred by terrible magic.  We must do what we can to heal this great wound.
10679	Death's Door is a portal that opens upon the world that the Burning Legion uses to breed their fel hounds and other canine-like terrors.  Any time that you see one of those creatures, that is where it came from, and it passes through here, first.$B$BLately, we became aware that the Burning Legion have ramped up their summoning of these creatures through the portal.$B$BYou must shut down Death's Door before it becomes an inexorable tide, and all is lost!
10680	I came to this land to cleanse troubled spirits, but after the attack I fear that my mission has failed.  So many have been taken by the wastes.  Please, you must help them.
10686	When I first set up my rogue academy in Shattrath, it wasn't nearly this crowded. Then, the refugees started flooding in and the naaru needed every available building to house them.$B$BI've closed the doors to my academy for now, but it's not permanent. I'll find a new place to set up.$B$BThen, a new generation of rogues will learn such staples as the gouge'n grin, combat looting, and blaming someone else for breaking polymorph. And who can forget the central rule of roguery --- real rogues don't feint.
10687	I am Zarevhi of the Consortium.  My skills as a transmuter are known in a thousand worlds.
10689	Oh, no!  My Fei Fei would never take someone else's things!  He's a good dog... he just needs attention sometimes.  If you give him a treat, then you see!
10691	I used to amuse myself by accepting challenges from anyone who would offer them, but I've long since grown tired of such easy victories.$B$BFor now, I'm taking some time to get my reagent business off the ground and write a book about my experiences in Twilight's Hammer.
10705	I'm not about to train you until you're exalted in the eyes of the draenei.
10706	Oh, thank you!  The pit of blackness inside of me has been lifted!  I can see again... and I see the face of my savior!
10707	Be gone, $c!  Leave us be, or we will enter you next and show you true despair!
10718	Now that you have bested me, test your skills against each other!  Take control of either king to begin play.
10720	You wish to speak to me, $r?
10721	I have seen many dangers in these wastes.  Who knows what creatures yet lurk in the dust to ambush the unwary?
10722	You do not have enough reputation with or have not pledged allegiance to The Aldor.
10723	You do not have enough reputation with or have not pledged allegiance to The Scryers.
10724	If you seek our master of Paladin Trainer's, go to Champion Bachi. He will wait of you in Farstriders' Square.
10725	Sylann, one of the finest cooks in the city, can be found upstairs in the Wayfarer's Rest tavern. You can purchase cooking supplies from here assistant there, too.
10726	Do you mean the Silvermoon City Inn, or the Wayfarer's Rest tavern.
10727	The Wayfarer's Rest tavern is located between the Walk of Elders and the Bazaar. You can reach it from either location.
10729	The conflicts in Outland are deadlier than any I have seen.  And their most tragic victims are the children that are left behind.$B$BNow, with the threat against Shattrath from the arakkoa of Skettis, there will be even more orphans to take care of.  These children often live without the hope of a bright future.$B$BBut you have the power to do something about that.  It's Children's Week, $c, and I implore you to volunteer to bring joy and wonder into a child's life.
10730	I'm lonely.  I wish that there were more kids my age around here.  Sometimes I miss being at the orphanage in Shattrath City.
10732	Are we there yet?
10733	I am free!  But the secret... is now in peril.  Akama must be warned!
10734	Why isn't the Outland called Draenor anymore?
10735	<Morthis glances skyward.>$B$BIn a way, I envy the freedom Rook and Corvax enjoy. To be free of earthbound responsibilities is a great blessing indeed.$B$BThe future will see me on wing once more, but first there's a task I must complete.
10741	Aran has been defeated? Yes... I can sense his grip has loosened - if only just a little. But just enough to allow me to do my job as the doorman! Would you like me transport you to the Guardian's Library, $N?
10742	It is good to see you again, $C $N.  Dornaa has been asking about you.
10744	The conflicts in Outland are deadlier than any I have seen.  And their most tragic victims are the children that are left behind.$B$BNow, with the threat against Shattrath from the arakkoa of Skettis, there will be even more orphans to take care of.  These children often live without the hope of a bright future.
10745	<The druid appears to be deep in sleep, oblivious to his surroundings.>
10746	I beg you, $r, be swift. They will not stop pursuing me! I cannot escape from them, even here!
10748	Ilyenia Moonfire, the night elf weapon master who resides at the Warrior's Terrace in Darnassus, can train you in the use of bows.
10749	Bixi Wobblebonk in this very shop can train ye in daggers. If ye're still looking abroad, anyone else - Woo Ping in Stormwind and Ilyenia Moonfire in Darnassus - can show ye a thing or two. Me, I was never one fer knife fights.
10750	Ilyenia Moonfire, the night elf weapon master on the Warrior's Terrace in Darnassus, or Buliwyf, the dwarf weapon master within the Timberline Arms in Ironforge, can train you in the use of fist weapons.
10751	Buliwyf, the dwarf weapon master within the Timberline Arms in Ironforge, can train you in the use of guns.
10752	I am here at the behest of Nexus-Prince Haramad. Strange things are afoot at the Stormspire.
10753	The gnome weapon master Bixi can train you in crossbows. She's found in the Timberline Arms in Ironforge.
10754	The dwarven weapon master Buliwyf can train you in both one and two-handed axes. He's found in the Timberline Arms in Ironforge.
10755	Buliwyf can show you how to swing a mace properly, no matter the size. You can find him within the Timberline Arms in Ironforge.
10756	Woo Ping is the master of polearms. He trains his students at Weller's Arsenal in Stormwind.
10757	Staves are taught by both Woo Ping, the master found at Weller's Arsenal in Stormwind, and Ilyenia Moonfire, who trains the night elves on the Warrior's Terrace in Darnassus.
10758	There is one master of the sword: Woo Ping. He can be found in Weller's Arsenal within Stormwind.
10759	Both Ilyenia Moonfire on the Warrior's Terrace of Darnassus and Bixi Wobblebonk of the Timberline Arms in Ironforge can show you how to use throwing weapons properly.
10760	Ilyenia Moonfire, the night elf weapon master who resides at the Warrior's Terrace in Darnassus, can show ye how to use a bow.
10761	My plucky companion Bixi Wobblebonk here can train ye in crossbows. If ye're looking for other trainers, though, ye might want to try Woo Ping in Weller's Arsenal within Stormwind.
10762	Bixi here can teach ye how to lob throwin' weapons.  If Darnassus is more yer speed, talk to Ilyenia Moonfire on the Warrior's Terrace there.
10763	Buliwyf can teach you how to use axes! He's around this shop somewhere.
10764	Buliwyf, in this very shop can train you in the use of fist weapons. If his training techniques aren't your style, I hear the night elf weapon master in Darnassus, Ilyenia Moonfire, knows her way around the weapon too! She's up on the Warrior's Terrace there.
10765	Guns are a specialty of Buliwyf's! He's around this shop somewhere.
10766	Maces are a specialty of Buliwyf's! He's around this shop somewhere, grousing.
10767	If you seek training in weapons, I can provide.
10768	Ah, you wish to train abroad? I will direct you. Tell me which weapon has sparked your interest.
10770	Both Hanashi and Sayoc can train you in the use of one and two-handed axes. They can be found in the Valley of Honor in Orgrimmar.
10771	The weapon masters in the Valley of Honor within Orgrimmar, Sayoc and Hanashi, can teach you how to shoot a bow.
10772	Archibald is the master of the crossbow. He's the weapon master of the Undercity, located in the War Quarter.
10773	Dagger instruction can be sought from two weapon masters: Archibald in the War Quarter of the Undercity and Sayoc within the Valley of Honor in Orgrimmar.
10774	Fist weapons are taught by Sayoc, the orc weapon master in Orgrimmar. He spends his days in the Valley of Honor.
10775	Our gunnery instructor is Ansekhwa, the tauren weapon master on the lower central rise of Thunder Bluff.
10776	Maces are taught by Ansekhwa, found on the lower central rise of Thunder Bluff.
10777	The Forsaken weapon master Archibald knows his way around the polearm. He trains others in the War Quarter of the Undercity.
10778	Staves are taught by Hanashi, the troll weapon master in Orgrimmar's Valley of Honor, and Ansekhwa, the tauren weapon master who trains on the lower central rise of Thunder Bluff.
10779	Archibald, Undercity's weapon master, can train you in both one and two-handed swords. He is in the War Quarter.
10780	Sayoc and Hanashi, Orgrimmar's weapon masters, are true artisans of the thrown weapon. They train willing students in the Valley of Honor.
10781	Archibald da master of da crossbow. He da weapon master of da Undercity, located in da War Quarter.
10782	Sayoc, da ugly orc here, teach you daggers. You want teaching in other places, you talk to Archibald in the War Quarter of Undercity, hokay?
10783	You want to punch things, yah? Talk to Sayoc right here. He teach you.
10784	Our gunnery instructor, he Ansekhwa, da tauren weapon master on da lower central rise of Thunder Bluff.
10785	Maces, they taught by Ansekhwa, found on da lower central rise of Thunder Bluff.
10786	Da Forsaken weapon master Archibald know his way 'round da polearm. He train others in da War Quarter of da Undercity, mon.
10787	Archibald, da Undercity's weapon master train you in both one and two-handed swords, mon. He in da War Quarter.
10788	Hanashi here knows staves. If you want a sturdier instructor, go to Thunder Bluff. Ansekhwa will teach you on the lower central rise there.
10789	If you haven't come to train, step back and leave me to my work.
10790	I can't see why you want to learn something else... but I suppose I can point you in the right direction. What training are you after, specifically?
10791	Be wary of the Ethereum that surround us on all sides.
10792	Come and I will show you how to ride the finest beasts you have ever seen. You... do have enough gold to cover the cost, I trust?
10793	Welcome to the Evergrove, $c. Timeon and I have been studying the arakkoa of Blade's Edge for some time now, and we've found some alarming differences between them and their cousins in Terokkar.
10796	The true believers have lived in shame since the day our treacherous cousins in Skettis stole the book from us, shattered its tablet, and buried the fragments in their wretched city!$B$BPray that the raven will choose you to restore it, my son. Be faithful and remember always the prophecy, \\"From the dreams of his enemies shall the raven spring forth into the world.\\"
10798	You go see Mog'dorg?
10799	I seek a $g hero : heroine; of the utmost skill.  $G He : She; will gather others to save the Bloodmaul clan, and all of the ogres of these mountains from the tyranny of our gronn oppressors.$B$BReturn to me when you have learned all that you can.  But, $c, keep quiet about this until that time lest the gronn get wind of our underground movement.
10800	The Sons of Gruul must be defeated if we are to shake off our shackles and live as free ogres once more!$B$BWe must work quietly, yet quickly, if our underground resistance is to have a chance of success.
10801	I fear that Colonel Jules may only be saved through a dangerous ritual... an exorcism.
10807	Do my eyes deceive me? Is that really you, Brother Rokkaram, after all this time?$B$BIf you are looking for Sai'kkal, he walks among the crystals in the western part of the Vortex Pinnacle. He seems preoccupied with what he calls a brutish, primitive presence there, although nothing seems amiss.
10808	Ya may know a thing or two about handlin' animals, but have ya ever taken ta the skies? We Wildhammers know how ta ride the wind with the best of 'em. Fer a small fee, if ya've got the mettle, I'll train ya good and proper.
10817	You look like you may know your way around a beast that runs on land, but if you want to soar, it'll take training and dedication. And gold. You have gold, right?
10818	Fine beasts, aren't they? The wyverns we raise here are trained to handle the fiercest and strangest weather conditions Draenor has to offer. You'll find them dependable and hardy.
10821	When I grow up I wanna be a tanner!
10830	There have been some complaints filed about this... individual. I'm told he's something of a shady character. I am here to determine whether or not this business of his is legitimate... and take action if it proves otherwise.
10831	If you manage to complete a deck of Storms cards you will be rewarded with a Greater Darkmoon card of Wrath.   This will increase your chance to get a critical hit with spells or physical attacks until you achieve one.
10832	If you manage to complete a deck of Lunacy cards you will be rewarded with a Greater Darkmoon card of Madness.   The power of madness will fill you each time you slay an enemy.
10833	If you manage to complete a deck of Blessings cards you will be rewarded with a Greater Darkmoon card of Crusade.   This will increase the damage you do with your spells and attacks as you continue to fight.
10834	If you manage to complete a deck of Furies cards you will be rewarded with a Greater Darkmoon card of Vengeance.   While wielding this card anyone who strikes you has a chance of suffering holy vengeance.
10835	Be wary, friends. The Betrayer meditates in the court just beyond.
10837	Shh! Keep your voice down. The babes are sleeping.
10841	You better wake up real quick, rookie.  This isn't our cushy backyard outside of Skettis; this is the Blade's Edge Mountains!  One false move and it's crash and burn!
10848	You no make dis your home. Maybe you want eat someting?
10850	OH YEA! You want a taste of these guns, maggot? Step on in!
10854	$G Brother:Sister;, you are now considered bound by blood to the Netherwing. All of Netherwing will be behind you now! The time to strike at the heart of our enemies is now, friend! We must reclaim our lost heritage.
10855	You have done much for our cause, $N, but you may go no further until you have mastered flight. Only the most stalwart riders are able to assist the Netherwing.
10860	You must have wondered how it is that I can speak so clearly for an ogre.  It's a side effect of the crystals that grow on the terrace surrounding Ogri'la.  The ogres there gifted me with this staff, and its crystal has in turn gifted me mentally.$B$BIt is through your continued actions, at Ogri'la above, that I hope to one day be able to bring this boon to all of my ogre brethren.  You have my thanks, my $g king : queen;, for all that you have done and will do.
10862	Another one, eh? You'll never make it...
10863	Just remember that you can only pick one gathering job to do per day. Aside from that, we're always looking for more crystals. Any worthless peon can bring those back to the base camp.
10864	I got nothing new for you, kid. You've outgrown manual labor...
10866	Illidan's grasp over my tribe is strong, $N. It shall all be over soon, one way or another.$B$BAre you ready, $N?  My people's future depends on us.
10872	UDB missing US text
10877	Be quiet 'bout what you hear and see around here, $r.
10879	Grok hear dat yous da new $g king : queen; of all da ogres.  Congrat... congratu... gratz, little $r.
10884	
10887	How can I help you, $c?
10888	The pile of skulls reeks of foulness.  You fear the arakkoa have made an addition to the pile fairly recently.
10889	If you're looking for gadgets, doodads, thingamajigs, widgets, whatsis, dohickeys, or gizmos, you've come to the right place!
10892	You look familiar...
10893	My sight is filled with visions of events taking place throughout the world and ones that may yet happen. Many of them are grim, but we needn't believe they are incapable of changing.
10901	Stand at attention, grunt!
10903	A thousand curses upon you, $r!  This prison will not hold me for long!
10904	Get lost before I beat you with my booterang.
10906	Oh, ye like me eyepatch now do ya?  Well, just make sure that ya don't have ta be wearing one yerself now $g boyo : girly;.
10907	Huh?  What?  I'm a little busy here, friend!$B$BOf course, if you're here to help, I've got all the time in the world.
10910	The fel crystalforge can be used to transform your apexis shards into unstable flasks of the beast.  These flasks make the imbiber more agile, stronger and heartier.$B$BMake your choice, below.
10911	<As you place your apexis shards into the fel crystalforge and pull the lever, the device makes an unworldly sound as it grinds them into dust.  A few moments later your flask pops out of its 'mouth'.>
10912	<As you place your apexis shards into the fel crystalforge and pull the lever, the device makes an unworldly sound as it grinds them into dust.  A few moments later your flasks pop out of its 'mouth'.>
10913	The Bash'ir crystalforge can be used to transform your apexis shards into unstable flasks of the sorcerer.  These flasks make the imbiber more intelligent, heartier, and increase the effectiveness of their damaging and healing magics.$B$BMake your choice, below.
10914	<As you place your apexis shards within the hollow of the Bash'ir crystalforge and pull the lever, the device literally disintegrates them.  A few moments later your flask appears at your feet.>
10916	We hope you'll be able to ease our headaches.  You try having ten sons, all of them wanting to do something they weren't meant for!$B$BStill, as a father, we do what we must.
10917	Do you have any sons, $c?$B$BLet us tell you something, we think we were much happier before we came to Ogri'la and the crystals made us more aware.  Before, we would have just bashed them over the head to get them to shut up.  Now all they do is bother us about the Sha'tari Skyguard.$B$BIgnorance is bliss!
10919	As a relative newcomer to Ogri'la, you don't have enough exposure to the crystals here to reap their full benefits.  Besides, you only have one head.$B$BWe, on the other hand, have been here a very long time.  So, as you can imagine, we're fairly well-versed in a great many things.$B$BOf late, we've taken a keen interest in the demons of the forge camps.  More specifically, we've devised a way to rid us of them for good.$B$BAt least, that's the theory.
10920	We wish that we could create more than one darkrune in a day, but that would be a waste of time.  It's simply not physically possible.  Besides, we can't even reliably create them at that rate.$B$BAnd trust us, if there were anyone else here smart enough to help, they'd be conscripted and we'd have as many darkrunes as needed.
10921	The Bash'ir crystalforge can be used to transform your apexis shards into unstable flasks of the sorcerer.  These flasks make the imbiber more intelligent, heartier, and increase the effectiveness of their damaging and healing magics.$B$BIt appears, however, that you do not have the requisite ten shards to purchase even a single flask.
10922	The fel crystalforge can be used to transform your apexis shards into unstable flasks of the beast.  These flasks make the imbiber more agile, stronger and heartier.$B$BIt appears, however, that you do not have the ten shards necessary to purchase even a single flask.
10923	Gahk new at Ogri'la like little $r.  It like heaven da other ogres below always talk about.  But, Gahk's heads hurt from crystal making Gahk smarter.$B$B<Both of Gahk's heads nod to each other.>$B$BUs learning ta make da crystalforged darkrune.  When us learn dat, we smash da demon's warp-gate!
10924	Gahk now smart!  Us know how ta make da darkrune into da crystalforged darkrune!
10925	$N smash warp-gate good, but da demons make it strong again.$B$B$N bring Gahk another darkrune and Gahk make special crystalforged darkrune for $N!
10926	Welcome to Ogri'la, $c.$B$BThe ogres here have managed to gain a great mental acuity through the magical emanations of the surrounding crystals.  Though we do not fully understand how they work, we have come to appreciate our new home and only want to live in peace.$B$BUnfortunate then that the demons and ethereals, and especially the Black Dragonflight, will not leave us to that peace.
10927	On behalf of all of Ogri'la, we give you thanks for your efforts, $N.$B$B<Chu'a'lor's left head nods while his right head smiles at you.>$B$BAnd do not forget that by helping us here you are also helping to protect our brethren down below whom you have become like a $g king : queen; to.
10929	You don't. You're not strong enough to participate in ranking matches yet. Still, you can find an Arena Battlemaster and get in some practice rounds. It's never too soon to start training.
10930	Have you come to hurt me?  I have nothing to do with the war, $r.$B$BI'm just a sickly scholar, please leave me alone!
10932	The egg appears resilient as an egg of the Black Dragonflight rightfully should.  Perhaps if you were to place a great many apexis shards next to it, their vibrations would cause it to crack open?$B$BToo bad that you don't appear to have the thirty-five apexis shards necessary to do the job.
10934	<Angela coos to the felhunter again before turning her attention to you.>$B$BJir'see's always been smaller than all the other felhunters, but that's never bothered him. And Outland's going to change all that, right Jir'see?$B$BMomma's little angel is going to grow up to be a big, fierce felhunter, yes he is!
10937	You'll find plenty to do here, $N.
10938	Ack, ye've been busy now haven't ye?!  I canna thank ye enough for bombing them demons and resupplying us with mounts.$B$BYer making our job all the more easier.  Keep up the good work, $g laddy : lassie;!
10939	We must re-establish our stranglehold on these mines!
10947	I must leave this place at once!
10948	The Apexis Relic shimmers, betraying a hidden intelligence within.
10949	The Apexis Monument looms above you.
10950	Stand at attention, captain!
10951	Burning eyes within the prism fill your mind with a sense of dread... especially knowing that you don't have the thirty-five apexis shards needed to summon forth its demon.
10953	You're a young hatchling aren't you?  My eyes fail me.$B$BI assume you're here to purchase one of my exotic texts?
10957	Forget Vixton's spread. You want the good stuff? You talk to Krixel here. I got just what you need, provided you got the right rep. You know, in the arena. This stuff isn't for sissies, kid.
10961	We're currently focus testing the Battle of Mount Hyjal. You must have at least HONORED reputation with the Violet Eye to participate.$B$BThat's the reputation you gain while doing Karazhan.
10962	Now that you're attuned to Mount Hyjal, I can teleport you to the Caverns of Time. Just let me know when you are ready.
10964	Now that you have your Black Temple key (Medallion of Karabor), I can teleport you directly to the Black Temple. Just tell me when you are ready.
10965	Welcome friend! What would you like to see?
10966	Greetings $G brother:sister;. How can we be of service?
10967	How can we help you?
10973	Our food should satisfy even the mightiest of hungers.
10974	Still hungry $G brother:sister;? How can we help?
10975	We have quite the feast for you friend.
10976	What tasty treats can we offer you?
10980	Good day to you.  When you've risen a bit more in the ranks of the Sha'tari Skyguard, I will be able offer you a direct flight to the Skyguard Outpost, our base atop the Blade's Edge Mountains.
10988	Don't ya have something better ta do, $g lad : lass; than jaw with me?$B$BNow get out there and prove yer mettle!
10989	That's the spirit, $g laddy : lassie;!  Yer making all of us proud with all o' the work ye be doing!$B$BAnd ya know, if ya want a quick trip ta our other base in the Skethyl Mountains, go down an talk ta Skyguard Handler Irena.  She'll set ya up nicely.
10992	I see that you've been putting in your time around here, $c.$B$BPut in more; the demons aren't gone yet, rookie.
10994	Your name seems to be on everyone's lips around the outpost.  Don't let it get to your head; I know that you can do better!$B$BI'll be watching you, rookie.
10995	Alright, I admit it, you've proven yourself and then some, $N.$B$BIf I was hard on you before it was because I saw the spark of a true Skyguard within you.  I dare say that you're the finest ace that we have!$B$BAnytime that you want to help out, I'll be more than proud to hand you another set of bombs.
10997	Hey there, $c!$B$B<Khatie looks at you slyly.>$B$BAnytime you want to wrangle us up some more aether rays, you make sure to come and see me!
11000	What are you looking for?
11001	You know, $N, it's such an honor to work with you!$B$BWhen you're not busy wrangling, maybe we could $g go out some place for dinner? : get together for a girl's night?;$B$BOh, did I mention that we can now get you to our base in the Skethyl Mountains real quick?  If you want, speak with Skyguard Handler Irena about that.
11002	So, you've been around a lot, but we seem to keep missing each other for getting together after work.$B$BIs it me?$B$B<Khatie purposely cheers up.>$B$BAnyway, I just wanted to say that I... we really appreciate everything that you've been doing for the Skyguard!
11004	I hope you don't think I'm a stalker, or anything like that, $N.$B$BI mean, I know that you're real famous within the Skyguard now, and well... I'm sure that you wouldn't want to hang out with a lowly peon like me.$B$BBut, if you ever want to get together to just hang out, or even wrangle some more rays, drop by anytime!  I'll be here.$B$BI miss you...
11007	The relics are truly a great mystery.  Perhaps by studying them regularly, you will gain a finer appreciation of their capabilities.
11008	Steel isn't strong, exalted one, flesh is stronger. Steel gains its strength from the one who wields it. But enough of that... How can we help you exalted one?
11009	<Chu'a'lor's left head says,>$B$BWe find your zeal to help us most appealing...$B$B<His right head concludes,>$B$B... and we want you to know that we greatly appreciate your efforts!
11010	Your name is beginning to be revered around here.$B$B<Chu'a'lor's left eye pierces you with its stony gaze.>$B$BKeep up the good work, $N!
11016	Here in Ogri'la we have time to contemplate the riddle of steel. But enough of that, how can we help?
11017	Do you have steel that needs shaping?
11018	We cannot thank you enough for everything you've done to protect our family, $N.$B$BAnd, you do realize that we were joking before when we offered to sell you one of our sons?  No, really... although we do feel a couple more headaches coming on.$B$BJunior, be still, will you?!
11019	Us starting ta like little $N!  Yous bashem da demons real good!
11025	Hello friend! What can we do for you?
11026	We are here to help.
11029	You having a good time here with us in Ogri'la?$B$BWe have a lot of stuff that our ogres are making, day and night.  We save the best to sell to our coolest guests like you!$B$BSo, as you're out there doing your thing, and making the mountains a safer place, stop by from time to time to see what we have.$B$BGood luck out there, $g man : chicky;.
11032	<Overlord Mor'ghor salutes.>
11035	Hey, remember, $N, we'll make this stuff available for you to buy as you do good deeds.  It's like a karma thing, or something.$B$BSo, help out where you can, including with our Skyguard friends just to the north.$B$BAwesome... thanks!
11036	Chu'a'lor's been saying good things about you, $N.  If you want, we have a couple of special ogre brews for sale.$B$BThey're really tasty!
11038	What can we say, $N?  $G Dude : Dudette;, anything that we have in the store is yours to purchase!$B$BRight on!
11042	Leave off. I don't have anything for the likes of you.
11045	What mysteries of the trade can I help you uncover today?
11049	Come, come. If you've properly prepared your leather for once, I'll show you how to fashion serviceable items.
11051	I've heard tell of a truly skilled smith across the sea named Saru Steelfury. The smithy in Orgrimmar is where you should head if you wish to ply your trade, $c. Best of luck.
11055	Come, $r. What formula interests you today?
11056	We are launching an assault on Bash'ir Landing, to study their Crystalforge.  Help us if you can!  Our Skyguard Aether-tech will leave in about $4581d.
11058	A terrible, dark energy emanates from this pile of skulls.
11059	Need supplies for the field?
11061	Need to requisition some supplies?
11064	Greetings, traveler.
11065	Our Aether-tech and his escort are heading to Bash'ir Landing.  Meet them there and help with their mission!
11066	Our Skyguard Aether-tech and her escort is studying the Bash'ir crystal forge.  She needs help!  Go to Bash'ir Landing, find the aether-tech and keep her safe!
11075	Forgetting your skill in Elixir Mastery is not something to do lightly.\r\r\n\r\r\nAre you absolutely sure?
11076	Forgetting your skill in Transmutation Mastery is not something to do lightly.$B$BAre you absolutely sure?
11077	All of Illidan's lieutenants have fallen, $N.  The way forward is open, if you're ready.
11081	I sense you've cleared the path to my brethren.  My connection to them and to the temple is still strong.  Do you wish to delve deeper inside?
11082	My brethren were here not long ago.  My connection to them has grown tenuous.  A powerful presence in the courtyard guards the way forward.
11085	Welcome, $N. Bring me the marks that Illidan bestows upon his most powerful minions and I shall grant you access to my alchemical goods.
11090	Drakes is my business, $N. I'm authorized to sell them to our highest ranking officers.
11091	What do you need, $c?
11093	Let's get out of here!
11094	The crystal foci?  Of course we'll explain it seeing as you only have half the brain power to figure it out.$B$BA depleted crystal focus can be combined with ten apexis shards in a simple process, which creates a charged crystal focus.  These charged foci have some healing properties, but more important is their use with a possessed demon.$B$BYou see, the charged focus can be used to enable a possessed demon to exhibit special powers.  After a time, Gahk will have a mission for you to do just that.
11128	I will accept your help in this inspection, $c. Do not assume that I will trust your findings or your motives without my own verification.
11143	The Headless Horseman's undead mind is obsessed!  During Hallow's End, his attacks on this village are frequent, and terrible.
11145	The Headless Horseman attacks the village!  Someone must save the children and stop him!
11147	We are free of the Headless Horseman's terror, for now.  We may breathe easy again, but until he can be defeated while joined with his head, he may return.
11163	I'm not sure where the zeppelin is right now, actually...
11165	The zeppelin should have just reached Orgrimmar.
11167	The zeppelin should have just arrived at Grom'gol... 
11169	The zeppelin should have just arrived at Orgrimmar...
11170	The zeppelin should have just departed from Orgrimmar...
11172	The zeppelin should have just departed from Grom'gol...
11173	The zeppelin should just have arrived at Undercity.
11174	The zeppelin should have just departed from Orgrimmar.
11175	The zeppelin should have just departed from Undercity.
11177	The Headless Horseman attacks!  The fires threaten to consume the whole village!  What will we do?
11179	The zeppelin should just have arrived at Undercity.
11180	The zeppelin should just have arrived at Grom'gol.
11181	The zeppelin should just have departed from Grom'gol.
11182	The zeppelin should just have departed from Undercity.
11189	I spend all day retrieving parts for the zeppelin and Frezza doesn't even have the decency to pay me an hourly wage. But you're not here about that, are you? I bet you want to know where the zeppelin is located. Well, you're in luck - I have my zeppelin tracking device right here!
11196	The merchant known as Griftah has been exiled from this city for his fraudulent activities. We plan to go over these little knick-knacks he sells extremely carefully. Please, leave his stall undisturbed and let us do our work.
11209	You won't find a better brew in Azeroth.
11210	We Thunderbrews take pride knowing that we are the best brewhouse in all the realms.
11211	Whoah! You really want buy from us?
11215	Can't you see that I've got places to go and people to see! Step aside, peasant!
11217	I can only assume that you know who I am. And yet you insist on disturbing me?$b$bWhat could you possibly want that requires my attention?
11220	I highly recommend that you visit Sayge to get your fortune told. I know, I know... he's a gnoll.  But he's a very special gnoll with the power to divine your future!$B$BAnd we are constantly expanding the faire with all manner of new attractions!
11221	Yes, well, listen here, $c. I'm older than I look and wise beyond my years. You'd do well not to question me so much.\r\n\r\nLook, you don't need to take my word for it. Read the postings on any local bulletin board for yourself. I'm everywhere!$b$bJust do yourself a favor and ignore the ones with 'WANTED' in the title. Simple misunderstandings, I assure you.
11230	What'll it be, sweety?
11231	Oh, me a cook?  I suppose that's true.  A barmaid's got to work in the kitchens from time to time, and I've learned a few recipes over the years.  Nothing too special, but they're hearty enough to fill Grok's substantial belly.
11233	I'm sorry $N, but you've already learned all I know about cooking.  Of course, you never know when our cooks will whip up something new, so don't be shy and be sure to visit again some time.
11234	My brother Krixx thinks he has it bad working in Orgrimmar. Nothing compares to the stench of this place. At least the boss had the decency to give me hazard pay!$B$BWhat? Do you want to see where the zeppelin is? Good thing I've got my zeppelin tracker right here!
11243	Be on your guard. We are Theramore's first line of defense against its many enemies in the marsh.
11245	Now that the deserters have taken over Lost Point, North Point Tower is the most distant of Theramore's outposts.
11256	What can a guy like me be doin' for a $r like you at a time like this?$B
11257	Beats me, kid. I'm new to the crew.$b$bI've had my fill of troll-killin' and grog drinkin, I can tell ya that. Only thing left to see is the treasure Budd keeps promisin'....$B
11258	Budd's crew, ye mean? Aye, he be no respecter of persons. He'll take on anyone who can work a shovel.$b$b'cept them undead. Budd hates 'em. Scared of 'em, likely as not.$B
11259	<sniff's himself, and winces>$b$bThat there be the smell of adventure, $c!
11279	Listen, mon!$b$bI tell ya all I be knowin', but first ya gotta be savin' me from these savages and their killer bears.$b$bDeal?
11285	I've never experienced cold like this, $r. Even in the absence of ice and snow, the frozen wastes of Northrend are extremely taxing.
11287	Say, you look familiar. Have we met?
11299	<Budd rolls his eyes as he sees you draw near>$b$bAhh, yes, the soon-to-be-famous $n!$b$bTo what do I owe the pleasure of your company?
11302	Now, now, $n, just relax and take a deep breath. You really need to learn to trust me.$b$bYour lack of experience in these situations is causing you to panic, and panic always exaggerates the truth. So you see, there really is no crisis.$b$bNow that we've settled that, I must ask that you stop being so negative. It's not good for the crew's morale....
11304	UDB Missing US text
11311	I wish we had a priest or a druid out here. I can't continue my studies until I've recovered from my injuries.
11313	Wait, don't tell me... $n, right?$b$bWhat can I do for you?$B
11320	Hi there! We're being blockaded by those good-for-nothing pirates out in the bay! Do you think you can help us out by dropping a few bombs on them?!$B$BOur stolen zeppelin's here; hop on board before she sets sail!
11322	Hi there! We're being blockaded by those good-for-nothing pirates out in the bay! Do you think you can help us out by dropping a few bombs on them?!$B$BOur stolen zeppelin's less than $3078w minutes away.  Make sure you're onboard when she leaves!
11324	Hi there! We're being blockaded by those good-for-nothing pirates out in the bay! Do you think you can help us out by dropping a few bombs on them?!$B$BOur stolen zeppelin's almost here... I think I hear her now.  Make sure you're onboard when she leaves!
11328	I'm a prisoner!$B$BThey shot me and my beautiful zeppelin out of the sky. And what for? Because I was ferrying men and materiel for the Horde? That's nothing new!$B$BNow they have me running her in circles around the bay so that they can bomb the pirates. I just don't have the parts to keep her going like this! I'm barely keeping her together on spit and bailing wire!$B$BI won't be held responsible for what happens to you, but you might as well get on board before she leaves.$B$BIt's a crime I tell you!
11330	I'm a prisoner!$B$BThey shot me and my beautiful zeppelin out of the sky. And what for? Because I was ferrying men and materiel for the Horde? That's nothing new!$B$BNow they have me running her in circles around the bay so that they can bomb the pirates. I just don't have the parts to keep her going like this! I'm barely keeping her together on spit and bailing wire!$B$BIf you're determined to help them out, she's due to arrive back in port in less than a minute.$B$BIt's a crime I tell you!
11352	Day and night all I do is sit here and make ammo and restring crossbows.$B$BI suppose you want me to do something for you too?
11354	UDB Missing US text
11356	What's happening?
11358	He's gone?  Hooray!
11359	Hallow's End is a scary holiday, but I like it!
11365	This board is used by the Steamwheedle representatives at Mudsprocket to post bounties and job notices.
11370	Indeed! They were given every advantage I could muster. I simply can't imagine what went wrong.$b$bHere, $c, take one. I've made a couple of modifications - little refinements really. Now there's no excuse for failure!
11372	UDB Missing US text
11376	You might wanna stand back. Fish guttin' is a dirty job.
11384	The Royal Apothecary Society welcomes you to Northrend, $c.  Now, what is it that you will do to aid us in Sylvanas' service?
11403	The situation out here is worse than I thought! The zeppelin is little better than a heap of twisted metal and burning fuel!
11406	Welcome to Theramore, $c.
11424	I haven't much time to talk unless it's urgent, citizen. The gates of Theramore are my greatest responsibility.
11432	Thank the Light the Defias don't know the first thing about diving!
11457	Welcome to Theramore.
11458	What enchantments interest you today, $c?
11459	UDB missing US text
11469	Pleased to meet you, $c.
11472	There are eight types of Darkmoon Cards; Beasts, Blessings, Elementals, Furies, Lunacy, Portals, Storms and Warlords, with eight cards, Ace to Eight in each suit. If you collect all eight of one suit then you can turn them into a deck that you can give to our Professor Thaddeus Paleo in exchange for a powerful trinket.$B
11473	The Headless Horseman's mind is plagued with dementia!  During Hallow's End, he might attack this village at any moment.
11474	The Headless Horseman has set fire to the village!  We must protect the children!
11475	The Headless Horseman is attacking!  Quickly, aid your Horde brethren in the village's defense!
11476	The Headless Horseman had been driven away, for now.  We may breath easy for a time, but must remain ever vigilant.
11477	Hallow's End is a scary holiday, but I like it!
11482	Greetings my friend, and welcome to the greatest show in Outland!$B$BPlease, step right up and take in all we have to offer.  Amaze at the wonders that the Darkmoon Faire has uncovered in this vast and mysterious world!  We have spared no expense in bringing you excitement that children of all ages will delight in!
11496	I advise the captain on matters that he chooses to share with me, but I have a feeling that he'd rather hear from you.
11498	All of these mouths to feed, and who has to do it? Me!$B$BAll the cooking, and the cleaning, and everything else!
11502	In all of my days I never thought to see such a magnificent new frontier.$B$BIf only it weren't tainted by evil and knowledge which is best left hidden.
11551	You have reached the limits of my knowledge, but there is more yet to learn. Across the sea, in the Mage Quarter of Stormwind City, a great tailor dwells. His name is Georgio Bolero, and he will train you now, I think. Go and speak with him.
11562	The ground... is frozen.  We're sitting ducks here; these meatwagons aren't going anywhere.
11564	What does it look like?  The ground is frozen like a rock!$B$BThe wheels on these meatwagons were built to go over mud at best.  We're going to need an abomination and some chains to salvage them.
11567	I will never call Brackenwall Village my home. To do so is to give up hope of reclaiming our rightful lands.
11578	Well then, I spose I be owin' ya my thanks, $r.$b$bTruth is, I thought I'd swallowed me last tankard 'til ye showed up.
11582	Ohh, thank you soo much for getting me out of that cage because I was in there for soo long and it smelled like minced mutton that had been sitting out in the sun for a week and I don't like mutton to begin with because when I was little, well littler, I was actually turned into a sheep for a minute and so I know what it feels like to be a sheep and I don't want someone eating me, especially an overgrown troll dressed up like a kitty....$b$b<Ashli takes a deep breath.>$b$bHow's my hair?$B
11584	UDB Missing US text
11586	The stranded Alliance sailors know they're going to die, yet they fight us tooth and nail.$B$BImpressive and pathetic at the same time.
11588	It is those two cannons along the wall that are slowing us down.  Without their protection our forces would be able to rush their fortification without taking any losses.$B$BIt's either take out those cannons or wait until they run out of ammunition.  Anselm's choice, I suppose.
11590	The Headless Horseman, once a knight of the Silver Hand and a hero among his fellow paladins, is cursed.  Driven insane within the Scarlet Monastery, he believes that he is alive and we are dead.$B$BNow, his fervor no longer serves the Light.  With the coming of Hallow's End, he spreads gloom and fire across the villages of Azeroth.
11596	UDB Missing US text
11602	Freedom! Kraz life was over.$b$bI thank you, $c.
11604	Kraz should never have come to this cursed place... should have known not to trust the human. A blind fool I was, $c, as are you if you follow his counsel.$b$bMy son, lost for two moons, was last seen with the human, Budd. He told me I could find him behind the walls of Zul'Aman....$b$bI followed his people here, and was captured with the rest. Without your help, I was doomed to die.$b$bThank you, stranger.
11607	Come in out of the cold and rest your weary bones a while. Our hospitality is yours.
11614	Walk in the Light, my child.
11622	$G Sir : Ma'am;! I'm here to assist and defend you.$B$BYour orders?
11625	For ages, I was lost.  Now, finally, I see how dark my soul had become...
11645	The pumpkin head smolders forebodingly...
11655	Make haste, $c!$b$bThis crisis is nowhere near being under control.
11662	You seek passage somewhere, $N?  My bats will get you there in no time.
11667	Tread carefully, $r.$b$bThese corpses here are all that remain of my best men.
11671	These Alliance pondsuckers sure are gutsy!  Boarding fully-manned Forsaken destroyers... now that's suicidal behavior if I ever heard of it.
11673	My sisters and I welcome you, $r.
11676	Stay sharp, $n.$b$bWe're not out of the woods yet....
11689	I am here to assist and defend you.$B$BHow next shall we strike at the enemy?
11691	Come closer, young one; my ears aren't what they once were, and I care not for raising my voice.
11724	So many uses for the plague, so little time!
11738	Aren't you a sight for sore eyes!$B$BThere's work to be done and not much time.
11742	Gorth not afraid of getting killed.  Them Forsaken just put me back together again.
11743	The Blastenheimer 5000 Ultra Cannon is a state-of-the-art single person projectile device. Delivering its payload at near the speed of a dragon, the cannon is the pride and joy of the Blastenheimer family, world renown for their aeronautical and combustible feats!$B$BIf you'd like to be launched through the skies to fly free as a bird, seek out Maxima Blastenheimer in the Terrace of Light in Shattrath City. She'll aim you at a target in a small pond outside the city walls!
11746	Keep your voice down, $c. We wouldn't want them to hear us.
11796	I've been in the military my whole life.  I've fought in many wars, under many banners - but they've always been other people's battles.$B$BNot this time.  Every Forsaken soldier you see here has come for one reason alone.  Arthas must be killed.
11797	Hungry? Can sleep here, too.
11799	Keep your wits about you, $r, we're surrounded by the walking dead here.
11827	We plaguebringers tend to be slightly more practical than the average apothecary.  After all, we deal with the logistics of deploying the plague.$B$BThat doesn't mean our theoretical background isn't rock solid.  We just prefer... hands on tasks.
11851	Ya be havin' me gratitude, $c.$b$bIf there be anythin' I can be doin' fer yeh, just say so.
11858	It was kind of the Explorers' League to allow me to tag along. However, with the dangers in the Rivenwood and surrounding area, it looks like it may have been foolish of me to come without help.
11874	I'm going to miss Camp Winterhoof, but I understand why Chieftain Ashtotem made his decision. Home is a comfort we cannot always afford.
11880	Hey, can't you shee I'm trying to drink here?
11884	Bones... flesh... muscles... tendons... cartilage... it all comes together here under my hacksaw.
11898	Here you go, $g lad : lass;. Make 'em count!
11907	UDB Missing US text
11910	Of course. I found it on the corpse of a dwarf nearby.
11912	Of course.
11945	Hey there!  Just because I can race rams better than anyone else, doesn't mean I won't pitch in and help out the brewers.  You can help out if you like.$b$bBut wait, there's more!$b$bHelping out with Brewfest means you get a chance to ride some of the fastest rams in the realms!
11956	Dark times make for strange friendships. It may be worth visiting old Lordaeron to watch the Forsaken burn their little man of wicker.
11957	I understand this holiday is a creation not of our allies, but the Horde. Why we follow suit, I do not know.
11958	We're celebrating the who breaking free of the what? Bah, who cares?! More candy!
11960	All this free candy is just bad business, I tell you. Or... maybe it's just a loss leader... they get you in the inn, and then gouge you on the meat. It's brilliant!
11961	When Hallow's End is over we'll smash all these pumpkins. That'll be the greatest day I've ever known!
11962	To celebrate the birth of yet another deadly enemy is an odd thing, to say the least. Still, we will join our allies in their festivities.
11963	The Forsaken are right to celebrate their freedom. What else is more important?
11964	I do not understand the significance of the Forsaken burning a great wicker effigy each night, but our own rituals must seem just as strange to them.
11966	During Hallow's End we celebrate the day that the Banshee Queen herself delivered us from the clutches of the Lich King and the Scourge. Be sure to attend the Wickerman Festival that is held each evening outside Undercity.
12044	Many are the rare and precious objects that my clientele seek.$B$BYou could be the one to bring them to me, $c. In return I offer that which you covet.$B$BShall we speak more on that which I look to procure today?
12049	We set up this area to practice fire fighting.  You never know when the town will be imperiled!
12052	I bet ya think you're tough, eh, kid? I guess I might have something for ya if ya can hold your own in the arena. Good stuff, not like Krixel's. That's so last season, ya know?$b$bOh, and have a nice day.
12076	There's always a need for more kegs at Brewfest!$b$bI'll lend you the reins to one of my personal rams.$b$bEvery time you bring me a keg, I'll give you some tokens.  I'll even let you use the ram for a bit longer for every keg you bring me!  $B$BTake heed! Once you start this, you won't be able to do it again until tomorrow.$B$BAre you sure you're ready to do this?
12080	I understand that many individuals seek romance in taverns and festivals like this one, but alcohol dulls the senses and makes calculating the difficulties of daily life all fuzzy!$b$bBut I've found a solution! Through many trials and tribulations, I've engineered an extraordinary device that gives you all the benefits of alcohol with none of the drawbacks! With these goggles on, ANYONE looks attractive!$b$bMmm... including you, cutie! Tell you what. I'll give you a discount!
12082	Ain't she a beauty? Want to take her for a spin?
12083	Hey there!  Are you interested in learning some more about racing rams and ram racing?
12084	When you take one of these tasks, we'll lend you a ram. It's a loan, so it won't last forever. The ram may seem slow, but just ease up on the reins a bit and he'll pick up the pace.$b$bOur rams love apples. We've put a few bushels of apples out along the way, so make sure to stop by. Eating apples will make your ram forget about how tired he's been getting.
12085	When you get a ram, you also get the reins. These aren't your grandma's reins though, you've gotta use them!$b$bJust loosen up on the reins a few times to build up some speed.  Keep on loosening up and GIDDYUP!  You'll be flying!$b$bBut the faster he goes the quicker he'll get tired. So you have to be careful.$B
12086	Once you start loosening the reins on the ram, you'll see his speed change. He starts off walking. Ease up on the reins a bit more and he'll start to trot. Give him more slack on the reins while he's trotting and he'll go into a canter. Give him even more slack while he's in a canter and you will send him into a gallop.$B$B
12087	Keeping your ram in a canter or gallop for too long will exhaust him. If you want your ram to recover a bit, let him walk or trot. If there are apple bushels around, take him there to recover.$B$B
12088	Ram racing is easier than it seems, but it takes skill to master. Just use the reins, eat apples if you can and avoid exhausting your ram.$B$B
12090	Yes? What is it?$B$BTime waits for no one!
12092	If you earn enough Brewfest prize tickets, the ticket redeemer in the Brewfest camp can give you an \\"Honorary Brewer\\" hand stamp.$b$bThat stamp will allow me to sell you a Brewfest riding ram. But they don't come cheap, mind you!
12098	Hey friend, what I've got here is a breakthrough, the likes of which have never been seen!  And it's for sale, for cheap!$b$bYou see, I got tired of spending money in taverns looking for the perfect person.  So I made these goggles and now EVERYONE looks like pure perfection.  I mean you CAN'T go wrong with these puppies!$b$bSo, you wanna try these out, help pad my pockets a bit?  Since you look soo good, I'll even give you a discount!
12103	Normal dogs won't come anywhere near me nowadays.  I was devastated when I found out... I used to love the beasts.$B$BPlaguehounds make for a fine substitute, however.  They're not quite as... easy on the eyes.  But then again, neither am I!
12104	You won't find a better brew in Azeroth.
12105	Hey mon, you ready to try da best brew in all da realms?
12108	Here we practice fire fighting techniques.  Power to the Forsaken!
12113	That crash between here and Razor Hill really messed up the brew flow!  It doesn't help that Dark Iron dwarves seem to be attacking every hour or so!$b$bSo if you want to help, here's the deal.  I'll let you borrow some reins and one of my rams.$b$bEvery time you bring me a keg, I'll give you some tokens.  I'll even let you use the ram for a bit longer for every keg you bring me!$b$bBUT, once you start this, you won't be able to do it again until tomorrow.$b$bAre you sure you're ready to do this?
12114	I see you checking out our legally obtained racing rams...  I can see you want in on the ram racing sensation...  But before you can play, you gotta work.$b$bWell, work and play are pretty much the same when it comes to these rams.
12120	Ahoy, mon!  What be happenin', ye salty 'at steppa!$B$BDis place be all chacka-chacka, ye scallywag!
12121	Now ye just be fass and facety, mon!  Ye fixin' fe vex me, ye maga dog blaggard?$B$BG'waan den, ye lily-livered scallywag.  Be seen ya first light!
12130	<Old Icefin eyes you warily, his fishy eye blinking as he bobs his head up and down once in a curt dismissal.>
12135	A word to the wise, stranger, go back to wherever you're from.$b$bThis is no place for lighthearted adventurers. It'll chew up the likes of you and spit out your bones.
12137	This large jack-o'-lantern rests in the middle of the village.
12138	The pumpkin has been smashed, and offers no more treasure.
12140	Smashing the pumpkin reveals a hidden treasure!  This is the greatest day you've ever known!
12162	Greetings, Light of Elune be with you.
12163	I would love to read it to you!$B$BDo not stand at my grave and weep,$BI am not there, I do not sleep.$B$BI am in a thousand winds that blow,$Bacross Northrend's bright and shining snow.$B$BI am the gentle showers of rain,$Bon Westfall's fields of golden grain.$B$BI am in the morning hush,$Bof Stranglethorn's jungle, green and lush.$B$BI am in the drums loud and grand,$Bthe thunderous hooves across Nagrand.$B$BI am the stars warmly gleaming,$Bover Darnassus softly dreaming.$B$BI am in the birds that sing,$BI am in each lovely thing.$B$BDo not stand at my grave and cry,$BI am not there. I do not die.$B 
12165	I'll tell ya, the only proper way to hunt is when yer good an' hammered!
12168	<The falcon squawks hungrily for a grub.>
12170	Best keep yer head down, \\"matey!\\"  If ye know what I mean!$B$BYarrrr!
12173	I run the fights around here.  You want to place a bet, gamble with confidence - anyone caught fixin' fights gets to walk the plank.$B$BI'll make sure of that myself!
12176	Day in and day out all Mad Jonah Sterling wants me to do is swab the decks.$B$BSwab the decks?!$B$BI'm a mage, I don't DO swabbin'! At least not the mundane way.
12179	What's it going to be, then?  Rum?  Ale?$B$BOr perhaps something else?
12180	You're going to pull off a stunt on Jack in front of his boys?$B$BThat takes a good amount of... stupidity.  Well, it's going to cost you.  I'm not going to risk my life for anything less than a gold.  And you best wait til I'm out of the way before you make a move.
12181	It never hurts to have a reason to drink!
12185	Welcome back, $N.
12186	That cursed Jonah Sterling will lead us right into doom.  If he spent more time outside of his cave, he would realize the folly of attacking professional navies in a time of war.
12190	The Dude, over yonder, is pretty upset about his rug.
12191	Evenin', Gov'na.
12193	I su... sur... surpose that yar wanna ride back to der outpost. Yarp?
12198	This barrel of ale is guarded by Jarven Thunderbrew.  As long as he's in the basement, no barrels may be disturbed.
12208	Times are changing, $N.  War has arrived.$B$BWill our people rise to the occasion and aid our allies... or will we linger in the sidelines?
12209	I've little time for talk, sorry.
12210	Can't ya see I'm workin' here, $glad:lass;? Off with ya, afore Kowalski sees me jawin.'
12213	There aren't many of us left, $N.  The return of our old enemy is a cause for great concern.
12217	Aye, that's her name, and a fine ship she is.$b$bThere's much to learn from such vessels, you know. A great poet once said: Ships that pass in the night, and speak each other in passing, only a signal shown, and a distant voice in the darkness; So on the ocean of life, we pass and speak one another, only a look and a voice, then darkness again and a silence.
12218	Should you desire sustenance, Galley Chief Grace can tend to your needs.
12219	Mr. Combs, the ship's engineer and quartermaster, can furnish you with whatever supplies you might require. He is a fair tinker, too, if your gear is in need of repair.
12220	Ah, yes, that... the name. Well... as they say, a good name, like good will, is got by many actions and lost by one. No need to go into the hows or whys; suffice to say, that is how I am named by some.
12221	The dead rise and seek vengeance on any that dare pass through their domain. Turn back!$B
12226	If we are to be successful in the creation of a portal to the Isle of Quel'Danas, and the Sunwell which rests upon it, we must acquire an energy source powerful enough to ignite the portal.$B$BWe are $3269w percent completed with our efforts. Will you assist us, $c?
12227	This portal is not like the others that lead back to Azeroth. To maintain it, we must acquire more mana cells.$B$BIt is either that or risk losing our access to the Isle of Quel'Danas and the Sunwell.
12237	Greetings, $r.$b$bMy shop is finally open. I hope you like what you see!
12238	Good day to you, $c.$b$bThere's much to be done to assist in the effort here. Sadly, there's very little I can do for you until I get all of my supplies.$b$bI've now got $3223w percent of the razorthorn roots I need to get started. Any assistance you provide will be well worth the effort, I assure you.
12239	This is the gateway that Kael's armies used to retreat to the Sunwell.  Some of his lapdogs remain here; the Legion has rewarded them in a most... unusual way.
12240	Have you seen the damaged sentries that wander the island?  A few modifications to the crystals that control their behavior will allow us to gain control of them and use them to secure tactical locations.$B$BThe Sun's Reach Sanctum will be ours in no time.  We are $3244w percent done with this goal.
12241	We succeeded in taking the Sanctum.  We can continue to convert sentries and use them as guards at other tactical locations.
12243	We must make sure not to lose any more souls to the seas.
12244	Forgive me $c, but I must concentrate on my job.
12245	Many have been lost to the seas.  I, and the wisps, are charged with looking for those souls.  
12246	The wisps and I watch the seas for any lost souls.
12247	The seas are a dangerous place, $c.  We must be alert.
12248	I'm afraid I cannot speak with you at the moment.
12255	Capturing the Sun's Reach Sanctum was the first step in our battle plan.  Our orders are to take control of the armory next.$B$BWe are $3233w percent done with our goal.
12256	We have gained control of the armory, but our work on the island is not yet finished.
12257	My orders are to create a distraction at the Dead Scar so our forces can take the Sun's Reach Armory.  It might not be as glamorous as killing demons face to face, but if it wins us this battle then I'm all for it.$B$BWe are $3233w percent done with our goal.
12258	We've captured the armory, $N.  Let's not rest on our laurels, however.  The Legion sure will not.
12260	Arming the wards at the sanctum will help us secure it faster.  We don't want any Wretched getting in our way when we unleash a full scale attack on the Legion and Kael.$B$BWe are $3244w percent done with our goal.
12262	The Bravery's crew will do its best to make your journey as swift and pleasant as possible.
12263	Sorry, but we'll have to speak some other time. Farewell.
12264	Welcome to The Bravery, $gsir:madame;. Now if you'll excuse me...
12267	Unlucky name fer a sailor, innit?
12270	We've sworn to do our very best to protect the passengers of The Bravery. The sea lane between Auberdine to Stormwind Harbor must remain safe.
12273	If your stomach's rumbling, talk to Galley Chief Steelbelly, but just between you and me? You might want to wait. He's got that name for a reason.
12277	Watch your step aboard Elune's Blessing, $r.  Though Elune's blessed us with the discovery of our new friends, we've also had our share of hardships at sea.$b$bHowever, recovering souls lost at sea or lost in a new world is truly a blessing from Elune.
12278	Elune has blessed us many times over with all the discoveries we have made.  But we must remain vigilant, $c.
12279	Forgive me, $r, I must focus on my job.
12281	Welcome aboard the Maiden's Fancy. It should be smooth sailing all the way to port.
12282	It's amazing what you can learn from a gnome if you squeeze them hard enough: clever little tricks about getting out of a bind, making delicious cookies, and even how to make a flying machine.
12283	As often as I can.  It's great exercise and it keeps me informed on what they're up to--which, from my experience, is always no good.
12284	Urrrk... if that grubbing galley chief over there offers you his special, do yourself a favor and dump it in the ocean. It might kill a few makruras instead of your will to live.
12285	Hello, $r.$b$bLet's get busy! No sense waiting around for supplies that may never arrive.$b$bI need my anvil in order to outfit our troops properly. Right now It's $3228w percent complete.$b$bAnd when the anvil is completed, there will be many more powerful items that I will be able to smith for you.
12286	Hello, $n.$b$bNow that I've finished creating my anvil I can begin outfitting our troops. It's an important step, but there's still much to be done.$b$bMore importantly for you, there are new things that I can create, which you may be interested in.
12287	We've taken the harbor, and this ship is a nice bonus. Too bad she's not yet sea-worthy.$B$BIn the meantime, I've been instructed to oversee the disruption of the naga on the Greengill Coast.$B$BThink you can help me out?
12289	<Grumbles>  I guess those mountains came out of nowhere...  All five times!
12290	If you like excitement, our captain's the best!  I love this job!
12291	Don't ask...
12300	I am glad that you ask. Our efforts to take the armory are at $3233w percent of our projections.$B$BI know that Battlemage Arynna and Harbinger Inuuro need your help. Seek them inside the Sun's Reach Sanctum on the Isle of Quel'Danas.
12301	Last I heard from Hauthaa, she indicated that we are $3228w percent of the way there.$B$BI cannot express how vital it is to our efforts that we get them created. Our men and women are going to need better armor and weapons, and the anvil and forge are the key to that.$B$BYou will find the smith behind the Sun's Reach Armory, $N.
12302	No, unfortunately we have not yet taken the harbor. However, reports indicate that we are $3238w percent of the way towards doing so.$B$B$N, if you want to help out, look for Magister Ilastar and Vindicator Kaalan at the Sun's Reach Armory on the Isle of Quel'Danas.
12303	The alchemy lab is not quite yet ready, $N. Mar'nah says that she is $3223w percent done with its assembly, however.$B$BIf you would like to help her with that, you will find her inside the inn at the Sun's Reach Harbor.
12304	We are trying to bring Agamath, the First Gate down. Please, $c, go to the Isle of Quel'Danas and help in any way that you can!
12305	Agamath, the First Gate is breached and two of Kil'jaeden's lieutenants, Lady Sacrolash and Grand Warlock Alythess, must be destroyed.$B$BGather your friends, $c, and see to it! Rohendor, the Second Gate is our next target.
12314	\\"Iron Eagle.\\" Hmph. It's a passenger ship, not a warbird! But hey, a job's a job, and I'll humor Captain \\"Bombast\\" so long as the prince is paying.$b$bIn any case, welcome aboard.
12315	Sorta busy.
12316	We protect this airship on its way from Orgrimmar to Grom'gol base camp in Stranglethorn Vale.
12317	Not right now, $gpal:sugar;... I got things to do. See ya around.
12319	We've almost consolidated our control over Sun's Reach.  If we manage to keep the harbor from getting any reinforcements we will certainly succeed.$B$BWe are $3238w percent done with our goal.
12320	We've done it, $N.  With Sun's Reach under our control we are but mere moments away from absolute victory.
12322	I'm gathering funds to build a monument in honor of those who've died in the war.  It is important to not forget the sacrifices we've made to achieve victory.$B$BWe are $3275w percent done with this goal.
12323	Isn't the memorial beautiful?  It is important to remember moments in our history when great sacrifices are made, lest we forget the price of all wars - even ones that are won.
12327	Welcome aboard $c.  Take a load off and enjoy the trip.  Aboard \\"The Purple Princess\\" we want you to relax.  We have vending machines down below if there's anything you might need while aboard.
12330	Please allow me a few seconds of rest.
12331	Let me sleep just five more minutes, mon...
12332	I'm busy right now.
12333	The flight from Grom'gol to Undercity is beautiful, though uneventful.  Though that is no excuse to fall asleep on the job.
12334	Come in out of the ash and muck. Dry yourself a spell.
12338	Do not fight the enemy unprepared, $N.  I can provide you with very powerful items... provided you have proven yourself to us.
12339	Kael's lackeys are about to be taught a lesson in humility.  We will crush the Dawnblade army and take Sun's Reach Harbor from them.$B$BWe are $3238w percent done with our goal.
12340	Sun's Reach is ours.  Kael's dogs are on the run... it is time to put them out of their misery!
12343	Mmrrglglglg? Glbmr brmmrggl glmrrbmrgl.$B$BGrglgrlbrr mrgl!!!
12347	The best defense is a good offense; anyone can tell you that.
12348	A strong weapon is no good if you don't live long enough to wield it, $c.
12349	Gawurgggl! Blrgl-brgl grgl!
12352	I'm not blind, you know. I can see what's going on around here!
12360	Blurg awrurgle mrr?
12361	My brothers and sisters have gone insane! Do you think you could help me get out of here?
12362	Glug bmrgl grggl!
12363	No time to talk -- I have work to do!
12370	Kael'thas and his felbloods be damned! All we've worked for is gone, but they're fools to think we won't fight back. Already, Lady Liadrin seeks a new source of power for our order. We will not be destroyed so easily.
12376	The Midsummer Fire Festival has something for everyone to enjoy!
12377	You've reached an Alliance bonfire! Desecrate this bonfire and stamp it out!
12382	We need to get this outpost ready for the push into Sholazar Basin.$B$BDon't just stand there, $c. Go out and represent the Horde with honor and spilled blood!
12384	I have to clean up this mess, but I'll do it without complaint.$B$BYou'll help if you have any Horde pride at all!
12387	The spirits speak all around us. Are you listening, $r?
12390	The Twilight Cult seeks to undo everything we fight to preserve. It is our sworn duty to prevent this calamity from coming to pass, $r.
12394	I am dishonored. I should have died with the farseer at Magmoth.$B$BLeave me to my thoughts.
12395	The element of air here is restless. Beware... they will not let you pass unharmed.
12403	It pains me to see my ancestors disturbed from their graves.$B$BWe must strike down the cursed spirit of your Force-Commander Steeljaw, the one who foolishly led his caravan through these sacred grounds.
12413	Only you can save me from Kaganishu, $N.
12417	We've lost a good many of our wind riders on scouting missions to the west. The Scourge is ruthless in their assault against any would-be spies.$B$BFortunately, I've come up with a solution that only risks the life of the rider. It's seen a 30% survival rate to those being ferried across the Plains of Nasam. That's a 30% improvement over when we were using wind riders!
12419	I am dishonored. I should have died with the farseer at Magmoth.
12422	Both Garrosh's Landing and Pal'ea were wiped out by the mist. We're the only ones crazy enough to stay here, buddy!
12424	What you see here on this coast is not a result of the Scourge. In fact, we believe that the Scourge also fear the mist - which might be why they do not come here.$B$BYou see, the mist is alive, friend. Inside those airy tendrils lies death...$B$BShould you step within its grasp, you will vanish. The mist will take you!$B$BWe have never seen anyone return alive from the mist.
12426	Since landing here I have seen horrors that had previously only haunted my darkest nightmares, but nothing could have prepared me for what lies beyond the mist.$B$B<Mootoo nods.>$B$BThrough that fog, not more than a few yards from us, stand the bloodthirsty creatures known as Kvaldir. None have returned from the fog and few that were originally at the landing when the mist rolled in have escaped. The area has since been condemned by Hellscream. Enter at your own risk...
12427	I... Are you...$B$B<Mootoo shivers.>$B$BAre you here to save me?
12433	You're a sight for sore eyes! I'm too weak to break the links on this rusty ball and chain.$B$BWell, don't just stand there! Get me loose!
12435	I've got my hands full here at the moment, $c.$B$BWhat can I do for you?
12440	Speak slowly, child, I am new to your strange tongue.
12441	Please, keep your voice down, $r. Hamat is old and needs her rest.
12456	Fine then, have a seat. This might take a while.$B$BWhen we first came to this frozen hell, General Arlos, down in Valiance Keep, gave my group of flying daredevils and I a special task: to establish a forward airbase for Alliance operations.$B$BThis airstrip is the result. Let me tell you, it wasn't easy, what with all the nasty beasts and the ground rock-hard from being frozen! But we managed, and we did it quickly too!
12457	Anyway, we needed to pump up lots of sand and oil for the machinery. The nearby pools proved to be perfect for that.$B$BSome of the sand even proved to have magical properties... can you say possibilities!? But that's a different tale.$B$BSo, we drained most of the water out and built the pumping station smack dab in the middle. Everything was going swimmingly until one day the main suction pipe got clogged.
12458	Mind you, this part I learned later because I wasn't out there at the time.$B$BWhen they ratcheted up the suction on the pump, up came pieces of a robot that looked like a gnome! Of course the fools worked night and day to put it back together without telling us.$B$BThis is when we lost communication with the pumping station.
12459	After a couple of days of silence, I sent a scouting party out to the platform. They never returned.$B$BI sent another group the next day with the same results, and lost a couple of flying machines out on aerial recon.$B$BAt that point I sent someone south to find help, and we hunkered down to prepare for the worst. We turned all of our attention to making armor, weapons and robots so that we could head out there in full force.$B$BWhen we did a few days ago, we couldn't believe our eyes!
12460	As I was saying, what we saw out there defied explanation.$B$BMy people were nowhere to be found, but in their place was a veritable army of robots and androids going about their business!$B$BThe droids all looked like gnomes and they said that they'd been expecting us. In fact, in their own strange way, they acted like they knew us. We were surrounded and quickly taken to the top of the pumping station.$B$BThat's where we saw their leader and what he was doing to the surviving gnomes!
12461	He called himself Gearmaster Mechazod. When we arrived he was busy transforming the survivors into mechanical beings!$B$BHe greeted us warmly and explained that he was one of the first gnomes ever to be created by something he called \\"The Grand Architect\\", a Titan keeper from within the halls of fabled Ulduar.$B$BApparently, he was the blockage that my team had accidentally sucked up from where he'd malfunctioned thousands of years ago. It was just our luck that we'd built the pumping station right above him.
12462	The station's mechanics had put him back together, bringing him back to \\"life\\".$B$BAnd now, by way of thanks, he was going to return the favor by curing all of us of what he called the \\"Curse of the Flesh\\".$B$BAccording to Mechazod, it's a condition that eventually befalls all of the creations of the Titans! In other words, we all supposedly start out as robots of some kind, and, over thousands of years, slowly turn into fleshy beings!$B$BPreposterous, I know.
12463	It didn't look like much of a \\"cure\\" to me, and I wasn't about to stand around listening to some crazy robot while he was butchering my people!$B$BWe did what any sane gnome would do... we ran! Well, actually, most of us parachuted off the side of the platform, but you get the picture.$B$BNot many of us managed to make it back here, and we're still spread thin from having to deal with everything else too, like the magnataur to the north and the Scourge to the east. To make things worse, the Horde just setup shop to the northwest!
12464	And that's where we find ourselves now, $N.$B$BWe can't possibly deal with all of this by ourselves, and quite frankly, I feel a little out of my depth. Jinky knows what needs to be done. You should go see her now.$B$BI just hope you'll be able to get us out of this mess with our bodies intact.
12472	The actions of these deserters shames us all. A shame so powerful that it must be witnessed to be understood. It is why Ug'thor is here... The boy must learn.
12475	Be careful around these parts, $r. The natives are ruthless.
12494	So, $N, which item are you interested in?
12495	Ah - oddities and rarities. We specialize in Azeroth's more unique items for the discerning adventurer.$B$BSince you're speaking with me, you must already have an idea of what you're looking for.
12496	Did you know that alchemists can transmute certain gems?  Mar'nah and I have been talking about this.$B$BI'm convinced that given her prowess, once her lab is complete, she and I will be able to create gems that were thought to be lost in time.
12497	We've done it, $N.  Mar'nah has learned how to transmute very special gems.  And I've learned how to work them.
12504	Welcome, $c. Have you come to honor this flame?$b$bRemember: Our festival fires burn in every land with an Alliance settlement. Make time to honor each of them, if you can.$b$bThe Horde, too, burns fires of their own. You would do well to desecrate such unworthy efforts when you see them.
12506	Behold, the Flames of Summer!
12511	While Nesingwary's advances upon the wildlife of Northrend has been halted, it is only a matter of time before he attempts another incursion. You must remain vigilant, $N!$B$BAbove all else, do not give in to whatever temptations may be set before you... The demon will attempt to charm you. When it happens, you must resist!
12521	I'll be damned if these blasted Scourge are going to drive us away!  Us settlers gave everything up to start new lives in Northrend.$B$BYou'd better believe we're going to fight tooth and nail.
12524	The stone radiates a bitter cold, chilling the air around it and the platform on which it sits. Deep within its facets, a blue light pulses, waiting.
12528	Some of us get to avoid military duty.  A good fisherman's always handy... even generals need to eat.
12529	Just another day workin' the kitchen.  Sure gets dull after a while.
12530	My shift's almost over.  Can't wait to catch some shut-eye, know what I mean?
12532	Need gold? Here's 5,000 coins worth.
12534	Arthas was once a human prince.  The army he led into Northrend suffered a horrible fate.$B$BMy brother, Thassarian, was a part of that army.
12538	We're miners, farmers and craftsmen - not soldiers.  But we'll defend our land with our bare fists if we must.
12539	Sorry, but my services are only of use to hunters.
12540	Sorry, but my services are only of use to druids.
12541	How may I help you, $c?
12542	I can erase all your talents so that you may choose new ones.$b$bThis becomes more expensive each time you do it.
12543	Sorry, but my services are only of use to hunters.
12544	Sorry, but my services are only of use to mages.
12545	Sorry, but my services are only of use to paladins.
12546	Sorry, but my services are only of use to priests.
12547	Sorry, but my services are only of use to rogues.
12548	Sorry, but my services are only of use to shamans.
12549	Sorry, but my services are only of use to warlocks.
12550	Sorry, but my services are only of use to warriors.
12553	Can I get you anything?  My selection is a little limited, but that's to be expected... all things considered.
12554	Huh?
12555	Dying for one's country is a soldier's duty.  But if calling this war folly is treason, then I'm a traitor.
12556	I'm very busy right now, $r. Please leave me alone.
12566	Focus your mind, mortal. This is the front line of a war unlike any you've witnessed.$b$bYou'll need full command of your faculties if you are to be of any use.
12572	When Ahune surfaces, will we be ready?
12577	Oh....$b$bWhere am I?
12582	Welcome, $c. Have you come to honor this flame?$b$bRemember: Our festival fires burn in every land with a Horde settlement. Make time to honor each of them, if you can.$b$bThe Alliance, too, burns fires of their own. You would do well to desecrate such unworthy efforts when you see them.
12587	Then I am glad you came. Now that you know of our fires, and of honoring them... and of the fires of our enemies, and of extinguishing them... you may return to him and be rewarded.
12590	In a word, magic.$b$bIrresponsible mortals with their brief lifespans think nothing of the lasting effects of their actions.$b$bArcane energies have been tapped too liberally, disrupting the world's balance. If this is allowed to continue, Azeroth will soon be annihilated.$b$bOn this, both sides agree. But before a council could even be appointed, Malygos put his own plan into action.$b$bWe had no choice but to confront him.
12591	We're making progress, $r, but far too slowly.
12592	We must succceed! Azeroth's fate lies in the balance....
12593	Malygos the Spellweaver, the Lord of Magic, Master of the Blue Dragonflight. He is the blue dragon aspect, one of the most ancient creatures on Azeroth.$b$bHe is said to be recovering from a madness which has lasted for millennia, but his recent actions lead me to believe that he is still far from sane.$b$bHis solution to our dilemma is to search out and destroy every magic-wielding mortal on Azeroth.$b$bAs the guardians of life, this has forced the red dragonflight to take action.$b$bDragon now fights against dragon, and the fate of our frail world lies in the balance.
12596	I'm glad you are here, $c. The military situation in the Sunwell Plateau is rather grim.
12597	Captain Selana has instructed me to assist you with your efforts here on the Sunwell Plateau.
12598	The Shattered Sun Offensive has made great progress in the outer areas of the Isle of Quel'Danas. Kil'jaeden's forces are being pushed back, and in the chaos I was able to lead a small scouting force here inside the Sunwell Plateau. My troops proceeded through Parhelion Plaza, spotted a group of Sunblade blood elves, and we then engaged the enemy. That fight quickly turned into a disaster.
12599	Kil'jaeden's defenders here on the Sunwell Plateau are much stronger than anything we faced outside on the Island. The Legion have even twisted our Arcane Guardian technology with fel energy to create something much more sinister. Just one of those Sunblade Protectors decimated my troops, and I ordered a swift retreat. I expected my squad to be pushed completely off the plateau, but the enemy surprised me by calling off the pursuit.
12609	Enjoying the festival, $c?$b$bWhile the Flame Keepers tend to the fires of the present, I am more of a historian, keeping close the festivals past. I'm also, of course, documenting this year's festivities. Things are going well thus far, don't you think?$b$bYou know, $n, there is power inherent in all festival fires burning throughout the holiday. We're taking care of ours, but I'm certain there are sacred flames burning deep within our enemy's cities...
12610	Welcome to our camp, $c. You're free to rest here if you'd like.
12611	There is nothing left for us here.
12618	Will the Horde grant me the chance to battle the Scourge?
12619	To avenge my people, to drive out the blight that has engulfed our land - I will take your oath. I will pledge all that I have and all that I am to the Horde.
12620	Lok'tar ogar! Victory or death - it is these words that bind me to the Horde. For they are the most sacred and fundamental of truths to any warrior of the Horde.$B$BI give my flesh and blood freely to the Warchief. I am the instrument of my Warchief's desire. I am a weapon of my Warchief's command.$B$BFrom this moment until the end of days I live and die - FOR THE HORDE!
12622	Ey, mon! Take me to mah troll bruddas!
12623	All three of the gates at the Sunwell Plateau have been brought down, $N.$B$BYou must marshal your forces and stop Kil'jaeden from entering Azeroth before all is lost!
12626	Riplash will never return to its former glory, but these boat-riding scum will pay for their deeds - I swear it!
12627	It is our duty to protect these taunka and provide them with what little comfort we can offer.
12636	I never understood why some pirates bury their treasure.  Me... I like to keep it within arm's reach.
12640	Moa'ki Harbor is blessed with two great sea turtles: Walker of Waves and Green Island. They swim between Unu'pe and Kamagua.
12641	Eager to get to Northrend, are you? The steam-powered Kraken sails from here to Valiance Keep in Borean Tundra.
12644	Hey there! Miss the Eastern Kingdoms, huh? Well, the Kraken sails back to Stormwind if you're really itching to return. I know I'd enjoy the warmer weather!
12645	Our blessed great sea turtle, Green Island, travels from here to Moa'ki Harbor in Dragonblight.
12646	Yo. Lookin' to get back to the Old World? Fly to Tirisfal Glades in style on the Cloudkisser.
12649	Northrend awaits, $r. The majestic Cloudkisser will take you straight across to the sea to Vengeance Landing in Howling Fjord.
12650	Heading home, $c? The Mighty Wind will get you there, if home's in Kalimdor. She flies straight from here to Durotar.
12657	Wanted DEAD for treason and other treacherous acts against the Horde!$B$BAll bounties paid by Captain Gort.
12663	All I ever wished for was to serve my king once again.  For humanity, against a common enemy.$B$BInstead, I find that our numbers have been infiltrated by cultist scum.... and all signs point to Naxxanar as the origin of this rot.
12664	This is where the cultists' orders are coming from.  Their leader is bound to show up soon.$B$BLet's not miss this opportunity.
12666	Huh?  What?!  Go away.
12667	If I can make a new war machine, I know I can get a pretty penny for it over at the Wrath Gate.  $B$BSome of our previous iterations haven't been entirely... stable, but my flying machine should do the trick if I can just develop an effective bomb system for it.
12669	You feel a strange presence as you stand before this ancient idol.
12670	Where the Eye of the Prophets rested for millenia, only an empty niche remains.
12673	Welcome!  If you need a place to rest, I can solve that problem.
12684	Looking for an Arena Battlemaster? You can find them on the road between towns, or in the capitals.$B$BYou can bind here, at me. I can also teleport you to one of the capitals.
12687	Welcome, $c!  I hope you aren't afraid of heights!$b$bI've got a practice parachute for you.  These chutes are for quick landings.  If you want to gently soar to the ground, use a mount.  If you want action and an adrenaline rush, you fall.  At the last possible moment you use your chute.  That's how these were made.  Quick action!  Are you ready for some quick action?$b$bThe chute only lasts a few seconds.  So you'll need to time it just right.  I'm not sure you can handle it, $c.  I'd like to see you prove me wrong.
12694	You'd better get outta here unless you want to find yourself in one of these cages....
12696	Thank you, $c, for seeing to it that I received the letter from my brother.$B$BRest assured, his death will not have been in vain. The blue dragonflight will pay for this.$B$BI'll see to it personally!
12698	Do your part in keeping the Scourge at bay, soldier! Report all suspicious activity and kill first, ask questions later!
12699	Mark my words, these forsaken fools will be the death of us all!
12701	Mon, da west wastes of dis place be full o' baddies. Stay away from dis here area if ya want to live!
12703	My charge at Agmar's Hammer extends far beyond the care of the animals at the stables.
12705	Expire? Me? Heh, not hardly, kid. That was just a scratch.
12708	With enough money, I could take over the world...
12709	This console stands before steaming rubble.  The sounds of an engine can be heard below.
12715	Leave me be, fool!
12718	What? You want to train under me, $c? You better be ready to work.
12720	You can sleep in the barracks, if you'd like. Just don't wake my men, or I'll throw you out in the snow myself.
12721	Thank you for rescuing me, $N. I will never forget your courage and determination.
12722	It would be an honor to battle alongside of you as a brother of the Horde, $N. I accept your offer.
12725	You not a real mon til you killed a dragon... mon.
12727	Hello, $r.  I'm sorry that you had to see our sacred land for the first time in such a state.
12732	Hey dere. You need anythin', you let me know.
12734	I have food, if you are hungry, and you may make use of my tent, should you require rest.
12735	Might not be snowy out there, but the nights here can freeze your nose right off. The bunks are in the back - just don't make a nuisance of yourself.
12736	Heh. Nothing against you, pup, but you might want to find somewhere else to bed down for the night. Wouldn't want that tender skin of yours to get bruised.
12738	Come in by the fire and rest, $r. I hope you don't mind the smell of fish.
12739	Through the valleys and peaks of Mount Hyjal, across the shifting sands of Silithus, against the Legion's dread armies - we have fought. We are the nameless, faceless, sons and daughters of the Alliance. By the Light and by the might of the Alliance, the first strike belongs to us and the last strike is all that our enemies see.$B$BWe are 7th Legion.$B
12740	Greetings!  Do you need something?
12750	All rewards to be paid by High Executor Wroth upon verification.$B$BSerious-minded individuals inquire within.$B$BNO SOLICITORS!
12751	We will ravage the living... I mean the Scourge, of course.$B
12755	<The Tuskarr eyes you suspiciously.>$b$bDo not stay long. You do not understand our people, and I don't want trouble.
12756	The sky is not safe, friend. Be alert!
12758	Do watch your step in the garden of Ysera, mortal. Things are not always as they seem.
12759	You need something? Maybe your armor or weapon repaired? Hmm?
12770	Desperate times call for desperate measures, $c.
12773	The natural beauty of these hills belies a great darkness below.  Tread carefully, friend.
12774	Be wary, for the plagued tendrils of the Lich King lurk close.
12775	The outhouse appears to be occupied at the moment.
12776	May the Light purge your infection, brave $N.
12777	My father has gifted me with his battle armor and axe. Soon I put it to good use.
12779	Fortunately, the outhouse is currently vacant.
12780	Our food and drink are in short supply.  I'm afraid I do not have anything to offer you.
12781	Thank you for your help, $n.  These frostberries are literally the fruits of your labor.
12795	Keep your voice down, $c. I'm in disguise and spying for Venomspite.
12804	Think you could get me out of here, $c?
12805	Oh good, you're here to rescue me. Now let me out of here!
12806	Hey, $g buddy : ma'am;. I've seen you around.$B$BMind getting me out of here?
12808	I don't know what happened. I had just arrived at Venomspite and then all of a sudden I woke up in this cage!$B$BAre you here to rescue me?
12819	Every two years the Spirits of Competition grow especially fervent... and now is that time! We wear this tabard into the Battlegrounds to honor them, seeking to defeat our enemies and earn their favor.
12820	You need only face our rivals in any of the Battlegrounds. Win or lose, if you stay for the duration of the battle, you will be mailed a Competitor's Tabard.
12821	You must defeat our rivals in any of the Battlegrounds. With every victory, there is a chance that a Gold Medallion will be mailed to you.
12823	We are quickly learning the price of death in this frigid wasteland, $N. The Lich King's power extends across every inch of Northrend, permeating into the earth itself! He turns our own fallen people against us.$B$BFrom the sky, risen gryphon riders rain down their vengeful stormhammers as the walking dead assail us on the ground.$B
12827	I think they put him in a cage over near the lumbermill.
12828	You must defeat your rivals in any of the Battlegrounds. With every victory, there is a chance that a Gold Medallion will be mailed to you.
12829	You need only face your rivals in any of the Battlegrounds. Win or lose, if you stay for the duration of the battle, you will be mailed a Competitor's Tabard.
12830	I think he's on the south side of the abbey.
12831	Every two years the Spirits of Competition grow especially fervent... and now is that time! Both Alliance and Horde wear this tabard into the Battlegrounds to honor the spirits, seeking to defeat all enemies and earn their favor.
12832	I think they have her down near the gallows.
12833	I think I saw them take him over by the north side of the abbey, near the archery targets.
12838	Greetings, $c.$b$bYou want Darrok to send you to Venture Bay?
12844	I am so very close to figuring this ore out. Any minute now and I will have the solution!
12845	'Ello, $c!$b$bYa ready ta head on down to Venture Bay and crack some Horde skulls?
12846	Yes, my $g son : daughter;?
12848	<The high abbot studies you a moment and then smiles.>$B$BVery well, I know a place, child. You just kiss my ring and let me know when you are ready.
12849	Then meet me at the entrance to the abbey. I'll be along in short order.
12850	I've played my part in destroying entire civilizations... to have to lower myself to dealing with the wretched Cult of the Damned disgusts me.
12851	Fine, but be more careful with it this time!
12852	Keep your voice down. We wouldn't want to attract any attention from these beasties!
12853	Don't bother me with trifles!
12856	Can't you see that I'm busy! We'll never have this base ready in time for the Prince's return!
12863	A good club can make all the difference in the world.
12864	Hey there friend!  I see you've got some Brewfest tokens.  As it happens, I still have some Brewfest items for sale.
12867	A good brew, is a strong brew.
12869	It's great bein' a member of da \\"Brew of the Month\\" club.
12882	You made it $g lad:lass;! I thought you were a goner for sure!
12883	What are you still doing here? Go back to town!
12895	Hey, $c, did you see that? Out there, lingering near the water's surface....$b$bYou saw it too didn't ya?
12896	The wha-??$b$bWell, I refer to them as undefined floating obstructions. And where I'm from, most deny their existence entirely.$b$bBut I know better! I've even seen 'em up close! My recent years have been spent building this vessel to locate, track, document, and if needs be, eradicate them!
12897	Don't be fooled, $r. They're very elusive. One moment they're there, the next they're gone - virtually inexplicable!$b$bBetween you and me, I actually held a piece of one in my hand once! Sadly, before I could conduct any measurements it was gone! Just disappeared....
12898	A lot you know...$b$bSome say they're just observing, some think they're altering our sea-life, and then others think they're here to take over Azeroth!$b$bOnce I take one down with my rocket propelled warheads I'll get the answers. You can believe that!
12899	Greetings, $r.$B$BI have been expecting you.
12900	Very well, let's go!
12905	The gryphon riders are standing 10 paces from us, friend. They'll be giving you a ride to Thorson's Post. Get going!
12906	Do not think for a second that your past accomplishments entitle you to anything, $N.  They don't.$B$BIf you want my respect you're going to have to earn it.  This means following my orders without question and fulfilling them... without exceptions.
12912	Welcome to Camp Oneqwah.
12913	S.T.O.U.T. is more than just a target for throwing steins, it's a valuable training asset.  If you can hit S.T.O.U.T. you can probably hit anything!$b$bJust try not to hit me.
12915	Belgaristrasz speaks the truth; the situation is grave indeed.  $B$BI can grant you the power to call upon a drake from the Green Fight.  Speak to Belgaristrasz or Eternos if you prefer to draw on the power of the Red or the Bronze.
12916	Varos Cloudstrider and his ring guardians protect the second ring.  Your drakes are more than a match for the Ring Guardians, but Varos stands behind an impenetrable shield created from the energy of the Oculus itself.  Ten Centrifuge Constructs power the shield from the ring and platforms above.  Destroy them and Varos will be vulnerable.$B$BI can grant you the power to call upon a drake from the Red Fight.  Speak to Eternos or Verdisa if you prefer to draw on the power of the Bronze or the Green.
12926	Most of my brethren are disdainful of the Horde's \\"barbaric\\" ways, and I once counted myself among them. When I was first ordered to this somewhat humid and... fragrant place, I cursed my lot in life.$b$bDuring my studies, however, I grew to appreciate my surroundings. It has a certain charm, don't you think?$b$bAh, and my studies, of course, were to allow other mages to return here with a spell. Shall I teach you?
12927	Most of my brethren are disdainful of the Horde's \\"barbaric\\" ways, and I once counted myself among them. When I was first ordered to this somewhat humid and... fragrant place, I cursed my lot in life.$b$bDuring my studies, however, I grew to appreciate my surroundings. It has a certain charm, don't you think?$b$b...you wouldn't be interested in my studies, of course, not being a mage yourself.
12933	Sinu a'manore. If you seek to learn how to conjure a portal to Theramore, I can show you.
12937	Here for a ride, $r?$B$BOr, is something else bothering you?
12938	Listen here, now. When you're looking for answers nothing beats a good explosion - the bigger, the better!$b$bBut that's probably enough with the questions for now, $r.$b$bMy warheads are classified material, and the element 115 that I created to power them is even more classified!$b$bIn fact, it's best that you just return to your everyday life and pretend we never met.
12939	Welcome, adventurer. You've come just in the nick of time.
12942	Does being in the presence of a Black Dragon make you nervous?$B$BGood. It should. It makes these dragons nervous too. They cling to their ancient virtues though - they wouldn't dare attack me here.$B$BFools.
12943	Listen, $r.$b$bIf you're lookin' for a shredder to ride, you'll need to head up into the hills just north there.$b$bThis one's out of commission.
12944	At first we repaired them to harvest the forests here, but ever since the alliance arrived and the fighting broke out we've been using them as war machines.$b$bBelieve me, $c. If you've got a key, you'd be crazy not to use it.
12945	Grekk holds them.$b$bMaybe he'll give you one if you help him out. The next time you're up north at Blue Sky logging Grounds be sure to talk to him.
12946	Yes?
12949	The Infinite Dragonflight is attempting to alter the destiny of Prince Arthas Menethil. You know him now as the Lich King, but here and now he was still a Prince of Lordaeron trying to do what was best for his kingdom. Arthas makes a very fateful choice today, leading to something we Keepers of Time call an inflection point in the timeline.
12952	The Infinites are attempting something unusually subtle for them. They are trying to hide the evidence that will lead to Arthas deciding to cull Stratholme. Their agents have used illusionary magic on the plagued grain shipments in the nearby countryside to make them appear normal. I need you to find the hidden grain, and use this Arcane Disruptor on the shipments. Arthas' men are looking for plagued grain, and should find it quickly with the illusion gone.
12953	I don't think we can afford to pass an opportunity to ingratiate ourselves with the red flight. With the battles ahead, having them as allies would be invaluable.
12958	<The commander stops his lesson and turns, his eyes appraising you, sizing you up.>$B$BI have use for one such as yourself, $c.
12960	Yes, $c, what is it?
12961	It's good to see you again, $N.$B$BCome for a refresher in Scourge tactics?
12963	Darling, those shoes are to die for!  I mean that literally.  Who did you kill for them?
12968	Hey, I see ya got some Brewfest tokens.  If ya want, I still got a few Brewfest goods to sell.
12976	$N, good to see you!$B$BOr is this the first time that we've met?$B$BI'm in so many places and times right now, I sometimes have a hard time keeping track of all of it.
12982	I left a war once to tend to the troubles back home in Westfall. That seems like a lifetime ago. Thank the Light that the Defias are no longer a threat.$B$BWe're a long way from home up here, but if we don't win this battle, there may not be a Westfall to return to.
12990	My warmages are inbound and will arrive presently.$b$bSpeak to me again when they have returned,
12991	Pardon me, $r, but I am on official business and cannot be disturbed.$b$bPlease excuse me.
12992	Good work! Arthas now knows about the plagued grain in Stratholme, and is about to begin the culling. Something is still not quite right, though. I sense a foreign presence in this timeline besides us, and that must mean the Infinite Dragonflight are here somewhere.
12993	I don't know, and that worries me. I'll do everything I can to find the Infinites. What I need you to do now is stay close to Arthas by joining his army.
12994	Well, you're not going to sign recruitment papers or anything, but you are going to fight alongside him. You need to make sure Arthas culls Stratholme and defeats Mal'Ganis. Without Uther and Jaina around, he'll need all the help he can get. If you talk to Arthas, he'll put you to work destroying the forces of Mal'Ganis. Follow along until I can figure out what's going on with the Infinites. I'll contact you again when I know more.
12995	Good luck, and be safe. Here comes Uther and Jaina now.
12999	Time was when I'd pull yer heart out ya just ta see da look on yer face....
13001	Ey, mon!$b$bGood to be seein' ya again... $N, right? Yes, yes, of course.$b$bYou and I gunna be real good friends. Drakuru know dese things.$b$b<A grin slowly spreads across the troll's painted face.>
13011	Oy, mon!$b$bThis not be what it looks like. Well, maybe...$b$bIt be complicated.
13012	Oy mon! I know you?$b$bAhh yeah, Prigmon not forget a face.$b$bYou... followin' me, mon? Cuz whatver it be, Prigmon never done it!
13018	Greetings, $r.$B$BIf you are interested in helping with the defense of the temple, please speak with Lord Afrasastrasz inside.
13019	Welcome to me camp, $r.$b$bShe don't look like much, but she's home fer now.
13023	Mr. Floppy and I went for a walk, but then we got lost and I was really scared, cause there were these wolves, you know, and they chased us, but then I saw this tower and Mr. Floppy and I hid here and the wolves finally went away after a while and it was terrible and now we don't know how to get back home.
13024	I think you should go, $g mister:miss;. You're scaring Mr. Floppy.
13026	The forces of the Scourge bear down upon us.  Take heart, and fight on!
13028	We must resist!  Gird your soul!  Burn the foul plague wherever you find it!
13030	Greetings, $c!$b$bI hope you don't mind a little hard work. We could sure use a hand here.
13031	The wind and trees whisper of unseen troubles.  The land appears healthy, but there's more going on here than meets the eye.
13033	Hides for the Horde, mon!  Only the best for our troops!
13034	Some supplies for the road?  Perhaps a refreshment to enjoy while you watch the fights?
13035	Enemies are closing in on us from all sides, and all the elders talk of abandoning this post. I say we should stand and fight like the warriors we are.
13042	I call 'er the Spirit of Gnomeregan. Isn't she a beaut? Without your help, she'd've never been restored.
13045	We're in a fine mess here.
13047	Thank the Light for you!
13055	Missing US text
13057	Missing US text
13059	Missing US text
13060	Oh... I'm feeling groggy...
13061	Don't bother me, $c!  I have two whole cauldrons of bubbling brew here and I must ensure they taste just right!$B$BIf they don't, then Master Coren Direbrew will flay and boil me!
13062	Missing US text
13063	This is getting good!  It really warms the stomach!  And $N, I have to say, you're a sharp dressing $gfellow:lass;!
13064	This is good stuff!  But it's a little weak.  I think I'll add a little more garlic breath to it...
13065	Missing US text
13070	This is a fine mess.
13074	I wouldn't do this on any other day, but... I'm thirsty and I hate drinking alone.$B$BBottoms up!
13077	BOOM!$b$bThat's the last thing I remember...
13078	<sigh>...$b$bA little help here, perhaps?
13079	Don't mind me. I'm just an old man, waiting on an old... friend.
13080	Ohhh, the pain is... overwhelming....
13081	Hurry, $r.$b$bTime is running out for me.
13082	Hurry, $g brother : sister;. I'm leaking here....
13083	<sigh>... Do you think we could move out, $c?$b$bI'm losing fluid fast!
13089	What is it? Can't you see that I'm busy?
13093	Listen, you tell Schweitzer and Roitau that we've got everything under control here. They don't gotta... what?$B$BThey didn't send you? Then what are you wasting my time for?$B$BI've got work to do!
13097	Greetings, $r.$b$bI'm afraid you must excuse me as I'm terribly busy at the moment.
13098	Time is of the essence here, $n. Are you prepared to be tested?
13118	Ugh, I should never have volunteered to be a specialist. They always ask us to do the impossible!
13120	<The captive crocolisk lets out a low growl as you approach.>
13121	Excellent day for a foray into the field wouldn't you say, $g sir : ma'am;?
13134	Bg'grrml brgl brm!
13135	Let me out of here, $r!
13147	Have you ever seen drakes like the ones around here? Makes for perfect hunting.
13156	This post is secure, $r.$b$bThe enemy has been cleared from the area for some time now.
13157	Thank you for freeing me, $r.$b$bI'm still a bit woozy from the venom. I think I'll stay here until my strength returns.
13177	Gather your senses quickly, we must press on.
13180	Zim'Torga is able to provide us with a certain level of protection, but she has been greatly weakened by the presence of the Scourge and the actions of the Drakkari.$B$BIt falls to me and Ahunae to see to the rest of our defenses.
13237	The trickster Mage-Lord Urom protects the third ring.  He will appear alone and defenseless, but do not be fooled by appearances!  Urom is a powerful conjurer who commands a menagerie of Phantasmal creatures.  Seek him out above.$B$BI can grant you the power to call upon a drake from the Red Fight.  Speak to Eternos or Verdisa if you prefer to draw on the power of the Bronze or the Green.
13238	Your greatest challenge lies ahead.  Ley-Guardian Eregos is a Blue dragon of immense power. You will find him flying above the uppermost ring. $B$BThe full power of your drakes has been unlocked.  Use their power to defeat Eregos!
13239	You have wrested control of the Oculus from the forces of Malygos.  The Red Flight is in your debt.
13240	The Bronze Flight is in your debt.
13241	The Green Flight is in your debt.
13254	Ruby Drakes excel at mitigating damage and protecting their allies.$B$BUsing Searing Wrath, they can breathe streams of liquid fire that jump from target to target, dealing increasing damage with each jump.$B$BWhenever a Ruby drake is damaged by an enemy attack, it gains an Evasive charge.  These charges can be used to perform a series of evasive maneuvers, allowing the drake to dodge incoming attacks and spells for a time.
13255	A Ruby Drake at full power can perform Martyr, which shields friendly targets by redirecting all hostile magic to the Ruby Drake for a short time.  Evasive Maneuvers can still be performed during Martyr.
13258	Emerald Drakes excel at healing themselves while poisoning their enemies.$B$BUsing Leeching Poison, they can steal health from their enemies.  Repeated applications of this poison can increase the effect.$B$BWith Touch the Nightmare, Emerald Drakes can reach into the Dream, converting a portion of their life energy into a highly damaging attack that leaves the target weakened, reducing its damage for a short time.
13259	An Emerald Drake at full power can perform Dream Funnel, which transfers the drake's own life energy to a friendly target, healing it.  Leeching Poison can be used to restore health lost when using this ability.
13261	Welcome to the camp, $c.
13265	Ponder on da thing you have witnessed this day, $n.$b$bDa future already be written. Only thing to decide be your part in it, mon.
13268	Belgaristrasz speaks the truth; time is running out!$B$BThe full power of your drakes has been unlocked.  Use their power to defeat Eregos!
13269	Belgaristrasz speaks the truth; the situation is grave indeed.  $B$BThe full power of your drakes has been unlocked.  Use their power to defeat Eregos!
13271	Take it easy on old Nass. He's not as young and resilient as he once was.
13289	Move along. Nothing to see here.
13290	<Bloodrose eyes you curiously.>$b$bI cannot help but wonder what makes you worthy of such attention.$b$bNo offense....
13293	Please hurry, $N. I am in a great deal of pain and time is running out.
13301	We're tryin' ta blow this wall so Wick's men can work on the new Harbor gatehouse and road beyond, but the clueless sod is cryin' about me using too much powder!$B$BTch. I've been sappin' since he was in diapers. This goes on much longer, I'll kick him into the canal and finish the whole blasted job meself!
13302	We're building another road down into Stormwind Harbor as soon as this wall has been removed... but this mad dwarf brought enough powder to level the entire quarter!$B$BI don't know what Master Alexston was thinking when he hired her... she's foul-mouthed, mean, and stubborn as an ox!
13303	The Scourge are a blemish upon these pristine lands.  By the might of my creators, I will crush every last one of their decrepit bones under my heel.
13307	Looks like you had the same idea I did. Hunting for fruit, are you?
13308	Loken?! That's downright bothersome... We might've neutralized the iron dwarves, but I'd lay odds there's another machine somewhere else churnin' out a whole mess o' these iron vrykul!
13311	Look for the eastern Zeppelin Landing Tower outside of the city to the southeast.
13321	From this dock, The Bravery travels back and forth between Stormwind and Auberdine.
13322	My poor flying machine. She didn't survive the crash and without spare parts, I'll never get 'er up and running again!
13324	Soon, $n!$b$bSoon ya be tastin' true power. Soon ya be rewarded for your dedication and service.$B
13328	Welcome. May I offer you rest or sustenance?
13331	Do you like the new home that I've carved out for my so-called worshippers?$B$BIn the throes of my death, I cursed them all and dragged them along with me into this special underworld of my own creation.$B$BI think that I shall delight in their eternal torment, but what I really want is to exact revenge upon my former prophet!
13342	Come to buy from Hargus, you have?
13348	Another supplicant seeking the favors of da Lich King?$b$bOnly da worthy be obtainin' da dark gifts....
13352	I hope the archmage appreciates what I've gone through to uphold Hemet's end of the bargain.
13353	You should be sticking close to Arthas right now!
13364	Kartak comes for big-tongue meat. Frenzyheart make sure plenty is ready.
13366	Everything okay?
13367	Hi! How you? We're good... yup, good good. Hi!
13368	I am forever in your debt, $N.
13375	Nice day for flying, isn't it?
13376	I know an ace when I see one.  Thanks again for saving my life!
13382	Look at what you have done, death knight! You have brought glory to the Scourge!
13390	Lemme outta here, mon!
13391	You Scourge not welcome in Zul'Drak!
13396	How dare you! Get out of my sight!
13397	It's only a matter of time before the plague overtakes New Avalon.
13402	Fineous has what you need, friend.
13422	$n! I've been awaiting your return. What be takin' ya so long, mon?$b$bIt be time to complete da conversion of da Blightbloods.$b$bJoin me and witness the creation of our army!
13431	This isn't quite what I signed up for, but hey... at least it's warm here.
13438	One day, Rejek be mighty warrior.
13445	These monsters killed my father and kidnapped my sister.  They're going to pay for this!
13449	Welcome to my kitchen! We prepare some of the finest food in Dalaran here.
13451	Hope you take it to big-tongues good. It about time they go away.
13455	I do not believe you possess the mental acuity to grasp the nature of portal magic.$B$BHowever, you can use the crystal behind me to teleport to the ruins below Dalaran in Crystalsong Forest.
13456	As a mage, you are one of a select group that can conjure a portal to transport you back to this very place.  I can teach you if you are ready.$B$BAnd remember that you can always use the crystal behind me to teleport down to the ruins beneath Dalaran in Crystalsong Forest.
13461	Welcome, friend, to the barbershop! Come for a cut? A coloring? Something else, perhaps?$B$BWe can groom facial hair, perform piercings, reshape tusks and horns, and even modify undead features!$B$BHave a seat and we'll get right to work. You're only a few coins away from a new, more attractive you...
13468	Your greatest challenge lies ahead.  Ley-Guardian Eregos is a Blue dragon of immense power. You will find him flying above the uppermost ring.
13469	The Halls of Stone, a level 77-79 dungeon within Storm Peaks, is now available for testing. Please be in your full group before teleporting to the dungeon. Meeting Stones are not available for this dungeon yet.$B$BTo leave the Halls of Stone, simply exit through the normal exit inside the dungeon and you will be returned here. If you die and release, you should teleport back from this NPC.
13470	What are you doing all the way back here? You need to get back to Stratholme immediately! Shall I teleport you to Stratholme?
13471	Go find those hidden plagued grain crates and use your Arcane Disruptor on them! Arthas will then have the evidence he needs to begin the culling of Stratholme.
13472	What are you doing here? Arthas is at the entrance to Stratholme right now and you should be with him! Go!
13474	Pet families come in one of three types. Ferocious pets, like cats, can dish out damage but can't take it as well. Tenacious pets, like turtles, are more defensive and can occupy an enemy's attention while you stay at range. Cunning pets, like spiders, have a mix of offensive and defensive abilities and are particularly useful in Battlegrounds and Arenas.$b$bAs your pet gains more experience, it can learn new talents just like you can, but at a slower rate. If you ever want to change your pet's talents, just come back to me.
13475	Are you certain?$B$BThere is no turning back once I wipe the knowledge of the talents you have learned from your mind.
13476	Very well. It is done.
13481	UDB Missing US text
13485	Here is where I sacrificied everything to free my father. Now I come to destroy it...
13501	Here you are, $n.$b$bNow please, return your focus to the task at hand....
13502	Our storehouses have been depleted.  I have nothing to sell until we can get more supplies.
13503	Because you've managed to replenish some of our supplies I can get back to cooking.  Now, what can I do for you?
13506	Why is everyone looking at me as if I crashed the ship?
13510	Hmm... something familiar about your face $r...  Give me a moment...$B$BAh ha! Westfall, that's where I recognize you from.  You are $n!  It's good to see you again.  But, let's hope you can help us finish the job this time.$B$BNow we're a long way from Westfall up here, but if we don't win this battle, there may not be a home to return to.
13511	$N!  I hardly recognized you in your new outfit.  Still have that tunic... or did you take the chausses... or was it the staff?   I can't recall, it was so long ago...$B$BWell, I'm glad you are here to help out again.  We could use all the help we can get.  $N, if you perform the way you did back in Westfall with the People's Militia, we have a chance.$B$BThese are dire times, if we don't win this battle, there may not be a Westfall to return to.
13512	With the Light's blessing and your help, $N, the Defias are no longer a threat.$B$BBut we're a long way from Westfall up here, and if we don't win this battle, there may not be a home to return to.
13519	Greetings, friend.
13525	Yes, the Lich King will fall to our might. We will have our final revenge.$B$BBut first, we will see to it that the plague known as the Scarlet Onslaught comes to an end once and for all!
13526	Very well, but if I were you, I would pay attention and not just blindly nod my head at what I heard.$B$BIt begins, as all good stories do, with betrayal. Oh, it's not that we were betrayed... not at all. The Lich King raised us death knights above all others.$B$BRather, it was we who betrayed him with the help of Highlord Darion Mograine.$B$BIn the final fight at Light's Hope Chapel in the Plaguelands, with the simpletons moments away from annihilation, Tirion Fordring helped Mograine break the Lich King's hold upon him and all of the rest of us that were present.
13527	With the Lich King fleeing in fear of Fordring armed with the Ashbringer, we were able to easily wrest Ebon Hold from the remaining Scourge forces.$B$BThat didn't settle things between us and the Scarlet Crusade, however.$B$BAs the Forsaken have learned the hard way, the Scarlets cannot seem to differentiate between us and the Scourge.$B$BWe think on our own, we have our own motivations, we have almost all of the qualities of the living, and yet to them, we are no different than the mindless slaves of the Lich King.$B$BMistakenly they think we will roll over and play dead.
13528	<The lord-commander fixes you with a stare before going on.>$B$BI was getting to that. Indeed, when High General Abbendis landed her forces on Northrend, she changed their name to the Scarlet Onslaught.$B$BIt was not long before Admiral Barean Westwind presented himself to her at New Hearthglen in the Dragonblight. From all accounts, she wasn't expecting him. Nor was she expecting that he would undermine her authority and take the reins of command away from her.$B$BLikely you were involved with her demise, but no matter. Once she was dead, the admiral made a mysterious exit and we lost track of him.
13529	As I said, we lost track of him, but this is something that I'm sure you will be able to figure out for me. My suspicion is that he's down there somewhere, but my spies that have returned haven't been able to place him anywhere on the island.$B$BThe Forsaken at Venomspite did a good job of sabotaging New Hearthglen, but the Onslaught forces that are present down there are the battle-hardened remnant from that place. Unfortunately, they picked up better equipment along the way, as well as gryphons taken from fools somewhere.$B$BWhat I'm trying to say is that this isn't going to be a stroll in the countryside, $N, even for you.
13530	We'll start in just a moment.$B$BI just want to be very clear -- we're not here to soften them up. We're not here to make a dent. We're here to put an end to the disease that calls itself the Scarlet Onslaught.$B$BIf you don't want any part of that, if you don't have the stomach, fly away now. I want someone with us who is going to be here every day until the job's done.$B$BAre you that $g man : woman;, $N?
13531	<The lord-commander flashes a rictus grin, looking you up and down discerningly.>$B$BThat's what I wanted to hear.
13534	Consider all of the suffering that the Scarlets have caused over the years. The torture, the zealotry, the murder.$B$BI won't allow that to continue. Will you?
13540	The Hyldsmeet is sacred.  Whoever earns victory is assured a lifetime next to Thorim.
13548	Greetings, $N. 
13557	Greetings, $c. I can help stable your pets or assist you in recovering lost companions.
13573	You stand before a master of the Arcane. One would be unwise to challenge me. Many corpses have been left ablaze in my wake.
13574	My life and spirit has been filled with memories of the insufferable Horde. Times of sorrow, desperation, and sacrifice have come to pass. The rage of battle could never leave my heart!
13581	What be happening?$B$BYou here to eat, mon? Or maybe to learn cooking from the best, eh?
13583	Looking for a tabard?
13584	Greetings, $c. I can assist you in recovering lost companions.
13591	Hello there! Care to buy some fishing supplies, or perhaps take a lesson or two?
13609	It is good to see you again, $N. How could I ever forget the $g man : woman; who saved my sister's life?
13610	It is good to see you again, $N.
13611	<The Frostborn Scout attempts to rise to his feet as you approach, but stumbles back to the ground, clenching an obviously painful wound in his side.>
13612	I don't think that's going to happen, $G lad:lass;. I've lost a lot of blood... there's no way I'm making it back.
13613	A pack of harpies came up from the valley. A big one named Sirana led them... I didn't have anywhere to escape. They haven't been this aggressive for a long time... I didn't expect it... I let my guard down.... it's my own fault.
13614	It's a little late... for that... $G lad:lass;.$B$B<The Frostborn Scout coughs up some blood on the snow.>$B$BGet... that wench in charge for me...$B$B<The Frostborn Scout slumps over as he breathes his last breath.>
13637	Be welcome amongst us, $c.
13640	Listen to what I have to tell you about our enemy before we start. You don't want to be unprepared while we're out smashing Scourge in the field.
13641	<Brann looks at you expectantly.>
13642	Imagine all the wisdom and knowledge locked away within Ulduar. The very secrets of life could be held there!
13646	Boktar thinks this crash an unfortunate event, but I believe we're intended to learn something from it.
13658	We're in over our heads, $r! Watch your back!
13661	Well met, Battle-Sister. I can assist you in recovering lost companions.
13663	Come, Battle-Sister.$B$BFeast, sleep, so that you may fight with all your strength!
13673	I can take care of myself, $N.
13680	You're the champion now, buddy! Do you think you have what it takes to defend your title?
13682	Go back to work before the overseer sees us.
13695	Hey, I recognize you! I guess I have you to thanks for me being here. That teleport accident was the best thing that ever happened to me.$B$BIf you find yourself back in Borean Tundra, let my goody two-shoes nerd of a duplicate know that I've move up in the world quite a bit!
13699	I no longer train Death Knights, having grown weary of cretinous Initiates and their constant questions.$B$BNow begone.
13702	How may I help you?
13703	Greetings, $N. This is the workshop of Keeper Mimir.
13731	What a landmark discovery! The Royal Apothecary Society has spent years working to break the secrets of the Lich King's plague, and I've finally done it!$B$BDespite this turning point in history, there is still so much to discover. I have more experiments to conduct... test subjects to acquire...$B$BAt least I don't have to worry about Scourge necropoli. The Alliance is dealing with that problem. This leaves me plenty of time to delve into the secrets of the plague and uncover what I can.
13734	What can I do for you?
13737	How may I serve you?
13738	What do you want?
13748	I do not trust you enough to speak of such things.$b$bYou must respect the trials our people have endured, the burdens we have borne...$b$bPerhaps, if you were to bring great honor to Dun Niffelem, I would be inclined to share with you the knowledge of our people.
13759	Hello, $r. How can I help you today?
13761	Sorry, friend. Only certified officers of the Horde can authorize the purchase of a vehicle.
13764	Good to see ya again!$B$BKing Stormheart has informed me that he will be taking his leave for a time... a grim memory brought back to him has left him with a score to settle it seems. He was very insistent that we not join him, so we have respected his wishes as we always do.$B$BI have taken responsibility for our clan in the meantime. You are still welcome with us, of course.
13776	You are no taunka. Why have you come to the sacred burial grounds of our warriors?
13777	Look at them... all they care about is outdoing each other.
13778	You see, Thorim is not like these harpies.  He's a worthy being of near godlike stature.$B$BHe served the titans as guardian of Ulduar and the Terrace of the Makers.$B$BThat is until his wife, Sif, was cowardly slain by his brother.
13779	Thorim lost it.  He lashed out against his most beloved allies, the frost giants.$B$BThat's one reason why to this day, this land is torn apart by the war between the Hyldnir and the Sons of Hodir... and why Thorim has exiled himself to the Temple of Storms.
13780	What do I care if these she-wolves and the frost giants kill each other every day?$B$BNo, no... I want Thorim to break out of his stupor and rally all his allies to retake Ulduar.$B$BThe world will be torn asunder if he fails to accomplish this!$B$BAnd of course, I'll reward you appropriately.
13783	Men -- can't live with them, can't live without them.  Well, you can... but it's just really boring.
13784	These mines are a dreadful place.  Fortunately, I don't plan on being here long.
13785	Bears are beautiful creatures.  Wild, strong and fierce in battle... much like us, sister.
13788	Someone called for me...?
13790	Hello, hello!
13792	Hello, peach - good to have your company!
13797	We discovered these proto-drakes at the Bronze Dragonshrine in the Dragonblight. We knew at once that they were kin - our blood from ages past.$B$BMy apologies, $c. You are probably confused. I am Penumbrius of the bronze dragonflight. I have taken this form out of convenience. It is much easier to communicate and live amongst mortals while in the mortal guise.$B$BHow can I help you?$B
13798	Hello, $n! How can I help you today?
13816	Elder Skywarden can be found near Agmar's Hammer in Dragonblight.
13819	Elder Chogan'gada can be found in Utgarde Pinnacle.
13820	Elder Lunaro is at the Ruins of Tethys in Grizzly Hills.
13823	Elder Kilias can be found inside Drak'Tharon Keep.
13828	Elder Fargal looks over Frosthold in Storm Peaks.
13833	We cannot allow the Horde to turn the hidden secrets of the Strand of the Ancients against us. Will you join our brave soldiers there?
13834	We cannot allow the Alliance to turn the hidden secrets of the Strand of the Ancients against us. Will you join our brave warriors there?
13838	The Fleshwerks is the heart of the Scourge's ghoul, abomination, and flesh giant production. If we can take it out, the Lich King will be greatly weakened.
13841	What do you need?
13843	We serve Thorim, sister.
13844	It is always a pleasure to meet heroes such as yourself in this forsaken land. Is there some form of assistance that I can offer you?
13846	Well met, $c.  My advice to you is this: as you travel the world, be wary of magic for it will burn the untrained.
13847	Of course! Go with Elune's blessing.
13851	We mustn't lose our focus. The dangers inherent in getting lost in the moment could put us in peril. Alas, the soldiers need a respite from this madness.$B$BBask in the victory, $N. If not for you we might have lost the Vanguard.
13896	The taking of Crusaders' Pinnacle is only the first step in a long and dangerous journey. There is much left to do before we are able to assault Icecrown Citadel.$B$BIt can only be possible with help from you and others like you, hero.
13902	Orgrim's Hammer is ready to strike in Icecrown.  You will find no finer vessel.
13905	The only reason that you still live is because of my curiosity.
13908	Whatever you're going to ask for, do it quickly.
13910	We'll take over from here, you've earned quite a respite after that battle.
13911	What is it?
13915	The Argent Dawn coordinates the Scourge's opposition at Light's Hope Chapel in the Eastern Plaguelands.  Go there for instructions.
13918	Many have fallen within Valhalas and their corpses are a testament to the strength of our ways.$B$BWill your bones litter this place of honor and battle as well, $N?
13919	I should kill you where you stand, $r!$B$BGet on with your inane prattling and then begone!
13921	You have not yet proven yourself worthy enough to issue a challenge within Valhalas, $N.$B$BReturn when you have earned a name for yourself.
13922	Many have fallen within Valhalas and their corpses are a testament to the strength of our ways.$B$BWill your bones litter this place of honor and battle as well, $N?
13930	Uhnhh.... Don't... bother with me.$b$bI am... finished...
13931	Gathering... information... on the Scourge.$b$bAlliance forces appeared...$b$bWe took cover - waited until they attacked the gate... then, we hit them from the rear.$b$bPinched between us... and the Scourge... it was too much for them....$b$b$g Brother:Sister;... it was... glorious.
13935	I have given my all... for the Horde...
13946	Champion $N, it is good to see you again.$B$BHave you returned to Valhalas to assist a friend with their challenges?
13948	Wait, $g brother:m'lady;....$b$bOne last thing...
13950	Great job! Arthas is safely on his way to Northrend!
13978	The Fleshwerks will never again produce soldiers for the Lich King's armies.
14014	Please respect the laws of Dalaran while you are here, stranger.$B$BWere you lost? Is there something I might help you find?
14028	The Scourge must be stopped at any cost. We cannot permit them to field the army they're constructing here.
14033	Our way is sacred.  We will choose death before we abandon Thorim and join the likes of the Lich King.
14035	Please, $r.$b$bRelease me...
14037	I can hardly believe the Cult was so careless as to leave these behind.
14040	How can I help?
14041	What can I be helping you with?
14042	Good Morning!
14043	Is there anything you can pay me to do?
14046	The air battle rages close, $n.  Both we and the Horde send bombers into the Bombardment and the Valley of Lost Hope.  Will you enter the fray?
14050	Are you ready to begin the assault and win back the Undercity for the Horde, $N?
14051	The elements are with us in force, $N. With their help, we will do all that is in our power to stop Varimathras and Putress! LOK'TAR OGAR!
14052	Oh my gosh! Keep your voice down, $N! What? Are you trying to get us killed?!$B$BOf course I know who you are! Who in the Alliance doesn't know the name, $N?!$B$BSay, what do you think of my jumpbot? She's based off of the mechagnome design. Sleek and aerodynamic!
14053	Woah, woah, woah! Keep it down, $N. Keep it down!$B$B<Blast looks around.>$B$BWe don't want those frosty vrykul noticing us, now do we?$B$BWhat do you think of my jumpbot? I based it off of the mechagnome. Pretty slick, huh?
14055	We don't have any easy path before us. If you've got a strong arm on you, stick around until one of my squads is ready to ascend to Ymirheim. They could use all the help they can get.
14061	Well you're an ugly one! Don't mean you don't know how to fight though.$B$BOne of my squads should be geared and ready to march soon - get your sorry butt in line and make the climb with them!
14062	Ranked arena matches start again in $6318d.$B$BWould-be champions are already busy honing their skills and acquiring the best gear they can. Are you going to be ready?
14066	This portal leads to the Caverns of Time, deep beneath the earth in far-off Tanaris.$B$BUntil you have grown stronger, though, I must ask you not to travel there.
14067	I can smell the gunpowder from all the bombs and rockets!  You want to get out there and join the fun?
14068	The voices are talking to me.
14069	We're still making preparations. We won't be ready to go for a while.
14070	We're almost ready to depart. Just give us a little bit longer to finish our preparations.
14072	In my travels I have learned the recipe for the Wispcloak.$B$BThis cloak is a tradeable Epic spellcasting cloak that grants Stamina, Spellpower, Intellect and Mana Recovery.   I am looking for someone worthy to teach this recipe to.$B$BSomeone who had completed all the normal dungeons of Northrend and had the \\"Northrend Dungeonmaster\\" achievement would be worthy of learning the recipe for the Wispcloak.
14074	I have ventured to dark places and learned the tailoring recipe for the Deathchill Cloak.$B$BThis cloak is a tradeable Epic cloak for spellcasters that grants Spellpower, Haste and Critical Strike.   I am looking for someone worthy to teach this recipe to.$B$BSomeone who had completed most of the quests across Northrend and had the \\"Loremaster of Northrend\\" achievement would be worthy of learning the recipe for the Deathchill Cloak.
14076	Since you are a tailor of some skill, I can tell you that I know some special recipes.   I know recipes for both the Wispcloak and the Deathchill Cloak.
14084	Greetings, $c.$B$BWhen the Horde controls Wintergrasp Fortress, I will open a portal for those who wish to travel there.$B$BThe next battle begins in $3975w:$3976w$3782w:$3784w$3785w.
14085	Greetings, $c.$B$BThe Alliance now controls Wintergrasp Fortress. Use the portal, if you like.$B$BThe next battle begins in $3975w:$3976w$3782w:$3784w$3785w.
14086	Greetings, $c.$B$BThe Horde now controls Wintergrasp Fortress. Use the portal, if you like.$B$BThe next battle begins in $3975w:$3976w$3782w:$3784w$3785w.
14087	Greetings, friend.  Something I can do for ya?
14088	Hey there, hold on just one second.  I see you're not riding a flying mount of your own.$B$BYou probably won't be of much use to the other goblins here if you can't get around.  They've paid me to loan my used mounts to people such as yourself -- at no cost to you.$B$BInterested?
14089	I've got a lead on Norgannon's keystone, which guards access to Ulduar's archives, but the Titans divided it into two pieces and secreted them away.$B$BOne of the pieces, the keystone's shell, is held within the Inventor's Library on the northern coast, south of Ulduar itself. The first thing you'll need to do is retrieve the fragments of an access disk from the library's guardians.
14090	When it comes to treasure, never be lookin' sideways at lootin' someone else's junk. Stolen goods be much sweeter, ya? But free is free, no matta how it got that way!
14115	Come to make yourself useful?
14118	The secret to goblin engineering has nothing to do with keeping things from exploding. It has everything to do with directing the explosions exactly where you want them.
14119	I am Xarantaur, the Witness.
14120	I was one of the first tauren druids, of the last generation taught by Shan'do Cenarius, before the Legion, before the Sundering, when the world was still young. Before everything changed.$B$BWhile my brethren hunted great beasts, I hunted stories. I had been drawn to the druidic arts by this hunger, this lust for knowledge. For a time, that hunger was sated as I learned to talk to the trees, rocks, and beasts, and heard their stories.$B$BBut then, the time came when Cenarius walked among us no more and my brethren began to forget what he had taught us. I could not forget, though, and I still needed to learn more about our world.$B$BSo I said my farewells and travelled beyond the lands of my people.
14126	How may I help you?
14128	How may I help you?
14134	Got somethin' that needs tightening, $r?
14137	We've lost a few good people up here already. I'm beginning to doubt that this place is worth our attention.
14142	The final battle will begin soon, $N. Stand at attention!
14149	You are welcome here, friend and ally of the Dragonflights. Take your rest here in our halls.
14150	Ah, it's you, $N! Welcome into our sanctuary. Rest and refresh yourself; you have more than earned it.
14155	It's been a busy day in the air, eh $N?  Maybe you should take a moment to catch your breath before going back out.
14159	Careful, $N.  Where are your cultist robes?
14160	There you are.  Are you ready then?  Once we start, there is no turning back.
14169	Do you possess the courage to face Malygos' elite drakes in their own realm, $r?
14170	UDB missing US text
14172	Sorry, friend. Only certified officers of the Alliance can authorize the purchase of a vehicle.
14177	Isn't it just beautiful? Can you see the potential profit?
14179	Hello, little $r.
14180	Just because something isn't broke doesn't mean you can't fix it.  You lookin' for something, sweety?
14182	The U.D.E.D. dispenser rumbles at you expectantly.
14198	The Emerald Dream has become a dangerous place. I grow increasingly concerned for those who have sacrificed their waking life in Azeroth in hopes of saving it.
14204	Make it quick, $c.
14209	Yes, little one?
14213	Big, sparkly, magic book help make Glyphs for spells and abilities. Always find near inscription trainer, in The Apothecarium.
14215	Make it quick, $r. I am weary and have no time for pleasantries..
14218	There you are!
14227	Ah, Noblegarden. So amusing to watch others throw away their dignity in favor of hunting colored eggs. Still, they do have a curious magical aura to them...
14229	Candy! That's what I'm talking about; I just wish I didn't have to run around finding it!
14231	Hey, if people want to run around rooting in the dirt for colored eggs, who am I to judge? I still get a cut of the profits on paint, and I invested in chickens this year.
14234	We're celebrating spring during Noblegarden. Affirmation of life and all that.
14236	Yah, mon, this be the time to be glad of life and spring. Ya collect lots of eggs yet?
14237	This entire holiday is nonsensical. Colored eggs and \\"life affirmation,\\" bah.
14240	Greetings, $c.$B$BWhen the Alliance controls Wintergrasp Fortress, I will open a portal for those who wish to travel there.$B$BThe battle currently enues. Hurry to Wintergrasp and support our forces!
14241	Greetings, $c.$B$BWhen the Horde controls Wintergrasp Fortress, I will open a portal for those who wish to travel there.$B$BThe battle currently ensues. Hurry to Wintergrasp to support our forces.
14245	With the help of our new taunka allies, the Northrend will belong to the Horde.
14248	Greetings $c!  Welcome aboard the Cloudkisser.  Northrend can be a very harsh place.  I hope you have prepared yourself.
14249	You'll be after Benik Boltshear, then. He's located in the heart of the Dwarven District by the blacksmiths.
14254	Vesprystus' hippogryphs will bear you swiftly to your destination.
14286	After the Plaguelands and the Battle for Light's Hope Chapel, I didn't think that we would witness anything more horrible.$B$BI was wrong.
14313	Dig rats make some surprisingly tasty stew.
14315	Welcome, $g sir : my lady;. This is a much better camp than the one that I used to have.$B$BIt's good to have company. They've been nice enough to teach me some of their fighting techniques so that I can hold my own against the Horde.
14316	Greetings, $c. Our position here is a bit exposed given the build up of the Horde's forces to the south.$B$BAnything that you can do to help will be greatly appreciated.
14319	I thought I'd never be free from that terrible curse. You have my gratitude, stranger.
14320	Take it with my gratitude, $c.
14324	What may I do for you, $GSir:Dame;?
14325	Are you certain you want my help in the battle against Yogg-Saron?
14330	Missing US text
14332	Missing US text
14334	Mortals, I am indebted to you for freeing me from the terrible corruption that besets this place. Though I have not yet recovered fully, I can help you battle Yogg-Saron.$B$BI can grant you and your friends the Speed of Invention, increasing your damage and movement speed. In addition, I can destabilize the matrices of certain Saronite based life-forms, reducing their attack and casting speeds.
14344	What is it, $c?
14362	My, my, I never thought I would have the chance to see Ulduar myself. Why, when Brann asked me to help fund this expedition, how could I refuse?!
14363	I never thought we'd escape from that steamy jungle! Now I'm the lead engineer of this expedition. 
14364	These babies may look like scrap, but they can rush ahead, knocking enemies aside. The front ram has been overloaded with a electroscopic hyper capacitor, letting it discharge electrical blasts. $B$BEven the turret has been upgraded with anti-air rockets, providing it with a definitive edge over those blasted demolishers.
14368	These babies can hurl fire like none other. We've even attached a secondary cannon, a grappling hook and added a manual fuel injection system.  If you can obtain liquid pyrite from the mechanognomes, you can use it to hurl high-density explosives, or turbo-boost your movement speed. $B$BLet's see those Explorer's League twirps beat that!
14369	It's a good thing you guys showed up! The Iron Dwarves have pushed us back to this location, and we're barely managing to hold the line here. $B$BEven worse, they've begun to power up their magical defenses. If we don't attack soon, they'll be able to annihilate us in the blink of an eye!$B$BWe've managed to rebuild several siege machines, demolishers and motorcycles from the Alliance and Horde expeditions that were here before us. However, all of our pilots died in the last assault.$B$BYou must take the vehicles and storm the gates of Ulduar! $B$BPlease, $n! You're our last hope!
14372	Something I can do for you, Boss?
14375	Greetings.
14383	The console appears ancient though there is no sign of dilapidation or decay.  A single slot appears to fit large circular discs.
14392	Glory will be ours when we win this tournament in the name of Silvermoon.
14396	King Magni expects us to win the tournament and make him proud. We will not fail.
14402	When the tournament starts, all will see the Forsaken emerge triumphant.
14403	The competition will be fierce, but Orgrimmar's champions will decimate all who stand in our way.
14404	We compete not only for glory, but to bring honor to our ancestors and to our people.
14405	The Darkspears stand ready to face the competition and the enemy.
14420	There are secrets contained within these halls that are beyond our wildest dreams.
14428	It's a real honor to be able to aid Brann in exploring ancient Ulduar.
14429	Brann taught me everything I know about exploring.
14431	Well met, $c.$B$BI train Aspirants in the art of mounted close combat.
14434	The Melee Target trains Aspirants in both mounted attack and defense.$B$BApproach the Melee Target and strike it with a Thrust attack. The force of the blow often spins the target hard enough to injure you or your mount. This is where defense comes into play.$B$BBe certain to have at least one layer of Defend before attacking the target, and continue to stack and refresh Defend throughout the training exercise. Otherwise, you may well find yourself dismounted.$B$BThe same holds true in actual mounted combat: Balance attack and defense, Thrusting at every opportunity and maintaining your layers of Defend as best you can.
14436	Hey there, how are ye?$B$BCome ta learn the art o' the Charge, $c?
14437	Well then! A mounted Charge is about more than just kickin' yer mount ta full speed an' hollerin' yer lungs out... though that IS the fun part, heh! But the Charge Target will teach ye the finer points.$B$BA good Charge is all about distance and timing. Ye can't be TOO close, or ye won't get enough speed. But ye can't be too far away either or yer mount will tire! As for timin'...$B$BYe'll want ta make sure the Charge Target doesn't have a layer o' Defend up before ye rush in. If it does, use yer Shield Breaker ta make it vulnerable, and THEN Charge in!$B$BSame goes for the real thing: Try ta drop yer opponent defenses before ye Charge!
14438	Well. Another $c, come to learn the ways of the Shield-Breaker...?
14439	The ranged Shield-Breaker attack is simple to learn, but difficult to master. Alone it may seem weak, but in conjunction with Thrusts and Charges the Shield-Breaker makes a successful jouster.$B$BFind a Ranged Target. Take a moment to understand the Shield-Breaker's range... how much space you need, and how far you can hurl the lance.$B$BAfter that? Well. Start throwing, and do not stop until you've broken every last layer of Defend and pierced the vulnerable target.$B$BThis tactic will serve you well in actual mounted combat: Break down your opponents' defenses... and then crush them!
14441	All in good time, mon. I be havin' more work for you to do soon....
14442	Indeed you have, mon. Our stores of blight crystals be nearly sufficient!
14443	Darmuk's incompetence be hinderin' us no more! Patience, mon. Dere soon be more for you to do....
14445	Now ya be knowin' everything, mon! Prepare yourself... we attack soon!
14458	Apologies, $r, but only champions of Thunder Bluff may purchase what I have to offer.
14459	Away with you, $c!$B$BOnly champions of Undercity may purchase what I have to offer.
14460	Only champions of Orgrimmar may purchase what I have to offer.
14461	Only champions of the Exodar may purchase what I have to offer.
14462	Hi there!$B$BSorry, friend, but only champions of Gnomeregan can buy what I've got.
14464	Samamba tinkin' joo be at da wrong quartermaster!$B$BWhat she got only for de Sen'jin champions...
14465	Alas, only the esteemed champions of Silvermoon City may purchase what I have to offer.
14473	It's good to see you here, $N.
14474	It takes a lot of dedication to train and ride a Venomhide.
14489	You've already bested one of our riders today, so I cannot accept your challenge.
14492	You've already bested one of our riders today, so I cannot accept your challenge.
14496	Activating secondary defensive systems will result in the extermination of unauthorized life forms via orbital emplacements.$B$BYou are an unauthorized life form. Please confirm.
14497	Security override permitted. Secondary defensive systems activated.$B$BBackup deactivation for secondary systems can be accessed via individual generators located on the concourse.
14527	<The hatchling looks at you as if trying to determine whether or not you're its mother.>
14534	The Lich King's cruel reign has inflicted great suffering on all of Northrend's inhabitants, particularly the children. If you are a friend to the Oracles or Frenzyheart Tribe of Sholazar, perhaps you might consider caring for an orphan for a week.
14537	The orphans we have taken in come from war torn Sholazar Basin. You can choose to care for either an orphaned Oracle hatchling or a Frenzyheart pup. Either will be happy to make a new friend, but you will only be able to care for one of them.
14543	Can you feel it?$B$BThe spirit world draws close during the Day of the Dead. This is why we decorate the graves of our dearly departed with flowers and candles and offerings: To welcome them back, even if only for a time.$B$BSo come! Dance with me! Let us cherish and honor those we have lost in their ghostly presence, so that they might eat and drink and smile and know that they are loved.
14544	During the Day of the Dead, people gather in graveyards to celebrate with and cherish the spirits of those they have lost.$B$BYou can find the festivities in the cemeteries of any major city, where you'll be able to cook, dance, don costumes, and more.
14552	It's good to visit with friends and family again, celebrating and sharing stories of old.
14560	Surely you've been a student once in your life, $c. You learned from an instructor, and you gained respect for them in some way, yes? Maybe not as a person, but at the least, as one who knew more than you and was willing to teach you. If not, use your imagination...$b$bWhat would you do if you came to realize your instructor may not know as much as you thought, and that you may have found a better path?
14561	This is awful! I shouldn't be sitting here, useless, when there's so much to be done! If only my arm hadn't gotten injured up in Northrend... No use dwelling on it, though! Tahu will have me patched up and cured eventually, and we'll still help around here in the meantime.$B$BJust because we're not at the front doesn't mean we can't help out somehow.
14562	Another new face? It's so good to meet you. I'm Dellylah.
14614	Zippik would drive us straight into the Bluff if I wasn't here. Moron.
14617	Hey. I'm on break.
14621	Hey, sweetheart. The zeppelin that parks here'll take ya straight to Thunder Bluff, free of charge. Who needs wyverns when you got us goblins here, am I right?
14623	What're ye starin' at, $r? Come ta torment the condemned?
14624	<The Baron lifts his manacles.>$B$BCome on then, $c. Do ye trust me?
14625	Missing US text
14627	Hello, $N. If you're looking for cooking training, you've come to the right place. I usually get lots of new students when Pilgrim's Bounty rolls around.
14628	If you're interested in learning more about the traditional Pilgrim's Bounty feast, speak to any of the hostesses.
14630	Are you here to celebrate Pilgrim's Bounty with us?
14633	Welcome! Have you come to join us for a Pilgrim's Bounty feast? Please, have a seat at a Bountiful Table.$B$BTry everything! I'm certain you'll find something to your liking.
14634	Welcome! Have you come to join us for a Pilgrim's Bounty feast? Please, have a seat at a Bountiful Table.$B$BTry everything! I'm certain you'll find something to your liking.
14635	\\"Pilgrim's Bounty.\\" Hrm. I can understand the tauren's eagerness to express their sense of gratitude and comraderie to the Horde's warchief, but the Forsaken?$B$BI imagined they would have dropped such sentimental traditions long ago.
14640	Pilgrim's Bounty is a time to reflect upon one's good fortune and share with all around you.$B$BWe hope that all of our noble allies will join us in feasting and celebration.
14641	Such a stark contrast, this holiday, to typical human behavior. Who'd have thought such a relentlessly voracious people would make a celebration of giving and sharing?$B$BIt's pleasant to see. Darnassus should do its utmost to support and encourage it.
14647	A Bountiful Table is laid out with five Pilgrim's Bounty foods, one in front of each chair.$B$BWhile in a chair, you may eat as much of that food as you like, as well as pass servings of that food to the other chairs. Feast and share with friends!$B$BIf you eat enough of any one food, you'll gain benefits unique to that food.$B$BIn addition, if you eat enough of every food, you'll gain the Spirit of Sharing!
14648	A Bountiful Table is laid out with five Pilgrim's Bounty foods, one in front of each chair.$B$BWhile in a chair, you may eat as much of that food as you like, as well as pass servings of that food to the other chairs. Feast and share with friends!$B$BIf you eat enough of any one food, you'll gain benefits unique to that food.$B$BIn addition, if you eat enough of every food, you'll gain the Spirit of Sharing!
14667	Those beasts are amazing specimens. You should feel no shame at being bested by them.
14668	Excellent! Let me know when you are ready for the next attempt.
14670	The Isle of Conquest is laden with valuable resources we cannot allow to fall into Horde hands. Will you join the fight?
14671	The Isle of Conquest is laden with valuable resources we cannot allow to fall into Alliance hands. Will you join the fight?
14672	We want everyone to have fun at Brewfest.  It would also help if we had some people remember it as well.$b$bThese goggles allow anyone to experience what it's like to be drunk, but without the drinking part.  Put the goggles on, and you're drunk!  Take them off, and you're sober!$b$bAre you interested in a pair?
14674	Are you ready to fight for the Horde, $c?
14675	Are you ready to fight for the Alliance, $c?
14678	Well done! Your fighting against all those beasts was splendid! I hear the next challenge should be even tougher!
14679	We're holding Lord Jaraxxus back for now, but we can't keep him bound for much longer.
14680	You'll find out soon enough. Are you ready for the next challenge?
14682	That's great, just give me the signal for when to drop the binding spells.
14712	Welcome to our shop.  We have everything you need... if you need alchemy supplies.
14713	No, I'm the intellectual one, and I am not to be taken lightly.  I could brew a healing potion from dishwater and dandelions, although that's not something I'll show you!$b$bAnyhow, if you'd like to make a purchase, please speak with Patricia.
14737	That was an impressive display.  But are you ready for your next challege?
14738	You've impressed everyone here today with your skills in the arena.  It is now time to be recognized before all as a champion of the tournament.
14759	The magnataur are not as stupid as they appear. Keeping Gormok until his time is a difficult task, but he is bound tightly enough that there is no danger.
14760	I tend these creatures of Gormok as he cannot. I do not fully agree with this slaughter, but at the least he will have his chance to fight.
14761	The yeti is a fierce, cunning creature, and this one is one of the strongest of his kind. We keep him asleep through herbs in his food.$b$bDo not think he will be lethargic in the ring, however.
14771	I will join in the assault upon Icecrown Citadel when the time to strike is upon us.
14777	Greetings, $c.$B$BThe Horde currently control Wintergrasp Fortress, but the battle has begun.  Hurry to Wintergrasp and support our forces!
14779	We have been tending these worms for some time. I hope they will be fit in time for the ring event of this organization. You must face not one, but two jormungar, after all.
14781	Greetings, $c.$B$BThe Alliance currently control Wintergrasp Fortress, but the battle has begun!  Hurry to Wintergrasp and support our forces!
14782	Greetings, $c.$B$BThe Alliance currently control Wintergrasp Fortress.  When the battle is about to begin, talk to me to enter the battle.$B$BThe next battle begins in $4354k.
14787	You! Yes, you!$b$bGaze upon me and treasure this moment of meeting, for soon the world will come to know and fear the name and stern visage of Wilfred Fizzlebang! Once my magnificent summoning is complete, no one will doubt my ability!
14790	Greetings, $c.$B$BThe Horde currently control Wintergrasp Fortress, but the next battle starts soon.   Get ready to head to Wintergrasp and support our forces!$B$BThe next battle begins in $4354k.
14791	Greetings, $c.$B$BThe Alliance currently control Wintergrasp Fortress, but the next battle starts soon.   Get ready to head to Wintergrasp and support our forces!$B$BThe next battle begins in $4354k.
14804	We may operate in the shadows of polite society, but out here on the battlefront our powers are properly respected at last.
14814	Well then, I'll give the signal to Tirion when you are ready to go.
14815	That fight was savage and brutal. I haven't seen a grand melee like that in many years! Amazing!
14816	I can't wait to see it! They seem ready for another round now, so prepare yourselves!
14820	The Val'kyrs'  teamwork is rather astounding. I now see why we had such problems capturing the two of them.
14821	You better believe it! You're going to face two of Arthas' most powerful Val'kyr lieutenants!
14822	Well I hope you improve quickly!
14829	The praise is well deserved. Tirion will want to praise you himself, shortly. Hey, have you noticed it getting a bit cold all of a sudden?
14850	Welcome, champion! Have you gathered your forces in preparation for the challenges of the Trial of the Grand Crusader? Only the most powerful and accomplished of combatants are able to participate in these trials. To participate in these trials, you must have completed the normal Trial of the Crusader.
14853	The Trial of the Grand Crusader is a more difficult version of the Trial of the Crusader. Each encounter is more difficult, and you will not be able to freely attempt the encounters until you win. After 50 unsuccessful attempts, the Trial of the Grand Crusader will end for the week. After successfully completing the Trial of the Grand Crusader, you will receive an additional tribute chest of rewards as compensation. Are you prepared for this trial?
14882	Nice to see you again, $N.
14931	Surprised to see an orc here? Don't be.$b$bThe forsaken need watching. If we'd been paying closer attention from the start, maybe the Wrath Gate wouldn't have happened.
14932	Make it quick, $r.
14933	What's wrong, bonebag? Looking for someone else? I'm all you've got now, so if you want something, make it quick.
15021	I remember when my brother and I would camp alone in the Azshara wilderness. Look at it now. 
15038	Well met, fellow Mohawk $GBrother:Sister;.
15074	What is your business here, $c?
15077	There you are! I was beginning to think that the Sunreavers had intercepted you. Are you ready to deliver the tome to our representatives in Icecrown?
15081	I cannot hold him for long, we must leave at once!
15119	Your jormungar can only move if you've submerged beneath the snow, but it cannot attack while submerged. Once your jormungar emerges, it can use its powerful acid attack to wear through the armor of the Iron Colossus. Be ready to submerge to escape from the Iron Colossus's most devastating attacks.
15132	Greetings, $glad:lass;. I'm Grelin Whitebeard. I'm here to examine the threat posed by the growing numbers of trolls in Coldridge Valley. What have I found? It's a bit troubling...
15134	Why you're just the $c I was looking for! I'm testing a new rocket-powered flying device, and I need your help!$B$BJust take one of these harnesses and put it on under your armor.  Hit the button on the side, and BOOM, off you go.$B$BDon't go trying to steal my work though. Each of these babies is fitted with a Transponster 8000 linked to the one in my hand. If you get too far from me the Transponster will shut down the main rocket and you'll be unable to lift off until you return.$B$BNow where did I put those liability forms?
15139	Oh dear.  Things aren't looking good for Felix.
15145	How do you do, $c?
15152	I will delay here until more reinforcements arrive, but you have to keep moving. We won't have much time until Arthas realizes we're here.
15155	These appear to be the remains of Thalorien Dawnseeker, the last wielder of Quel'Delar.
15157	I cannot hold him for long, we must leave at once!
15160	Speak with Alchemist Finklestein, $c. He can set you on the path.$b$bDemonstrate your loyalty and their methods shall be made known to you.
15166	The Lich King is near, $n. His voice taunts me...$b$bLet us silence him at last!
15172	I'll gather up the rest of slaves and get them ready to fight. We'll catch up with you before you engage Scourgelord Tyrannus.
15189	Forgive me, heroes. I should have listened to Uther. I... I just had to see for myself. To look into his eyes one last time. I am sorry.
15190	We are safe... for now. His strength has increased tenfold since our last battle. It will take a mighty army to destroy the Lich King. An army greater than even the Horde can rouse.
15191	I will delay here until more reinforcements arrive, but you must keep moving. Arthas will soon realize that we're here.
15195	Are ye sure, $g lad:lass;? Ye don't need another minute or two?
15206	We have no time to waste, $c. Why do you delay here?
15207	We do not have much time, hero. What do you need?
15211	You expect me to remember all that off the top of my head? Look. They didn't pay me enough to put up with this, and the contract only asked for my silence. So I'm just gonna drop my ledger on the floor here, and you're going to take it and leave me alone.$b$bGot it?
15214	Whatever you need, Brazie Getz! Get it?$B$BAnd I'm not just talkin' about the \\"legal\\" stuff, either. WHATEVER YOU NEED, PAL! Anything...
15215	Standing this close to the blade that ended my life... The pain... It is renewed.
15217	Brave soldier of the Horde, I salute you! We would have surely been destroyed by the Alliance gunship had it not been for you and your allies.$B$BTake a moment to rest before we begin our assault upon the upper reaches of the citadel.
15218	Are you sure, $N? We must face the Scourge at full strength if we are to succeed. If you do not require more rest, we will begin.
15219	I have heard tale of my boy being here. That he's now a powerful death knight in service of the Lich King. If this is true, then it must be me that ends the bloodline.$B$BMy charge now is to command Orgrim's Hammer to the top of Icecrown Citadel and destroy all Scourge that get in our way. We leave when you and your allies are ready.
15240	I will escort you into the Sunwell when you're ready.
15246	Kneel beside me, friend. I caught a bullet during that last raid.$B$B<Gann grunts in pain as he tries to shift position. His left hand clutches a wound, blood welling between his quivering fingers.>$B$BWhen the dwarves first invaded the Barrens, I contented myself with harassing their diggers and sabotaging their equipment. I should've struck a killing blow when I had the chance.
15282	Don't you have some packages to move?
15284	Something stinks, and for once it's not my socks.
15287	Truly an amazing sword, don't you think? That's no weapon of dwarven make, no, it's far more ancient than that.$B$BThese Sunreaver and Silver Covenant representatives seem intent on getting to the bottom of the mystery. I'm already working on a report for Brann.
15290	Long have I waited for this day, hero. Are you and your allies prepared to bring the Lich King to justice? We charge on your command!
15296	You've caught me at a critical time in my research! No worries, you're welcome to join me in quiet contemplation... emphasis on \\"quiet\\", if you don't mind though.
15297	A self-inflicted wound, friend.  I could not bear to look upon a world where I'd committed so many horrors under the Lich King's grasp.$B$BIt was my first step towards redemption, and if my sins are unforgivable, then I will attempt to atone for them for the rest of my life.
15302	A foul wind blows from the East, $c.
15339	Frostmourne: the blade that destroyed our kingdom...
15340	After countless failures of our agents to secure workable samples of Scourge blight for analysis, I've come up to the front lines myself to oversee the efforts. Like they say, if you want a job done right....
15343	This is incredible! You're covered in potent, virulent, fantastic blight! Please, allow me to harvest these pristine samples. I will remove any lingering infection from your allies as well, and reward you all for your bravery and self-sacrifice in the name of medicine! Let me know if you are ready to proceed.$B$B[Before proceeding, make sure that ALL raid members are nearby in order for them to receive credit for your accomplishment.]
15379	Mortals, you have saved me from a fate worse than death. Left to their devices, the sorcerers of the Lich King would have broken my will eventually, and condemned me to a tortured eternity of unlife. Ahead of you lies one who was not so fortunate: the once-proud consort of Malygos, Sindragosa.$B$BMortally wounded after Neltharion's betrayal and left to die alone in the snows of Icecrown, she exists now as a being of pure hatred. And yet, beneath those layers of malevolence still remains the noble spirit of a dragon queen. I believe there is yet hope that Sindragosa's soul may find peaceful respite.
15400	You are astute to ask, young $c.  Scribes are capable of inscribing tarot cards of great power, although even they do not have full control of what they make.  The fates decide for them.$b$bIf you manage to obtain a completed deck, please bring it to me for a magnificent reward.
15412	We got the final barrier blockin' entry to Frostwing Halls down, $g lad:lass;. Only Sindragosa stands between the Lich King and divine retribution! What are ye waitin' for?!
15415	All barriers are now down, $N! Only Sindragosa stands between the Lich King and us. Justice comes soon...
15432	Anywhere but here...
15445	Greetings, hero. I craft and sell Freya's Lasherweave armor for druids.
15449	Greetings, hero. I craft and sell Ahn'kahar Blood Hunter armor for hunters.
15450	Greetings, hero. I craft and sell Ymirjar Lord's armor for warriors.
15453	Greetings, hero. I craft and sell Bloodmage armor for magi.$B
15454	Greetings, hero. I craft and sell Dark Coven armor for warlocks.$B
15512	<Deathguard Simmer looks at you expectantly.>
15531	Simmer say Gordo got guts, but got no brains.  Why he mean?
15532	On behalf of the illustrious and still neutral Steamwheedle Cartel, I hope you enjoy your stay.$B$BRemember, everyone is welcome in Gadgetzan! Everyone except pirates.
15602	The continued sacrifice of the Ashen Verdict and heroes such as yourself bring us all closer to final victory. Now I have come to Icecrown Citadel to lend aid to those who fight against the Scourge. Together we will end the tyranny of the Lich King!
15603	You can do this alone, you say? Is this simple foolishness or misplaced confidence I see before me?$B$BNo, I can see it in your eyes. You have to know. You have to prove to yourself that you can do this alone. Very well. I will retreat from the battlefield if you so wish it.
15604	You will need more than bravery to defeat the Lich King. Good luck.
15605	Your choice has been made. Whether you live or die by that choice is now up to you.
15606	With the Warsong Offensive here in Icecrown Citadel, victory is within our grasp! The death of the Lich King will bring glory to the Horde!
15607	Your choice was bold! I respect your desire for glory and honor! Die well, $N!
15664	Try to ignore the firm, feathery behinds of the harpies... the creatures are really quite deadly!
15704	That's right, I've seen you here before! How could I forget? I can teleport you to Stratholme now, if you wish.
15719	Missing US text
15779	I'm only here in case someone faints. The new recruits get a little excited and occasionally overexert themselves.$B$B...well, that, and sometimes one of the new mechano-tank prototypes explode. Whoops!
15796	I be one of da first to answer Vol'jin's call to arms. Will you be joinin' us?
15806	If ya need a bat, ya come to da right place. I be handlin' all de bats for de scouts.
15846	May de spirits guide ya, $c.
15853	I'm tellin' you, that Corin Direbrew's a madman.$B$BIt's not MY fault he didn't get invited to compete at Brewfest! But that didn't stop him and all his Dark Iron cronies from roughin' up my employees and drinking all my brew.$B$BSomeone's got to put an end to this!
15855	The Frost Lord, Ahune, must be stopped.$B$BEven now he is taking form, summoned from his elemental prison by the mad cultists of the Twilight's Hammer.$B$BIf he's allowed to enter our world completely, he'll bury us beneath an eternal winter.
15859	What?!  What did ye say?!  How dare ye!  Me beer can stand up to any of that rot they serve at Brewfest!$B$BYou'll pay for this insult, $c!
15863	Welcome to Tinker Town!
15864	This shard of ice echoes the deep, cracking rumble of invading glaciers.  Its cold turns your thoughts to a lifeless, endless winter.
15865	Zalazane's time be runnin' out. De Echo Isles will belong to de Darkspear Tribe again!
15866	De Darkspears have a home again! An' we couldn't have done it wit'out ya helpin', $N. Now, we celebrate!
15868	It's my job to ensure that this whole assault runs like clockwork.$B$BHigh Tinker Mekkatorque is out in the field now, but he's scheduled to come back to get some more troops any time now.  $B$BHe's never late, so just stick around and he'll be here.
15870	Hurry! You should talk to Mekkatorque! If we don't start the assault soon, we're going to be late.$B$BAnd my boss HATES it when we're late!
15873	Vol'jin told me ta keep hittin' da drum till he gets back.  If ya be waitin' for him, he'd be back soon to take back da Isles.$B$BJust wait here and enjoy da music!
15876	We'd be gettin' ready to take back da Echo Isles. Zalazane has been workin' his voodoo magic for some time, convincing folks dat he be dead and performing ancient dark rituals.$B$BHe knows we'd be coming, so we have ta make sure we be prepared.
15877	We require da help of allies on da islands.$B$BZen'tabra has been watching over da animals of de Islands for some time now.  We'd need her help and da help of da animal creatures.$B$BBwonsamdi is a powerful loa dat controls de spirits of de dead on da islands.  His blessing is crucial for our attack.$B$BOnce our allies have joined us, Zalazane and his army of mind-controlled trolls will have no chance!  Then, da Echo Isles will be de Darkspears!
16157	What you want?
16211	Ach, it's hard enough keeping order around here without all these new troubles popping up!  I hope you have good news, $n...
16219	Things can get a little stuffy here in Nethergarde.  Sometimes a dwarf just needs a brew to take her mind off her duty for a bit.
16334	Welcome to Grom'gol, $C. Before we get off on the wrong foot, I'll have you know that I won't have slackers in my Base Camp.. I expect a healthy $R like you to pull your own weight around here.
16335	Even in this remote corner of the world, know that Hellscream's eyes are upon you.
16336	Missing US text
16390	I'm sick of sittin' in this hole. I hope whatever sorry pencil-pusher is holdin' up Danath's return gets a punch in the jimmies.
16418	Here's to you!  Here's to me!  May we never disagree.$b$bBut if we do... BLAST YOU!  Here's to me.
16432	Woohoo! They are into it now!
16440	Care to purchase some piratey items?
16441	Welcome to Booty Bay, $r.
16491	May the Sun's light protect you, $c.
16510	Welcome to Dolanaar, $c. Let me know if you need any recipes or basic cooking ingredients.
16528	This is MY WAGON!$B$BMINE!
16535	Keep your eyes open, $c. Even Durotar is not safe from our enemies.
16583	I must have lived a charmed life, $N. To return to the world as a member of the Forsaken and the Apothecary Society... I couldn't have asked for a more suitable fate.
16644	Hey there, cutie!  Mind rubbing some lotion on my exposed areas?
16661	We must take what is ours. Our survival depends on it.
16667	Missing US text
16719	<The Major nods curtly.>
16901	You won't find a finer firearm anywhere else in Orgrimmar.
17038	You lookin' for me?
17140	You've got to try some of this beer.
17151	What brings you to a bunch of old, washed-up desert dogs like us?
17235	Who are you?
17268	Welcome to Thorium Point. As Overseer, I'm responsible for all the activities of the Thorium Brotherhood.  While that mainly involves mining, smithing, and some minor guard duty, we've lately become more of a martial organization... out of necessity.
17511	Derak Nightfall, at your service!
17586	Welcome to Starfall Village, traveler. Have you come to assist us?
17772	We're glad to have your help.
17804	What?
17805	What!
17816	Weary of one of your demonic charges? Hoping for one with a more pleasing name?$B$B$B$BFor a price, I can assist you in the obliteration of a current minion so that you may summon an entirely new one...
17838	Only the most valiant and honorable amongst the tribe can earn the honor of being laid to rest at Red Rocks.
17861	A treasure hunter's life is a treacherous one. Don't be foolin' yerself.
18070	With all the Siege Engines nearly complete, I'm getting a bit bored!$B$B$B$BYou're not an engineer, are you? Care to compare blueprints...?
20201	Stop! Do not go any further, mortal. You are ill-prepared to face the forces of the Infinite Dragonflight.Come, let me help you.
20551	I hope this damned thing works. \\"Araxes pounds on the portable trasnponder.\\"
20564	Araxes, come in....Are you there Araxes? Visibility is nil, Warp storms blocking us.
21024	It is here that Gul`dan severed the tie between orcs and elemental spirits. His unquenchable thirst for power could not be satiated with the complete annihilation of the draenei. He had to also destroy Draenor, razing the land and siphoning all of its energies for use in his war.  Npw all that is left are remnants of his madness.   Look to the altar, night elf - the land is forever haunted......
22932	Rokkaram, is that you?$B$BForgive me for questioning you, my son. My sight isn't what it once was, but the raven has blessed me with a long life. Soon it will be time for you to take my place. I have taught you all I know. $B$BMy only regret is that I didn't prove worthy enough to recover our sacred Book of the Raven.The true believers have lived in shame since the day our treacherous cousins in Skettis stole the book from us, shattered its tablet, and buried the fragments in their wretched city!$B$BPray that the raven will choose you to restore it, my son. Be faithful and remember always the prophecy, \\"From the dreams of his enemies shall the raven spring forth into the world.\\"
22990	Be wary, friends. The Betrayer meditates in the court just beyond.
24400	<Omarion grumbles something under his breath.>$B$BBut of course I can help you, dear $N. It is my dying wish... my final desire. Please, take this handbook. The information on its pages are a compilation of all that I know and have learned in the past 30 some-odd years of my miserable life. Give the handbook to that good for nothing apprentice of mine that's probably sitting on his fat duff at Light's Hope Chapel.
24401	A tailor, eh? Very well. What would you like to learn about, tailor?$B$B
24402	A blacksmith, eh? Very well. What would you like to learn about, blacksmith?$B$B
24403	A leatherworker, eh? Very well. What would you like to learn about, leatherworker?$B$B
24404	Is this the best they could do?$B$B<Omarion musters the strength to laugh.>$B$BYou do not possess the resolve to face a monster like Kel'Thuzad. You will crumble before his minions - just like those that have come before you...$B$BLeave me here to die. I refuse to return to a world that champions the likes of you.
31023	Hello, $N. What can I do for you?
50010	You must be hard up to be wandering these Badlands, $c. Hard up like me.$B$BOr maybe you're here because you're crazy. Crazy, like me.
50013	In order to serve the Dark Lady and Varimathras we need to advance the front on the Human Infestation.
50014	We are but so close to developing the New Plague that our Dark Lady desires with such fervor.
50015	Thanks to the Warchief, even here in the remains of our former prison, some hope remains, and the Horde rises anew.
921061	Hey citizen ! I need your help.. .
16777215	Greetings $N
6157	Hey there, friend. My name's Remy. I'm from Redridge to the east, and came here looking for business, looking for business. You got any...got any??
1244	Don't let the humans in the Bazaar fool ye $g lad : lass;, with the subway those gnomes built it's easier than ye might think to transport goods from Ironforge. If they try to tack on import fees just tell them yer gonna buy yer gear from me.
8121	The journal of Jandice Barov is filled with rantings and ravings about the undead. Towards the end of the book is what appears to be a tailoring pattern for the creation of a bag of some sort.
8122	UDB Missing text
7006	A Sulfuron ingot?!??! Impossible! I must have it! I must! I must!$B$B$R, I am authorized to make you a grand deal for that ingot. Perhaps you would be interested to know the secrets of the Hand of Ragnaros? Sulfuras, idiot! The legendary hammer of the Firelord.
7007	In exchange for one Sulfuron Ingot, I am authorized to grant you one copy of the plans to forge a Sulfuron hammer.$B$BNow an adventurer like yourself is probably thinking to $ghimself:herself;, \\"What would I ever need a hammer like that for when what I already own is far superior?\\"$B$BWell let me tell you something, $gmister:missy;, there ain't nothing more superior than what the Sulfuron hammer can become!
7008	You see, all you gotta do is forge the Sulfuron hammer and find yourself the Eye of Sulfuras. Combine the Eye of Sulfuras with the Sulfuron hammer and it will become Sulfuras! Now I'm not going to bog you down with any technical information as to where or how or when you can get an Eye of Sulfuras. I'm sure you'll figure that stuff out. Just sign this here contract so that our agreement is binding and our business will be done.
50218	<Lydros reaches into his robe and presents you with a dull, flat elven blade.>$B$BIn ages past, well before even the War of the Ancients, there existed this blade.
50219	The blade itself had to be crafted in ceremony with the children of the Aspects. A rare occurrence indeed... For not only would a dragon have to willingly heat and mold the enchanted metal with their breath, they would also need to contain the fury of their own enchantment by using their blood as temper.
50220	Over the course of 8,000 years, only a handful of these blades were created - each blade unique in both power and appearance. The blades of Quel'Serrar would take on the characteristics of their creator.
50221	Rumors exist of a single, legendary blade of Quel'Serrar crafted for an unknown entity by the combined might of the five Aspects. Before the abominations of Nefarian and Deathwing were thrust into our world, such meetings of the Aspect were represented by the term 'Prismatic.' I could only assume that the Prismatic Blade of Quel'Serrar was a most glorious creation.
50222	What I offer to you now is one such blade, unfired, unheated, untreated - the most raw and basic form.$B$BNow you merely need to find a dragon that will willingly enchant the blade.$B$BIf you had an eternity to live, this might be a possibility; but since you are mortal and could very likely cease to exist at any moment, might I recommend trying to persuade one of the lesser dragons to do your bidding. 
50223	Have you heard of the brood mother of the Black Flight? I believe she is called Onyxia...
7884	It... It's foggy, $N. I can't see anything! Wait... Wait a minute. I see... I see Doctor Weavil's hideout. It... YES! I believe he is holding a chapter of the book!$B$BLet me see if I can zoom this thing out to get a better vantage point.$B$B<Narain appears to be going cross-eyed.>$B$BAlcaz Island! That devious bastard is on Alcaz Island!
6986	Elementium? I have not heard that word uttered from the mouth of a mortal in decades.
6987	 A former student of mine by the name of Krixix spent a lifetime attempting to make contact with the chained Gods of the underworld. He pursued that which would spring up from the ravaged earth... That which would form only as a result of the elements clashing in the titanic conflict.$B$BElementium as it would be known to mortals.$B$BOne day, nearly a decade ago, Krixix's pursuit lead to a fissure forming in this very gorge.
6988	Aye, he had done what was thought to be impossible. Out from the fissure sprung an agent of Therazane!$B$BFrom my vantage point, I could see the goblin holding conversation with the agent of the Old God. What happened after that was terrible...
6989	The fissure closed and Krixix was gone! Swallowed whole!$B$BBe warned, $r, what you wish for could very well become that which you do not want. You play with beings and arcana that are older than time itself!$B$BShould Krixix be alive and should he have the information which you seek, you can be certain that he will not give up said information. He has faced terrors far worse than you could ever dream to perpetuate.
8309	It seems like love is drifting on the wind. I hope that I won't be left out.
1248	If you insert tab A into slot B then of course it's going to go BOOM! Here, let me show you what I have and then you can ask Lilliam about how to put it together so it doesn't blow up.
8310	It has been years since I have thought with my heart, but it's all flooding back.
8311	After all these years of fighting, now everyone's falling in love!
\.
