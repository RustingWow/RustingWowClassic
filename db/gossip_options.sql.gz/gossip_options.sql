SET search_path TO world;
COPY gossip_options (menu_id, option_id, icon, text, option_kind, action_menu_id) FROM stdin;
0	0	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
0	1	VENDOR	I want to browse your goods.	VENDOR	0
0	2	TAXI	I need a ride.	TAXIVENDOR	0
0	3	TRAINER	Train me.	TRAINER	0
0	4	INTERACT_1	GOSSIP_OPTION_SPIRITHEALER	SPIRITHEALER	0
0	5	INTERACT_1	GOSSIP_OPTION_SPIRITGUIDE	SPIRITGUIDE	0
0	6	INTERACT_2	Make this inn your home.	INNKEEPER	0
0	7	MONEY_BAG	GOSSIP_OPTION_BANKER	BANKER	0
0	8	TALK	How do I form a guild?	PETITIONER	0
0	9	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
0	10	BATTLE	I wish to join the battle!	BATTLEFIELD	0
0	11	MONEY_BAG	GOSSIP_OPTION_AUCTIONEER	AUCTIONEER	0
0	12	CHAT	I'd like to stable my pet here.	STABLEPET	0
0	13	VENDOR	GOSSIP_OPTION_ARMORER	ARMORER	0
0	14	CHAT	I wish to unlearn my talents.	UNLEARN_TALENTS	0
0	15	TAXI	I wish to unlearn my pet's skills.	UNLEARN_PET_SKILLS	0
21	0	CHAT	How can I help?	GOSSIP	22
21	1	CHAT	Can you tell me about this shard?	GOSSIP	20025
24	0	CHAT	Tell me a story, Skorn.	GOSSIP	23
63	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
63	0	TRAINER	I am interested in mage training.	TRAINER	0
64	0	TRAINER	I am interested in mage training.	TRAINER	0
64	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
83	0	INTERACT_1	Return me to life.	SPIRITHEALER	0
85	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
85	4	CHAT	<Take the letter>	GOSSIP	-1
85	0	TRAINER	I would like to train.	TRAINER	0
125	0	CHAT	You've got something I need, Astor. And I'll be taking it now.	GOSSIP	-1
126	0	CHAT	You're Astor Hadren, right?	GOSSIP	125
141	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
141	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
141	4	CHAT	<Take the letter>	GOSSIP	-1
161	1	CHAT	Mennet said I should ask you for a set of thieves' tools.	GOSSIP	-1
262	0	CHAT	Where is the key to this lock?	GOSSIP	261
321	0	CHAT	Please port me to Darnassus.	GOSSIP	0
342	0	CHAT	Trick or Treat!	GOSSIP	435
342	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
342	3	VENDOR	Let me browse your goods.	VENDOR	0
344	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
344	3	VENDOR	Let me browse your goods.	VENDOR	0
345	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
345	3	VENDOR	Let me browse your goods.	VENDOR	0
347	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
347	3	CHAT	What can I do at an inn?	GOSSIP	1221
347	0	CHAT	Trick or Treat!	GOSSIP	-1
348	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
348	3	VENDOR	Let me browse your goods.	VENDOR	0
349	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
349	3	VENDOR	I want to browse your goods.	VENDOR	0
381	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
381	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
381	4	CHAT	<Take the letter>	GOSSIP	-1
401	0	CHAT	Druid	GOSSIP	405
401	1	CHAT	Hunter	GOSSIP	408
401	2	CHAT	Mage	GOSSIP	402
401	3	CHAT	Paladin	GOSSIP	407
401	4	CHAT	Priest	GOSSIP	406
401	5	CHAT	Rogue	GOSSIP	403
401	7	CHAT	Warlock	GOSSIP	409
401	8	CHAT	Warrior	GOSSIP	404
410	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
410	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
410	4	CHAT	<Take the letter>	GOSSIP	-1
411	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
411	0	TRAINER	Good day, Hulfdan, I am looking for training.	TRAINER	0
411	4	CHAT	<Take the letter>	GOSSIP	-1
421	0	CHAT	Alchemy	GOSSIP	422
421	1	CHAT	Blacksmithing	GOSSIP	423
421	2	CHAT	Cooking	GOSSIP	424
421	3	CHAT	Enchanting	GOSSIP	444
421	4	CHAT	Engineering	GOSSIP	425
421	5	CHAT	First Aid	GOSSIP	426
421	6	CHAT	Fishing	GOSSIP	443
421	7	CHAT	Herbalism	GOSSIP	427
421	9	CHAT	Leatherworking	GOSSIP	428
421	10	CHAT	Mining	GOSSIP	430
421	11	CHAT	Skinning	GOSSIP	431
421	12	CHAT	Tailoring	GOSSIP	432
435	0	CHAT	Auction House	GOSSIP	3102
435	1	CHAT	Bank of Stormwind	GOSSIP	265
435	3	CHAT	Deeprun Tram	GOSSIP	3081
435	4	CHAT	The inn	GOSSIP	3126
435	5	CHAT	Gryphon Master	GOSSIP	382
435	6	CHAT	Guild Master	GOSSIP	383
435	8	CHAT	Stable Master	GOSSIP	4925
435	9	CHAT	Weapons Trainer	GOSSIP	3721
435	10	CHAT	Officers' Lounge	GOSSIP	5883
435	11	CHAT	Battlemaster	GOSSIP	8222
435	14	CHAT	Class Trainer	GOSSIP	401
435	15	CHAT	Profession Trainer	GOSSIP	421
436	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
436	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
436	4	CHAT	<Take the letter>	GOSSIP	-1
441	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
441	4	VENDOR	Let me browse your goods.	VENDOR	0
523	0	TRAINER	I require warrior training.	TRAINER	0
523	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
524	0	CHAT	Press the yellow button labeled 'Thieves' Tools.'	GOSSIP	-1
561	0	CHAT	What is a \\"subterranean being matrix\\"?	GOSSIP	563
562	0	CHAT	Who are the Earthen?	GOSSIP	561
563	0	CHAT	What are the anomalies you speak of?	GOSSIP	564
564	0	CHAT	What is a \\"resilient foundation of construction\\"?	GOSSIP	565
565	0	CHAT	So... the Earthen were made out of stone?	GOSSIP	566
566	0	CHAT	Anything else I should know about the Earthen?	GOSSIP	567
567	0	CHAT	I think I understand the Creators' design intent for the Earthen now.  What are the Earthen's anomalies that you spoke of earlier?	GOSSIP	568
568	0	CHAT	What high-stress environments would cause the Earthen to destabilize?	GOSSIP	569
569	0	CHAT	What happens when the Earthen destabilize?	GOSSIP	570
570	0	CHAT	Troggs?!  Are the troggs you mention the same as the ones in the world today?	GOSSIP	571
571	0	CHAT	You mentioned two results when the Earthen destabilize.  What is the second?	GOSSIP	572
572	0	CHAT	Dwarves!!!  Now you're telling me that dwarves originally came from the Earthen?!	GOSSIP	573
573	0	CHAT	These dwarves are the same ones today, yes?  Do dwarves maintain any other links to the Earthen?	GOSSIP	574
574	0	CHAT	Who are the Creators?	GOSSIP	575
575	0	CHAT	This is a lot to think about.	GOSSIP	576
576	0	CHAT	I will access the discs now.	GOSSIP	-1
581	0	TRAINER	Train me.	TRAINER	0
590	0	CHAT	Can you give me directions?	GOSSIP	589
593	0	TRAINER	Train me.	TRAINER	0
593	1	CHAT	Tell me more about Forging Armor.	GOSSIP	590
593	2	CHAT	Tell me more about Forging Weapons.	GOSSIP	592
597	0	TRAINER	Train me.	TRAINER	0
597	1	CHAT	I wish to unlearn Armorsmithing!	GOSSIP	0
645	0	TRAINER	Train me.	TRAINER	0
646	0	TRAINER	Train me.	TRAINER	0
648	0	TRAINER	Train me.	TRAINER	0
655	0	TRAINER	I require warrior training.	TRAINER	0
655	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
656	0	TRAINER	I require warrior training.	TRAINER	0
656	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
657	0	TRAINER	Train me.	TRAINER	0
660	0	TRAINER	Train me.	TRAINER	0
681	0	VENDOR	I want to browse your goods.	VENDOR	0
682	0	VENDOR	I want to browse your goods.	VENDOR	0
683	0	VENDOR	I want to browse your goods.	VENDOR	0
684	0	VENDOR	I want to browse your goods.	VENDOR	0
685	0	VENDOR	I want to browse your goods.	VENDOR	0
686	0	VENDOR	I want to browse your goods.	VENDOR	0
687	0	VENDOR	I want to browse your goods.	VENDOR	0
688	0	VENDOR	I want to browse your goods.	VENDOR	0
690	0	VENDOR	I want to browse your goods.	VENDOR	0
691	0	VENDOR	I want to browse your goods.	VENDOR	0
692	0	VENDOR	I want to browse your goods.	VENDOR	0
693	0	VENDOR	I want to browse your goods.	VENDOR	0
698	0	VENDOR	I want to browse your goods.	VENDOR	0
699	0	MONEY_BAG	I would like to check my deposit box.	BANKER	0
700	0	VENDOR	I want to browse your goods.	VENDOR	0
701	0	VENDOR	I want to browse your goods.	VENDOR	0
703	0	VENDOR	I want to browse your goods.	VENDOR	0
704	0	TAXI	I need a ride.	TAXIVENDOR	0
704	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
705	0	VENDOR	I want to browse your goods.	VENDOR	0
706	0	VENDOR	I want to browse your goods.	VENDOR	0
708	0	TALK	How do I form a guild?	PETITIONER	0
708	1	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
721	0	CHAT	The bank	GOSSIP	743
721	1	CHAT	The wind rider master	GOSSIP	744
721	2	CHAT	The guild master	GOSSIP	742
721	3	CHAT	The inn	GOSSIP	2461
721	4	CHAT	The mailbox	GOSSIP	2462
721	5	CHAT	The auction house	GOSSIP	2463
721	6	CHAT	The weapon master	GOSSIP	3725
721	7	CHAT	The stable master	GOSSIP	4904
721	8	CHAT	The battlemaster	GOSSIP	8223
721	9	CHAT	A class trainer	GOSSIP	740
721	10	CHAT	A profession trainer	GOSSIP	751
740	0	CHAT	Druid	GOSSIP	745
740	1	CHAT	Hunter	GOSSIP	746
740	2	CHAT	Mage	GOSSIP	747
740	3	CHAT	Priest	GOSSIP	748
740	4	CHAT	Shaman	GOSSIP	749
740	5	CHAT	Warrior	GOSSIP	750
751	0	CHAT	Alchemy	GOSSIP	780
751	1	CHAT	Blacksmithing	GOSSIP	781
751	2	CHAT	Cooking	GOSSIP	782
751	3	CHAT	Enchanting	GOSSIP	783
751	4	CHAT	First Aid	GOSSIP	784
751	5	CHAT	Fishing	GOSSIP	785
751	6	CHAT	Herbalism	GOSSIP	786
751	8	CHAT	Leatherworking	GOSSIP	787
751	9	CHAT	Mining	GOSSIP	788
751	10	CHAT	Skinning	GOSSIP	791
751	11	CHAT	Tailoring	GOSSIP	789
840	2	CHAT	Hero, I have urgent business with Corporal Splithoof.	GOSSIP	-1
840	1	CHAT	Why are you here?	GOSSIP	841
840	0	CHAT	Please continue, Hero...	GOSSIP	880
900	0	VENDOR	I would like to buy from you.	VENDOR	0
922	1	CHAT	Seen any strange things in the desert lately?	GOSSIP	1423
922	0	VENDOR	Yes! I want more of that fabulous Noggenfogger Elixir!	VENDOR	0
922	2	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
940	0	CHAT	Will you blow up that door now?	GOSSIP	0
941	1	CHAT	That's it!  I'm tired of helping you out.  It's time we settled things on the battlefield!	GOSSIP	0
941	0	CHAT	Hey Bly!  Bilgewizzle wants his divino-matic rod back!	GOSSIP	0
942	0	CHAT	Please tell me more about the hippogryphs.	GOSSIP	943
942	1	CHAT	Please tell me more about the Gordunni ogres.	GOSSIP	1002
980	0	VENDOR	Hello Sovik, I wish to browse your goods.	VENDOR	0
1022	0	TRAINER	Train me.	TRAINER	0
1045	0	CHAT	Acquire Higher Level Access Card	GOSSIP	1044
1047	0	CHAT	Acquire Higher Level Access Card	GOSSIP	1046
1047	1	CHAT	Use engineering to access hidden schematics!	GOSSIP	-1
1049	0	CHAT	Acquire Higher Level Access Card	GOSSIP	1048
1050	0	CHAT	Acquire high level data card.	GOSSIP	1052
1050	1	CHAT	Use engineering to access hidden schematics!	GOSSIP	-1
1080	0	CHAT	I am ready to begin.	GOSSIP	0
1120	0	VENDOR	I would like to buy from you.	VENDOR	0
1141	0	CHAT	Tell me about the reduction.	GOSSIP	50405
1142	0	CHAT	Tell me more, Trenton.	GOSSIP	1143
1161	0	CHAT	What have you heard of the Shady Rest Inn?	GOSSIP	1162
1186	1	CHAT	Paval Reethe.	GOSSIP	1188
1186	0	CHAT	The Burning Inn.	GOSSIP	1187
1201	0	CHAT	What's the worst that could happen?	GOSSIP	1202
1262	0	VENDOR	I would like to buy from you.	VENDOR	0
1282	0	CHAT	Touch the Suntara stone and call forth Lathoric the Black and his guardian, Obsidion.	GOSSIP	-1
1285	0	CHAT	I wish to hear your tale.	GOSSIP	1287
1286	0	CHAT	Let me think about it, Zamael.	GOSSIP	-1
1287	0	CHAT	Please continue, Zamael.	GOSSIP	1286
1288	0	CHAT	How could the altar and the statues be related?	GOSSIP	1302
1290	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1290	3	CHAT	What can I do at an inn?	GOSSIP	1221
1290	4	VENDOR	I want to browse your goods.	VENDOR	0
1291	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1291	3	CHAT	What can I do at an inn?	GOSSIP	1221
1291	4	VENDOR	I want to browse your goods.	VENDOR	0
1291	0	CHAT	Trick or Treat!	GOSSIP	0
1291	5	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
1293	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1293	3	CHAT	What can I do at an inn?	GOSSIP	1221
1293	4	VENDOR	I want to browse your goods.	VENDOR	0
1293	0	CHAT	Trick or Treat!	GOSSIP	0
1294	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1294	3	CHAT	What can I do at an inn?	GOSSIP	1221
1294	4	VENDOR	I want to browse your goods.	VENDOR	0
1296	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1296	4	VENDOR	Let me browse your goods.	VENDOR	0
1296	3	CHAT	What can I do at an inn?	GOSSIP	1221
1296	0	CHAT	Trick or Treat!	GOSSIP	0
347	4	VENDOR	I want to browse your goods.	VENDOR	0
1297	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1297	4	VENDOR	Let me browse your goods.	VENDOR	0
1297	3	CHAT	What can I do at an inn?	GOSSIP	1221
1297	0	CHAT	Trick or Treat!	GOSSIP	0
1301	0	VENDOR	I wish to browse your wares.	VENDOR	0
1321	0	CHAT	Let me confer with my colleagues.	GOSSIP	1323
1322	0	CHAT	Continue please.	GOSSIP	1321
1323	0	CHAT	Tell me what drives this vengeance?	GOSSIP	1322
1323	2	CHAT	Kalaran, I have misplaced my torch. I require another.	GOSSIP	-1
1323	3	CHAT	Kalaran, please enchant the torch.	GOSSIP	-1
1341	1	CHAT	Do you know someone... or something, rather, by the name of Eranikus?	GOSSIP	1366
1341	0	CHAT	What's an elf like you doing inside a cave like this?	GOSSIP	1363
1364	0	CHAT	I will consider what you have told me.	GOSSIP	-1
1365	0	CHAT	I possess part of Eranikus' essence.  What do you want with it... or with me?	GOSSIP	1364
1366	0	CHAT	What happened to him in the first place?  When I... encountered him, he was rather malicious.	GOSSIP	1365
1403	0	TRAINER	I am here for training.	TRAINER	0
1403	2	CHAT	I wish to unlearn my talents.	GOSSIP	4463
1403	1	VENDOR	I'd like to purchase more Tharlendris seeds.	VENDOR	0
1422	0	VENDOR	Can you help me get down?	VENDOR	0
1443	0	CHAT	You can cook?  So can I!  Is there a recipe you can teach me?	GOSSIP	1501
1443	1	CHAT	You're an alchemist?  So am I.  Perhaps you can teach me what you know...	GOSSIP	1442
1465	0	TRAINER	Train me.	TRAINER	0
1469	0	TRAINER	Train me.	TRAINER	0
1482	0	CHAT	Tell me more about these hippogryphs.	GOSSIP	1481
1482	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
1503	0	TRAINER	I am interested in warlock training.	TRAINER	0
1503	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
1522	0	TRAINER	I am interested in warlock training.	TRAINER	0
1522	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
1541	0	CHAT	I wish to face the Defiler.	GOSSIP	-1
1561	0	CHAT	I am ready, Historian Archesonus.	GOSSIP	1565
1562	0	CHAT	Unbelievable! How dare they??	GOSSIP	1563
1563	0	CHAT	Of course I will help!	GOSSIP	-1
1564	0	CHAT	Interesting, continue please.	GOSSIP	1562
1565	0	CHAT	That is tragic. How did this happen?	GOSSIP	1564
1581	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
1581	3	VENDOR	I want to browse your goods.	VENDOR	0
1581	0	CHAT	Trick or Treat!	GOSSIP	0
1582	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
1582	3	VENDOR	I want to browse your goods.	VENDOR	0
1623	0	MONEY_BAG	I would like to check my deposit box.	BANKER	0
1624	0	VENDOR	I want to browse your goods.	VENDOR	0
1626	0	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
1626	1	TALK	How do I form a guild?	PETITIONER	0
1662	0	CHAT	What are you doing out here?	GOSSIP	1661
1663	0	CHAT	Amazing! I've never spoken to a ghost. I wish to learn!	GOSSIP	1664
1664	0	CHAT	Continue please.	GOSSIP	1665
1665	0	CHAT	Fascinating. Please, tell me more.	GOSSIP	1666
1701	0	VENDOR	I'd like to purchase more Tharlendris seeds.	VENDOR	0
1721	0	VENDOR	I want to browse your goods.	VENDOR	0
1781	0	VENDOR	I'd like to see what you have to sell.	VENDOR	0
1801	0	CHAT	How can I get Evoroot?	GOSSIP	1915
1822	0	CHAT	I need to know where the princess are, Kharan!	GOSSIP	1830
1942	0	CHAT	Alchemy	GOSSIP	1845
1942	1	CHAT	Blacksmithing	GOSSIP	1846
1942	2	CHAT	Cooking	GOSSIP	1861
1942	3	CHAT	Enchanting	GOSSIP	1862
1942	4	CHAT	Engineering	GOSSIP	1981
1942	5	CHAT	First Aid	GOSSIP	1863
1942	6	CHAT	Fishing	GOSSIP	1864
1942	7	CHAT	Herbalism	GOSSIP	1865
1942	9	CHAT	Leatherworking	GOSSIP	1866
1942	10	CHAT	Mining	GOSSIP	1868
1942	11	CHAT	Skinning	GOSSIP	1869
1942	12	CHAT	Tailoring	GOSSIP	1871
1945	0	CHAT	Gloom'rel, tell me your secrets!	GOSSIP	20023
1945	1	CHAT	I have payed your price, Gloom'rel.  Now, teach me your secrets!	GOSSIP	20025
1947	0	CHAT	Your bondage is at an end, Doom'rel.  I challenge you!	GOSSIP	0
1949	0	CHAT	Hunter	GOSSIP	1906
1949	1	CHAT	Mage	GOSSIP	1907
1949	2	CHAT	Priest	GOSSIP	1908
1949	3	CHAT	Shaman	GOSSIP	1909
1949	4	CHAT	Rogue	GOSSIP	1910
1949	5	CHAT	Warlock	GOSSIP	1911
1949	6	CHAT	Warrior	GOSSIP	1912
1951	0	CHAT	The bank	GOSSIP	1901
1951	1	CHAT	The wind rider master	GOSSIP	1902
1951	2	CHAT	The guild master	GOSSIP	1903
1951	3	CHAT	The inn	GOSSIP	1904
1951	4	CHAT	The mailbox	GOSSIP	1905
1951	5	CHAT	The auction house	GOSSIP	2403
1951	7	CHAT	The weapon master	GOSSIP	3724
1951	8	CHAT	The stable master	GOSSIP	4902
1951	9	CHAT	The officers' lounge	GOSSIP	5882
1951	10	CHAT	The battlemaster	GOSSIP	8224
1951	12	CHAT	A class trainer	GOSSIP	1949
1951	13	CHAT	A profession trainer	GOSSIP	1942
1964	0	VENDOR	I want to browse your goods.	VENDOR	0
1965	0	VENDOR	I would like to buy from you.	VENDOR	0
1970	1	CHAT	You're good for nothing, Ribbly.  It's time to pay for your wickedness!	GOSSIP	-1
3669	0	CHAT	I live only to serve, Warchief! My life is empty and meaningless without your guidance.	GOSSIP	3670
2021	0	TRAINER	I'd like to train in cooking.	TRAINER	0
2061	0	CHAT	Official business, John. I need some information about Marshal Windsor. Tell me about the last time you saw him.	GOSSIP	2060
2121	0	CHAT	Auction House	GOSSIP	2321
2121	1	CHAT	Bank of Ironforge	GOSSIP	2141
2121	2	CHAT	Deeprun Tram	GOSSIP	3082
2121	3	CHAT	Gryphon Master	GOSSIP	2142
2121	4	CHAT	Guild Master	GOSSIP	2143
2121	5	CHAT	The inn	GOSSIP	2145
2121	6	CHAT	Mailbox	GOSSIP	2146
2121	7	CHAT	Stable Master	GOSSIP	4927
2121	8	CHAT	Weapons Trainer	GOSSIP	3723
2121	9	CHAT	Battlemaster	GOSSIP	8220
2121	11	CHAT	Class Trainer	GOSSIP	2144
2121	12	CHAT	Profession Trainer	GOSSIP	2168
2144	0	CHAT	Hunter	GOSSIP	2147
2144	1	CHAT	Mage	GOSSIP	2148
2144	2	CHAT	Paladin	GOSSIP	2150
2144	3	CHAT	Priest	GOSSIP	2149
2144	4	CHAT	Rogue	GOSSIP	2151
2144	5	CHAT	Warlock	GOSSIP	2152
2144	6	CHAT	Warrior	GOSSIP	2153
2168	0	CHAT	Alchemy	GOSSIP	2161
2168	1	CHAT	Blacksmithing	GOSSIP	2162
2168	2	CHAT	Cooking	GOSSIP	2163
2168	3	CHAT	Enchanting	GOSSIP	2164
2168	4	CHAT	Engineering	GOSSIP	2165
2168	5	CHAT	First Aid	GOSSIP	2166
2168	6	CHAT	Fishing	GOSSIP	2167
2168	7	CHAT	Herbalism	GOSSIP	2169
2168	9	CHAT	Leatherworking	GOSSIP	2170
2168	10	CHAT	Mining	GOSSIP	2172
2168	11	CHAT	Skinning	GOSSIP	2173
2168	12	CHAT	Tailoring	GOSSIP	2175
2177	0	CHAT	I want to examine this pylon.	GOSSIP	2181
2178	0	CHAT	I want to examine this pylon.	GOSSIP	2180
2179	0	CHAT	I want to examine this pylon.	GOSSIP	2182
2184	0	CHAT	Tell me more about the Eastern Crystal Pylon.	GOSSIP	2202
2184	1	CHAT	Tell me more about the Northern Crystal Pylon.	GOSSIP	2203
2184	2	CHAT	Tell me more about the Western Crystal Pylon.	GOSSIP	2204
2187	0	CHAT	Transcript the Tablet	GOSSIP	2186
2188	0	CHAT	Who is this Lar'korwi you spoke of?	GOSSIP	2201
2208	0	CHAT	I need a Cenarion beacon.	GOSSIP	-1
2208	1	CHAT	What plants are in Felwood that might be corrupted?	GOSSIP	2361
2242	0	VENDOR	I would like to buy from you.	VENDOR	0
2304	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
2304	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
2343	0	CHAT	Druid	GOSSIP	2328
2343	1	CHAT	Hunter	GOSSIP	2327
2343	4	CHAT	Priest	GOSSIP	2329
2343	5	CHAT	Rogue	GOSSIP	2341
2343	6	CHAT	Warrior	GOSSIP	2342
2351	0	CHAT	Alchemy	GOSSIP	2344
2351	1	CHAT	Cooking	GOSSIP	2345
2351	2	CHAT	Enchanting	GOSSIP	2347
2351	3	CHAT	First Aid	GOSSIP	2348
2351	4	CHAT	Fishing	GOSSIP	2349
2351	5	CHAT	Herbalism	GOSSIP	2350
2351	7	CHAT	Leatherworking	GOSSIP	2354
2351	8	CHAT	Skinning	GOSSIP	2356
2351	9	CHAT	Tailoring	GOSSIP	2358
2352	0	CHAT	Auction House	GOSSIP	0
2352	1	CHAT	The bank	GOSSIP	2322
2352	2	CHAT	Hippogryph Master	GOSSIP	0
2352	3	CHAT	Guild Master	GOSSIP	0
2352	4	CHAT	The inn	GOSSIP	0
2352	5	CHAT	Mailbox	GOSSIP	0
2352	6	CHAT	Stable Master	GOSSIP	0
2352	7	CHAT	Weapons Trainer	GOSSIP	0
2352	8	CHAT	Battlemaster	GOSSIP	0
2352	9	CHAT	Class Trainer	GOSSIP	0
2352	10	CHAT	Profession Trainer	GOSSIP	2351
2381	0	TRAINER	I am interested in warlock training.	TRAINER	0
2381	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
2383	0	TRAINER	I am interested in warlock training.	TRAINER	0
2383	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
2384	0	TRAINER	I am interested in warlock training.	TRAINER	0
2384	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
2387	0	CHAT	Um... sorry to bother you, but could I see Goodsteel's ledger again... if you're not using it.	GOSSIP	2386
2404	0	MONEY_BAG	I would like to check my deposit box.	BANKER	0
2405	0	CHAT	Is there a difference between ooze and slime?	GOSSIP	0
2405	1	CHAT	What do you mean by \\"pure?\\"	GOSSIP	0
2405	2	CHAT	Are there any areas you can think of that would be so untouched?	GOSSIP	0
2422	0	CHAT	What do you think of Dadanga?	GOSSIP	2421
3668	0	CHAT	I... I did not think of it that way, Warchief.	GOSSIP	3669
2464	0	VENDOR	Let me browse your goods.	VENDOR	0
2465	0	CHAT	Lady Jaina, this may sound like an odd request... but I have a young ward who is quite shy.  You are a hero to him, and he asked me to get your autograph.	GOSSIP	5850
2685	1	VENDOR	I want to browse your goods.	VENDOR	0
2703	0	CHAT	How do I use the Cache of Mau'ari?	GOSSIP	2704
2703	1	CHAT	What is E'ko?	GOSSIP	2705
2741	0	TRAINER	Train me.	TRAINER	0
2744	0	TRAINER	Train me.	TRAINER	0
2744	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
2781	0	TRAINER	Train me.	TRAINER	0
2784	0	TRAINER	Train me.	TRAINER	0
2802	0	CHAT	Do it... Do it now.	GOSSIP	0
2847	0	CHAT	Alchemy	GOSSIP	2834
2847	1	CHAT	Blacksmithing	GOSSIP	2835
2847	2	CHAT	Cooking	GOSSIP	2836
2847	3	CHAT	Enchanting	GOSSIP	2837
2847	4	CHAT	Engineering	GOSSIP	2838
2847	5	CHAT	First Aid	GOSSIP	2839
2847	6	CHAT	Fishing	GOSSIP	2840
2847	7	CHAT	Herbalism	GOSSIP	2841
2847	9	CHAT	Leatherworking	GOSSIP	2842
2847	10	CHAT	Mining	GOSSIP	2843
2847	11	CHAT	Skinning	GOSSIP	2844
2847	12	CHAT	Tailoring	GOSSIP	2845
2848	0	CHAT	Mage	GOSSIP	2821
2848	1	CHAT	Paladin	GOSSIP	8165
2848	2	CHAT	Priest	GOSSIP	2829
2848	3	CHAT	Rogue	GOSSIP	2830
2848	4	CHAT	Warlock	GOSSIP	2832
2848	5	CHAT	Warrior	GOSSIP	2833
2849	0	CHAT	The bank	GOSSIP	2822
2849	1	CHAT	The bat handler	GOSSIP	2823
2849	2	CHAT	The guild master	GOSSIP	2824
2849	3	CHAT	The inn	GOSSIP	2825
2849	4	CHAT	The mailbox	GOSSIP	2826
2849	5	CHAT	The auction house	GOSSIP	2827
2849	6	CHAT	The zeppelin master	GOSSIP	2828
2849	7	CHAT	The weapon master	GOSSIP	3726
2849	8	CHAT	The stable master	GOSSIP	4906
2849	9	CHAT	The battlemaster	GOSSIP	8225
2849	12	CHAT	A class trainer	GOSSIP	2848
2849	13	CHAT	A profession trainer	GOSSIP	2847
2890	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
2890	4	VENDOR	I want to browse your goods.	VENDOR	0
2890	0	CHAT	Trick or Treat!	GOSSIP	0
2890	5	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
2901	0	CHAT	Hello, Eitrigg. I bring news from Blackrock Spire.	GOSSIP	2902
2902	0	CHAT	There is only one Warchief, Eitrigg!	GOSSIP	2903
2903	0	CHAT	What do you mean?	GOSSIP	2904
2904	0	CHAT	Hearthglen?? But...	GOSSIP	2905
2905	0	CHAT	I will take you up on that offer, Eitrigg.	GOSSIP	2906
2906	0	CHAT	Ah, so that is how they pushed the Dark Iron to the lower parts of the Spire.	GOSSIP	2907
2907	0	CHAT	Perhaps there exists a way?	GOSSIP	2908
2908	0	CHAT	As you wish, Eitrigg.	GOSSIP	-1
2945	0	CHAT	To Malyfous, I assume.	GOSSIP	-1
2946	0	CHAT	I'll consider that the next time I run into one of these things.	GOSSIP	2945
2947	0	CHAT	Oh?	GOSSIP	2946
2948	0	CHAT	I must know something: How did you go to the bathroom with that thing on?	GOSSIP	2947
2949	0	CHAT	So let me get this straight. You were swimming, nay, doing backstrokes in molten lava with this... this lava suit of yours? Yes? And out of nowhere, this here beast swallowed you whole? 	GOSSIP	2948
2950	0	CHAT	I'm all ears.	GOSSIP	2949
2951	0	CHAT	How the hell did you get in there to begin with?	GOSSIP	2950
2952	0	VENDOR	I would like to buy from you.	VENDOR	0
3049	0	CHAT	You will have to excuse me, Lorax, I do not speak 'crazy.'	GOSSIP	20015
3062	0	CHAT	Low spirits	GOSSIP	-1
3062	1	CHAT	Bad hang nail	GOSSIP	-1
3062	2	CHAT	Feeling underpowered	GOSSIP	-1
3062	3	CHAT	Jungle Fever	GOSSIP	-1
3062	4	CHAT	Uni-brow	GOSSIP	-1
3062	5	CHAT	Whiplash	GOSSIP	-1
3062	6	CHAT	I don't want to go back to work	GOSSIP	-1
3063	0	CHAT	You will be ok, Awbee. Your assailants have been terminated.	GOSSIP	3064
3064	0	CHAT	Absolutely.	GOSSIP	3065
3065	0	CHAT	Horrifying.	GOSSIP	3066
3066	0	CHAT	Continue please...	GOSSIP	-1
3067	0	TRAINER	I would like to train.	TRAINER	0
3130	0	VENDOR	Let me browse your goods.	VENDOR	0
3142	0	CHAT	I lost the Flute of the Ancients and require a replacement, Eridan.	GOSSIP	-1
3161	0	VENDOR	I would like to buy from you.	VENDOR	0
3162	0	VENDOR	I would like to buy from you.	VENDOR	0
3181	0	VENDOR	I wish to make a purchase.	VENDOR	0
3182	0	CHAT	I wish to become an armorsmith.	GOSSIP	0
3182	1	CHAT	I wish to become a weaponsmith.	GOSSIP	0
3183	0	CHAT	How are we doing in the battle to subvert the cauldrons?	GOSSIP	0
3184	0	CHAT	How are we doing in the battle to subvert the cauldrons?	GOSSIP	0
3185	0	VENDOR	I would like to buy from you.	VENDOR	0
3186	0	VENDOR	I would like to buy from you.	VENDOR	0
3201	0	TRAINER	I require training.	TRAINER	0
3223	4	VENDOR	What's needed for the cauldron at the Writhing Haunt?	GOSSIP	3226
3223	3	VENDOR	What's needed for the cauldron at Dalson's Tears?	GOSSIP	3225
3223	2	VENDOR	What's needed for the cauldron at Felstone Field?	GOSSIP	3224
3223	1	VENDOR	I wish to purchase arcane quickener from you.	VENDOR	0
3223	0	CHAT	I need a vitreous focuser.	GOSSIP	-1
3223	5	VENDOR	What's needed for the cauldron at Gahrron's Withering?	GOSSIP	3227
3228	0	CHAT	I need a vitreous focuser.	GOSSIP	-1
3228	1	VENDOR	I wish to purchase arcane quickener from you.	VENDOR	0
3228	2	VENDOR	What's needed for the cauldron at Felstone Field?	GOSSIP	3224
3228	3	VENDOR	What's needed for the cauldron at Dalson's Tears?	GOSSIP	3225
3228	4	VENDOR	What's needed for the cauldron at the Writhing Haunt?	GOSSIP	3226
3228	5	VENDOR	What's needed for the cauldron at Gahrron's Withering?	GOSSIP	3227
3283	0	CHAT	Hunter	GOSSIP	3261
3283	1	CHAT	Mage	GOSSIP	3262
3283	2	CHAT	Priest	GOSSIP	3263
3283	3	CHAT	Rogue	GOSSIP	3264
3283	4	CHAT	Shaman	GOSSIP	3265
3283	5	CHAT	Warlock	GOSSIP	3266
3283	6	CHAT	Warrior	GOSSIP	3267
3284	0	CHAT	Alchemy	GOSSIP	3268
3284	1	CHAT	Blacksmithing	GOSSIP	3269
3284	2	CHAT	Cooking	GOSSIP	3270
3284	3	CHAT	Enchanting	GOSSIP	3271
3284	4	CHAT	Engineering	GOSSIP	3272
3284	5	CHAT	First Aid	GOSSIP	3273
3284	6	CHAT	Fishing	GOSSIP	3274
3284	7	CHAT	Herbalism	GOSSIP	3275
3284	9	CHAT	Leatherworking	GOSSIP	3276
3284	10	CHAT	Mining	GOSSIP	3277
3284	11	CHAT	Skinning	GOSSIP	3278
3284	12	CHAT	Tailoring	GOSSIP	3279
3285	0	CHAT	The bank	GOSSIP	3280
3285	1	CHAT	The wind rider master	GOSSIP	3281
3285	2	CHAT	The inn	GOSSIP	3282
3285	3	CHAT	The stable master	GOSSIP	4901
3285	4	CHAT	A class trainer	GOSSIP	3283
3285	5	CHAT	A profession trainer	GOSSIP	3284
3301	0	CHAT	This is an atrocity.	GOSSIP	3303
3302	0	CHAT	How can I help?	GOSSIP	0
3303	0	CHAT	I feel sick.	GOSSIP	3302
3304	0	CHAT	Tell me more.	GOSSIP	3301
3305	0	CHAT	No restraints? Just in a circle?	GOSSIP	3304
3306	0	CHAT	So what happened?	GOSSIP	3305
3307	0	CHAT	Why didn't you just leave?	GOSSIP	3306
3308	0	CHAT	What do you mean?	GOSSIP	3307
3309	0	CHAT	Until what, Eva? I must know.	GOSSIP	3308
3310	0	CHAT	The pleasure is mine, madam. Might I ask what it is that you are doing here?	GOSSIP	3309
3329	0	CHAT	Druid	GOSSIP	3314
3329	1	CHAT	Hunter	GOSSIP	3315
3329	2	CHAT	Shaman	GOSSIP	3316
3329	3	CHAT	Warrior	GOSSIP	3317
3330	0	CHAT	Alchemy	GOSSIP	3318
3330	1	CHAT	Blacksmithing	GOSSIP	3319
3330	2	CHAT	Cooking	GOSSIP	3320
3330	3	CHAT	Enchanting	GOSSIP	3321
3330	4	CHAT	First Aid	GOSSIP	3322
3330	5	CHAT	Fishing	GOSSIP	3323
3330	6	CHAT	Herbalism	GOSSIP	3324
3330	8	CHAT	Leatherworking	GOSSIP	3325
3330	9	CHAT	Mining	GOSSIP	3326
3330	10	CHAT	Skinning	GOSSIP	3327
3330	11	CHAT	Tailoring	GOSSIP	3328
3331	0	CHAT	The bank	GOSSIP	3311
3331	1	CHAT	The wind rider master	GOSSIP	3312
3331	2	CHAT	The inn	GOSSIP	3313
3331	3	CHAT	The stable master	GOSSIP	4903
3331	4	CHAT	A class trainer	GOSSIP	3329
3331	5	CHAT	A profession trainer	GOSSIP	3330
3354	0	CHAT	Mage	GOSSIP	3337
3354	1	CHAT	Paladin	GOSSIP	8166
3354	2	CHAT	Priest	GOSSIP	3338
3354	3	CHAT	Rogue	GOSSIP	3339
3354	4	CHAT	Warlock	GOSSIP	3340
3354	5	CHAT	Warrior	GOSSIP	3341
3355	0	CHAT	Alchemy	GOSSIP	3342
3355	1	CHAT	Blacksmithing	GOSSIP	3343
3355	2	CHAT	Cooking	GOSSIP	3344
3355	3	CHAT	Enchanting	GOSSIP	3345
3355	4	CHAT	Engineering	GOSSIP	3346
3355	5	CHAT	First Aid	GOSSIP	3347
3355	6	CHAT	Fishing	GOSSIP	3348
3355	7	CHAT	Herbalism	GOSSIP	3349
3355	9	CHAT	Leatherworking	GOSSIP	3350
3355	10	CHAT	Mining	GOSSIP	3351
3355	11	CHAT	Skinning	GOSSIP	3352
3355	12	CHAT	Tailoring	GOSSIP	3353
3356	0	CHAT	The bank	GOSSIP	3334
3356	1	CHAT	The bat handler	GOSSIP	3335
3356	2	CHAT	The inn	GOSSIP	3336
3356	3	CHAT	The stable master	GOSSIP	4905
3356	4	CHAT	A class trainer	GOSSIP	3354
3356	5	CHAT	A profession trainer	GOSSIP	3355
3364	0	CHAT	Yes I am.	GOSSIP	3372
3365	0	CHAT	Yes I do.	GOSSIP	3364
3366	0	CHAT	Continue, please.	GOSSIP	3365
3367	0	CHAT	Ras Frostwhat? Who is that?	GOSSIP	3366
3368	0	CHAT	What is this plan?	GOSSIP	3367
3369	0	CHAT	Who do I need to kill?	GOSSIP	3368
3370	0	CHAT	This is disheartening. Is there anything I can do to stop this?	GOSSIP	3369
3371	0	CHAT	Impossible.	GOSSIP	3370
3372	0	CHAT	Tell me about the Cult of the Damned.	GOSSIP	3371
3421	0	CHAT	I need another Argent Dawn Commission.	GOSSIP	-1
3421	1	VENDOR	I would like to buy from you.	VENDOR	0
3441	1	VENDOR	I would like to buy from you.	VENDOR	0
3441	0	CHAT	I need another Argent Dawn Commission.	GOSSIP	-1
3461	0	CHAT	I need another Argent Dawn Commission.	GOSSIP	-1
3461	1	VENDOR	I would like to buy from you.	VENDOR	0
3461	2	CHAT	Miranda, could you please tell me the insignia cost of items that you are offering for adventurers with other reputations?	GOSSIP	7208
3481	0	CHAT	The land of Azshara.	GOSSIP	4061
3481	1	CHAT	The Ruins of Eldarath.	GOSSIP	4062
3481	2	CHAT	The mage tower to the north.	GOSSIP	4063
3481	3	CHAT	The Timbermaw furbolgs.	GOSSIP	4064
3481	4	CHAT	The presence of blue dragons.	GOSSIP	4065
3501	0	VENDOR	I want to browse your goods.	VENDOR	0
3502	0	CHAT	I am ready to hear your tale, Tirion.	GOSSIP	3683
3506	0	CHAT	Bank	GOSSIP	3507
3506	1	CHAT	Gryphon Master	GOSSIP	3508
3506	2	CHAT	Guild Master	GOSSIP	3509
3506	3	CHAT	Inn	GOSSIP	3510
3506	4	CHAT	Stable Master	GOSSIP	4924
3506	5	CHAT	Class Trainer	GOSSIP	3519
3506	6	CHAT	Profession Trainer	GOSSIP	3532
3519	0	CHAT	Druid	GOSSIP	3511
3519	1	CHAT	Hunter	GOSSIP	3512
3519	2	CHAT	Mage	GOSSIP	3514
3519	3	CHAT	Paladin	GOSSIP	3515
3519	4	CHAT	Priest	GOSSIP	3513
3519	5	CHAT	Rogue	GOSSIP	3516
3519	6	CHAT	Shaman	GOSSIP	8160
3519	7	CHAT	Warlock	GOSSIP	3518
3519	8	CHAT	Warrior	GOSSIP	3517
3532	0	CHAT	Alchemy	GOSSIP	3520
3532	1	CHAT	Blacksmithing	GOSSIP	3521
3532	2	CHAT	Cooking	GOSSIP	3522
3532	3	CHAT	Enchanting	GOSSIP	3523
3532	4	CHAT	Engineering	GOSSIP	3524
3532	5	CHAT	First Aid	GOSSIP	3525
3532	6	CHAT	Fishing	GOSSIP	3526
3532	7	CHAT	Herbalism	GOSSIP	3527
3532	9	CHAT	Leatherworking	GOSSIP	3528
3532	10	CHAT	Mining	GOSSIP	3529
3532	11	CHAT	Skinning	GOSSIP	3530
3532	12	CHAT	Tailoring	GOSSIP	3531
3533	0	CHAT	Bank	GOSSIP	3534
3533	1	CHAT	Gryphon Master	GOSSIP	3535
3533	2	CHAT	Guild Master	GOSSIP	3536
3533	3	CHAT	The inn	GOSSIP	3537
3533	4	CHAT	Stable Master	GOSSIP	4926
3533	5	CHAT	Class Trainer	GOSSIP	3545
3533	6	CHAT	Profession Trainer	GOSSIP	3558
3545	0	CHAT	Hunter	GOSSIP	3538
3545	1	CHAT	Mage	GOSSIP	3539
3545	2	CHAT	Paladin	GOSSIP	3540
3545	3	CHAT	Priest	GOSSIP	3541
3545	4	CHAT	Rogue	GOSSIP	3542
3545	5	CHAT	Warlock	GOSSIP	3543
3545	6	CHAT	Warrior	GOSSIP	3544
3558	0	CHAT	Alchemy	GOSSIP	3546
3558	1	CHAT	Blacksmithing	GOSSIP	3547
3558	2	CHAT	Cooking	GOSSIP	3548
3558	3	CHAT	Enchanting	GOSSIP	3549
3558	4	CHAT	Engineering	GOSSIP	3550
3558	5	CHAT	First Aid	GOSSIP	3551
3558	6	CHAT	Fishing	GOSSIP	3552
3558	7	CHAT	Herbalism	GOSSIP	3553
3558	9	CHAT	Leatherworking	GOSSIP	3554
3558	10	CHAT	Mining	GOSSIP	3555
3558	11	CHAT	Skinning	GOSSIP	3556
3558	12	CHAT	Tailoring	GOSSIP	3557
3564	0	CHAT	Druid	GOSSIP	3565
3564	1	CHAT	Hunter	GOSSIP	3566
3564	2	CHAT	Priest	GOSSIP	3567
3564	3	CHAT	Rogue	GOSSIP	3568
3564	4	CHAT	Warrior	GOSSIP	3569
3572	0	CHAT	Alchemy	GOSSIP	3570
3572	1	CHAT	Cooking	GOSSIP	3571
3572	2	CHAT	Enchanting	GOSSIP	3573
3572	3	CHAT	First Aid	GOSSIP	3574
3572	4	CHAT	Fishing	GOSSIP	3575
3572	5	CHAT	Herbalism	GOSSIP	3576
3572	7	CHAT	Leatherworking	GOSSIP	3577
3572	8	CHAT	Skinning	GOSSIP	3578
3572	9	CHAT	Tailoring	GOSSIP	3579
3580	0	CHAT	The bank	GOSSIP	3560
3580	1	CHAT	Rut'theran Ferry	GOSSIP	3561
3580	2	CHAT	The Guild Master.	GOSSIP	3562
3580	3	CHAT	The inn	GOSSIP	3563
3580	4	CHAT	Stable Master	GOSSIP	4923
3580	5	CHAT	Class Trainer	GOSSIP	3564
3580	6	CHAT	Profession Trainer	GOSSIP	3572
3622	0	CHAT	How can I prove myself to the Timbermaw furbolg?	GOSSIP	3621
3624	0	CHAT	What about the Winterfall furbolg?	GOSSIP	3623
3624	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
3626	0	TRAINER	I'd like to train.	TRAINER	0
3626	1	VENDOR	Let me browse your goods.	VENDOR	0
3643	0	TRAINER	Train me	TRAINER	0
3643	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3644	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
3644	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3681	0	CHAT	I will, Tirion.	GOSSIP	-1
3682	0	CHAT	That is terrible.	GOSSIP	3681
3683	0	CHAT	Thank you, Tirion. What of your identity?	GOSSIP	3682
3701	2	CHAT	You may speak frankly, Neeru...	GOSSIP	20005
3801	0	CHAT	I am ready for the illusion, Myranda.	GOSSIP	-1
3862	0	CHAT	You have fought well, spirit.  I ask you to grant me the strength of your body and the stength of your heart.	GOSSIP	3863
3862	1	CHAT	You have fought well, spirit.  I ask you to grant me the strength of your body and the stength of your heart.	GOSSIP	3863
3881	0	CHAT	I seek to understand the importance of strength of the body.	GOSSIP	3883
3882	0	CHAT	What do you represent, spirit?	GOSSIP	3881
3883	0	CHAT	I seek to understand the importance of strength of the heart.	GOSSIP	3884
3884	0	CHAT	I have heard your words, Great Bear Spirit, and I understand.  I now seek your blessings to fully learn the way of the Claw.	GOSSIP	3885
3884	1	CHAT	I have heard your words, Great Bear Spirit, and I understand.  I now seek your blessings to fully learn the way of the Claw.	GOSSIP	3885
3921	0	TRAINER	I seek training as a druid.	TRAINER	0
3921	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3923	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3923	0	TRAINER	I seek training as a druid.	TRAINER	0
3924	0	TRAINER	I seek training as a druid.	TRAINER	0
3924	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3925	0	TRAINER	I seek training as a druid.	TRAINER	0
3925	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3926	0	TRAINER	I seek training as a druid.	TRAINER	0
3926	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3984	4	CHAT	<Take the letter>	GOSSIP	-1
3984	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3984	0	TRAINER	Yes, I have. Teach me.	TRAINER	0
4001	0	VENDOR	I would like to buy from you.	VENDOR	0
4002	0	VENDOR	Let me take a look at what you have to offer.	VENDOR	0
4003	0	VENDOR	I am curious to see what a bucket of bolts has to offer.	VENDOR	0
4004	0	VENDOR	I would like to buy from you.	VENDOR	0
4005	0	VENDOR	I would like to buy from you.	VENDOR	0
4006	0	VENDOR	I would like to buy from you.	VENDOR	0
4007	0	TRAINER	I'd like to train.	TRAINER	0
4007	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4009	0	TRAINER	I am in need of training.	TRAINER	0
4009	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4010	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4010	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4011	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4011	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4012	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4012	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4014	0	TRAINER	I seek training to ride a steed.	TRAINER	0
4015	0	TRAINER	I seek training to ride a steed.	TRAINER	0
4017	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4017	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4018	0	TRAINER	I seek training to ride a steed.	TRAINER	0
4019	0	TRAINER	I seek training to ride a steed.	TRAINER	0
4021	0	TRAINER	I seek training to ride a steed.	TRAINER	0
4022	0	TRAINER	I seek training to ride a steed.	TRAINER	0
4023	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4023	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4041	0	CHAT	I'd like to fly to Rut'theran Village.	GOSSIP	-1
4041	1	CHAT	Do you know where I may find the Half Pendant of Aquatic Agility?	GOSSIP	20009
4042	0	CHAT	I'd like to fly to Thunder Bluff.	GOSSIP	-1
4042	1	CHAT	Do you know where I may find the Half Pendant of Aquatic Endurance?	GOSSIP	20010
4066	0	VENDOR	I want to browse your goods.	VENDOR	0
4085	0	VENDOR	Yes, Augustus.  I would like to do business.	VENDOR	0
4090	0	VENDOR	I would like to buy from you.	VENDOR	0
4091	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4091	0	TRAINER	Yes. I have.	TRAINER	0
4092	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4092	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4101	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4101	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4103	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4103	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4104	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4104	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4106	0	TAXI	I need a ride.	TAXIVENDOR	0
4106	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4107	0	VENDOR	I would like to buy from you.	VENDOR	0
4107	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4115	0	TRAINER	Train me.	TRAINER	0
4123	0	TRAINER	Train me.	TRAINER	0
4126	0	TRAINER	Train me.	TRAINER	0
4135	0	TRAINER	Train me.	TRAINER	0
4145	0	TRAINER	Train me.	TRAINER	0
4150	0	TRAINER	Train me.	TRAINER	0
4163	0	TRAINER	Train me.	TRAINER	0
4164	0	TRAINER	Train me.	TRAINER	0
4169	0	TRAINER	Train me.	TRAINER	0
4171	0	TRAINER	Train me.	TRAINER	0
4174	0	TRAINER	Train me.	TRAINER	0
4185	0	TRAINER	Train me.	TRAINER	0
4205	0	TRAINER	Train me.	TRAINER	0
4209	0	TRAINER	Train me.	TRAINER	0
4242	0	TRAINER	Train me.	TRAINER	0
4261	0	TRAINER	Train me.	TRAINER	0
4281	0	TAXI	I need a ride.	TAXIVENDOR	0
4281	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4282	0	TAXI	I need a ride.	TAXIVENDOR	0
4283	0	VENDOR	Let me browse your goods.	VENDOR	0
4301	0	TAXI	I need a ride.	TAXIVENDOR	0
4302	0	TAXI	I need a ride.	TAXIVENDOR	0
4302	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4303	0	VENDOR	I want to browse your goods.	VENDOR	0
4304	0	VENDOR	I want to browse your goods.	VENDOR	0
4305	0	VENDOR	Let me browse your goods.	VENDOR	0
4306	0	TAXI	Sure! Let's go for a ride.	TAXIVENDOR	0
4307	0	TAXI	I need a ride.	TAXIVENDOR	0
4307	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4323	0	TAXI	I need a ride.	TAXIVENDOR	0
4323	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4326	0	TAXI	I need a ride.	TAXIVENDOR	0
4342	0	TAXI	I need a ride.	TAXIVENDOR	0
4342	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4345	0	TRAINER	Train me.	TRAINER	0
4346	3	CHAT	What can you tell me about the hippogryph - Sharptalon?	GOSSIP	4382
4346	2	CHAT	What can you tell me about the nightsaber cat - Shadumbra?	GOSSIP	4383
4346	1	CHAT	What can you tell me about the bear - Ursangous?	GOSSIP	4381
4348	0	TRAINER	Train me.	TRAINER	0
4349	0	TRAINER	Train me.	TRAINER	0
4351	0	TRAINER	Train me.	TRAINER	0
4353	0	TRAINER	Train me.	TRAINER	0
4355	0	TRAINER	Train me.	TRAINER	0
4358	0	TAXI	I need a ride.	TAXIVENDOR	0
4359	0	VENDOR	I would like to buy from you.	VENDOR	0
4360	0	TAXI	I need a ride.	TAXIVENDOR	0
4360	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4361	0	TRAINER	I would like to train.	TRAINER	0
4362	0	CHAT	Place Termite Barrel on the crate.	GOSSIP	0
4461	0	CHAT_11	Yes. I do.	UNLEARN_TALENTS	0
4463	0	CHAT_11	Yes. I do.	UNLEARN_TALENTS	0
4468	0	TRAINER	Train me	TRAINER	0
4468	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4469	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4469	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4470	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4470	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4471	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4471	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4472	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4472	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4473	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4473	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4474	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4474	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4484	0	TRAINER	I am interested in mage training.	TRAINER	0
4484	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4485	0	TRAINER	I am interested in mage training.	TRAINER	0
4485	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4485	2	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4486	0	TRAINER	I am interested in mage training.	TRAINER	0
4486	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4502	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
4502	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4502	4	CHAT	<Take the letter>	GOSSIP	-1
4503	0	TRAINER	I am interested in warlock training.	TRAINER	0
4503	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4504	0	TRAINER	I am interested in warlock training.	TRAINER	0
4504	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4505	0	TRAINER	I am interested in warlock training.	TRAINER	0
4505	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4506	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4506	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4507	0	TRAINER	I seek training as a druid.	TRAINER	0
4507	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4508	0	TRAINER	I seek training as a druid.	TRAINER	0
4508	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4510	0	TRAINER	I require warrior training.	TRAINER	0
4510	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4512	0	TRAINER	I would like training.	TRAINER	0
4512	4	CHAT	<Take the letter>	GOSSIP	-1
4512	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4513	4	CHAT	<Take the letter>	GOSSIP	-1
4513	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4513	0	TRAINER	I would like training.	TRAINER	0
4516	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4516	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4521	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4521	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4522	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4522	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4523	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4523	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4524	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4524	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4525	0	TRAINER	I require warrior training.	TRAINER	0
4525	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4526	0	TRAINER	I require warrior training.	TRAINER	0
4526	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4527	0	TRAINER	I require warrior training.	TRAINER	0
4527	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4528	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4528	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4529	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4529	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4530	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4530	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4531	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4531	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4532	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4532	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4533	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4533	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4534	0	TRAINER	I am interested in mage training.	TRAINER	0
4534	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4535	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4535	0	TRAINER	I am interested in mage training.	TRAINER	0
4536	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4536	0	TRAINER	I am interested in mage training.	TRAINER	0
4537	0	TRAINER	I am interested in mage training.	TRAINER	0
4537	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4538	0	TRAINER	I am interested in mage training.	TRAINER	0
4538	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4539	0	TRAINER	I am interested in mage training.	TRAINER	0
4539	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4544	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4544	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4549	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4549	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4550	0	TRAINER	I am here for training.	TRAINER	0
4550	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4551	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4551	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4552	0	TRAINER	I am interested in mage training.	TRAINER	0
4552	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4553	0	TRAINER	I am interested in mage training.	TRAINER	0
4553	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4556	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4556	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4557	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4557	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4561	0	TRAINER	I'm lookin' for rogue trainin'.	TRAINER	0
4561	4	CHAT	<Take the letter>	GOSSIP	-1
4561	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4562	0	TRAINER	I'm lookin' for rogue trainin'.	TRAINER	0
4562	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4562	4	CHAT	<Take the letter>	GOSSIP	-1
4567	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4567	0	TRAINER	I am interested in warlock training.	TRAINER	0
4568	0	TRAINER	I require warrior training.	TRAINER	0
4568	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4569	0	TRAINER	I require warrior training.	TRAINER	0
4569	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4570	0	TRAINER	I require warrior training.	TRAINER	0
4570	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4571	0	TRAINER	I seek training as a druid.	TRAINER	0
4571	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4576	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
4576	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4576	4	CHAT	<Take the letter>	GOSSIP	-1
4578	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4578	0	TRAINER	I require warrior training.	TRAINER	0
4603	0	TRAINER	I am interested in warlock training.	TRAINER	0
4603	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4604	0	TRAINER	I am interested in warlock training.	TRAINER	0
4604	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4605	0	TRAINER	I seek further druidic training to have a closer understanding of the Earth Mother's will.	TRAINER	0
4605	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4606	0	TRAINER	I seek training as a druid.	TRAINER	0
4606	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4607	0	TRAINER	I seek training as a druid.	TRAINER	0
4607	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4609	0	TRAINER	I am interested in warlock training.	TRAINER	0
4609	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4610	0	TRAINER	I submit myself for further training my master.	TRAINER	0
4610	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4621	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4621	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4641	0	TRAINER	I am interested in warlock training.	TRAINER	0
4641	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4642	0	TRAINER	It is a greater knowledge of the ways of the warlock that I crave.	TRAINER	0
4642	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4643	0	TRAINER	I am interested in warlock training.	TRAINER	0
4643	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4644	0	TRAINER	I seek training as a druid.	TRAINER	0
4644	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4645	0	TRAINER	I require warrior training.	TRAINER	0
4645	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4647	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4647	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4648	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4648	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4649	0	TRAINER	I require warrior training.	TRAINER	0
4649	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4650	0	TRAINER	I require warrior training.	TRAINER	0
4650	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4652	0	TRAINER	I'd like to train.	TRAINER	0
4652	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4653	0	TRAINER	I require warrior training.	TRAINER	0
4653	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4654	0	TRAINER	I am interested in mage training.	TRAINER	0
4654	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4655	0	TRAINER	I submit myself for further training my master.	TRAINER	0
4655	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4656	0	TRAINER	I submit myself for further training my master.	TRAINER	0
4656	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4657	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4657	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4658	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
4658	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4658	4	CHAT	<Take the letter>	GOSSIP	-1
4659	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
4659	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4659	4	CHAT	<Take the letter>	GOSSIP	-1
4660	0	TRAINER	I am interested in mage training.	TRAINER	0
4660	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4661	0	TRAINER	I am interested in mage training.	TRAINER	0
4661	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4662	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4662	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4663	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4663	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4664	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4664	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4665	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4665	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4666	0	TRAINER	Train me	TRAINER	0
4666	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4667	0	TRAINER	I am interested in warlock training.	TRAINER	0
4667	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4674	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4674	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4675	0	TRAINER	I seek training in the ways of the Hunter.	TRAINER	0
4675	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4676	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
4676	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4676	4	CHAT	<Take the letter>	GOSSIP	-1
4677	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4677	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4678	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4678	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4680	0	TRAINER	Train me	TRAINER	0
4680	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4681	0	TRAINER	I am interested in warlock training.	TRAINER	0
4681	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4682	0	TRAINER	I am interested in warlock training.	TRAINER	0
4682	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4683	0	TRAINER	I require warrior training.	TRAINER	0
4683	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4684	0	TRAINER	I require warrior training.	TRAINER	0
4684	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4685	0	TRAINER	I am interested in mage training.	TRAINER	0
4685	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4687	0	TRAINER	I seek training as a druid.	TRAINER	0
4687	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4688	0	TRAINER	I seek training as a druid.	TRAINER	0
4688	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4690	0	TRAINER	I seek training.	TRAINER	0
4690	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4690	4	CHAT	<Take the letter>	GOSSIP	-1
4691	0	TRAINER	I would like to train further in the ways of the Light.	TRAINER	0
4691	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4693	0	TRAINER	I'd like to train.	TRAINER	0
4693	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4694	0	TRAINER	I'd like to train.	TRAINER	0
4694	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4695	0	TRAINER	I'd like to train.	TRAINER	0
4695	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4697	0	TRAINER	I require warrior training.	TRAINER	0
4697	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4741	0	TRAINER	I require training, Lumak.	TRAINER	0
4742	0	TRAINER	I require training, Grimnur.	TRAINER	0
4743	0	CHAT	Where can I get Enchanted Thorium?	GOSSIP	50100
4743	1	CHAT	Where can I find Crystal Restore?	GOSSIP	50101
4746	0	VENDOR	I wish to browse your goods, Dirge.	VENDOR	0
4746	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
4748	0	TRAINER	I require training, Daryl.	TRAINER	0
4762	0	TRAINER	I require training, Nissa.	TRAINER	0
4763	0	CHAT	Ysera is my answer.	GOSSIP	-1
4763	1	CHAT	Neltharion is  my answer.	GOSSIP	-1
4763	2	CHAT	My answer - Nozdormu.	GOSSIP	-1
4763	3	CHAT	Alexstrasza is  my answer.	GOSSIP	-1
4763	4	CHAT	Malygos is my answer.	GOSSIP	-1
4764	0	VENDOR	Gul'dan	GOSSIP	-1
4764	1	VENDOR	Kel'Thuzad	GOSSIP	-1
4764	2	VENDOR	Ner'zhul is my answer.	GOSSIP	-1
4781	0	VENDOR	Show me what I have access to, Lokhtos.	VENDOR	0
4781	1	CHAT	Hrm, I'm listening. What is this offer?	GOSSIP	5847
4783	1	TRAINER	How do I train my pet?	TRAINER	0
4783	2	CHAT	I wish to untrain my pet.	UNLEARN_PET_SKILLS	0
4842	0	TRAINER	Train me.	TRAINER	0
4844	0	TRAINER	Train me.	TRAINER	0
4845	0	VENDOR	I want to browse your goods.	VENDOR	0
5021	5	CHAT	How many more supplies are needed for the next upgrade?	GOSSIP	0
5061	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
5061	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
5061	4	CHAT	<Take the letter>	GOSSIP	-1
5065	0	CHAT	[PH] I desire an aqual quintessence, Duke Hydraxis.	GOSSIP	-1
5065	1	CHAT	I desire this eternal quintessence, Duke Hydraxis.	GOSSIP	-1
5123	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
5123	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
5124	3	CHAT	How many more supplies are needed for the next upgrade?	GOSSIP	0
5146	0	CHAT	I got your back, Ichman. GO GO GO!	GOSSIP	0
5148	0	CHAT	I got your back, Slidore, but to be honest, you do stink. Take a shower, man.	GOSSIP	0
5181	0	VENDOR	Let me browse your seasonal fare.	VENDOR	0
5221	0	TRAINER	I'd like some weapon training	TRAINER	0
5221	1	CHAT	What can other weapon masters teach?	GOSSIP	5222
5222	0	CHAT	Crossbow	GOSSIP	8594
5222	1	CHAT	Gun	GOSSIP	8597
5222	2	CHAT	Mace	GOSSIP	8598
5222	3	CHAT	Polearm	GOSSIP	8599
5222	4	CHAT	Staff	GOSSIP	8610
5222	5	CHAT	Sword	GOSSIP	8601
5241	0	CHAT	How many more supplies are needed to send ground assaults?	GOSSIP	5626
5241	2	VENDOR	I want to browse your goods.	VENDOR	0
5262	0	CHAT	Crossbow	GOSSIP	8603
5262	1	CHAT	Dagger	GOSSIP	8604
5262	2	CHAT	Fist Weapon	GOSSIP	8605
5262	3	CHAT	Gun	GOSSIP	8606
5262	4	CHAT	Mace	GOSSIP	8607
5262	5	CHAT	Polearm	GOSSIP	8608
5262	6	CHAT	Sword	GOSSIP	8609
5263	0	TRAINER	I'd like some weapon training	TRAINER	0
5263	1	CHAT	What can other weapon masters teach?	GOSSIP	5262
5265	0	CHAT	Axe	GOSSIP	8592
5265	1	CHAT	Bow	GOSSIP	8593
5265	2	CHAT	Crossbow	GOSSIP	8594
5265	3	CHAT	Dagger	GOSSIP	8595
5265	4	CHAT	Fist Weapon	GOSSIP	8596
5265	5	CHAT	Polearm	GOSSIP	8599
5265	6	CHAT	Sword	GOSSIP	8601
5265	7	CHAT	Thrown	GOSSIP	8602
5266	0	TRAINER	I'd like some weapon training	TRAINER	0
5266	1	CHAT	What can other weapon masters teach?	GOSSIP	5265
5268	0	CHAT	Axe	GOSSIP	8592
5268	1	CHAT	Bow	GOSSIP	8593
5268	2	CHAT	Fist Weapon	GOSSIP	8596
5268	3	CHAT	Gun	GOSSIP	8597
5268	4	CHAT	Mace	GOSSIP	8598
5268	5	CHAT	Staff	GOSSIP	8600
5268	6	CHAT	Thrown	GOSSIP	8602
5269	0	TRAINER	I'd like some weapon training	TRAINER	0
5269	1	CHAT	What can other weapon masters teach?	GOSSIP	5268
5270	0	CHAT	Axe	GOSSIP	8577
5270	1	CHAT	Bow	GOSSIP	8572
5270	2	CHAT	Fist Weapon	GOSSIP	8574
5270	3	CHAT	Gun	GOSSIP	8575
5270	4	CHAT	Mace	GOSSIP	8578
5270	5	CHAT	Thrown	GOSSIP	8582
5271	0	TRAINER	I'd like some weapon training	TRAINER	0
5271	1	CHAT	What can other weapon masters teach?	GOSSIP	5270
5272	0	CHAT	Axe	GOSSIP	8577
5272	1	CHAT	Crossbow	GOSSIP	8576
5272	2	CHAT	Gun	GOSSIP	8575
5272	3	CHAT	Mace	GOSSIP	8578
5272	4	CHAT	Polearm	GOSSIP	8579
5272	5	CHAT	Sword	GOSSIP	8581
5273	0	TRAINER	I'd like some weapon training	TRAINER	0
5273	1	CHAT	What can other weapon masters teach?	GOSSIP	5272
5274	0	CHAT	Bow	GOSSIP	8583
5274	1	CHAT	Crossbow	GOSSIP	8584
5274	2	CHAT	Dagger	GOSSIP	8573
5274	3	CHAT	Polearm	GOSSIP	8579
5274	4	CHAT	Thrown	GOSSIP	8585
5274	5	CHAT	Staff	GOSSIP	8580
5274	6	CHAT	Sword	GOSSIP	8581
5275	0	TRAINER	I'd like some weapon training	TRAINER	0
5275	1	CHAT	What can other weapon masters teach?	GOSSIP	5274
5276	0	CHAT	Axe	GOSSIP	8586
5276	1	CHAT	Bow	GOSSIP	8572
5276	2	CHAT	Fist Weapon	GOSSIP	8587
5276	3	CHAT	Gun	GOSSIP	8588
5276	4	CHAT	Mace	GOSSIP	8589
5276	5	CHAT	Polearm	GOSSIP	8579
5276	6	CHAT	Staff	GOSSIP	8580
5276	7	CHAT	Sword	GOSSIP	8581
5277	0	TRAINER	I'd like some weapon training	TRAINER	0
5277	1	CHAT	What can other weapon masters teach?	GOSSIP	5276
5283	1	CHAT_12	I'd like to stable my pet here.	STABLEPET	0
5346	0	CHAT	Tell me more about the history of Remulos and Zaetar.	GOSSIP	5361
5347	0	CHAT	Please tell me more about Zaetar.	GOSSIP	5346
5349	0	CHAT	Please tell me more about Maraudon.	GOSSIP	5347
5382	1	CHAT	Teach me how to create and apply a Runecloth Bandage, Doctor.	GOSSIP	0
5382	0	CHAT	Teach me how to create and apply a Heavy Mageweave Bandage, Doctor.	GOSSIP	0
5382	2	CHAT	Teach me how to create and apply a Heavy Runecloth Bandage, Doctor.	GOSSIP	0
5461	0	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
5461	1	TALK	How do I form a guild?	PETITIONER	0
5462	0	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
5462	1	TALK	How do I form a guild?	PETITIONER	0
5541	0	VENDOR	I want to browse your goods.	VENDOR	0
5542	0	VENDOR	I want to browse your goods.	VENDOR	0
5602	0	CHAT	Thank you, Ironbark. We are ready for you to open the door.	GOSSIP	-1
5665	0	TRAINER	Train me.	TRAINER	0
5667	1	CHAT	Why should I bother fixing the trap?  Why not just eliminate the guard the old fashioned way?	GOSSIP	5716
5667	0	CHAT	So, I found this shackle key...	GOSSIP	5668
5668	0	CHAT	I guess so!	GOSSIP	-1
5675	0	CHAT	What do you know of it?	GOSSIP	5689
5687	0	CHAT	A battle?	GOSSIP	5702
5688	0	CHAT	Continue, please.	GOSSIP	5687
5689	0	CHAT	I am listening, Demitrian.	GOSSIP	5688
5701	0	CHAT	Caught unaware? How?	GOSSIP	5704
5702	0	CHAT	<Nod>.	GOSSIP	5701
5704	0	CHAT	So what did Ragnaros do next?	GOSSIP	5703
5708	0	CHAT	I'm the new king?  What are you talking about?	GOSSIP	5715
5708	1	CHAT	Henchmen?  Tribute?	GOSSIP	5740
5709	0	CHAT	Game? Are you crazy?	GOSSIP	-1
5709	1	CHAT	Why you little...	GOSSIP	-1
5709	2	CHAT	Mark my words, I will catch you, imp. And when I do!	GOSSIP	-1
5709	3	CHAT	DIE!	GOSSIP	-1
5709	4	CHAT	Prepare to meet your maker.	GOSSIP	-1
5710	0	CHAT	Why you little...	GOSSIP	-1
5711	0	CHAT	Mark my words, I will catch you, imp. And when I do!	GOSSIP	-1
5712	0	CHAT	DIE!	GOSSIP	-1
5713	0	CHAT	Prepare to meet your maker.	GOSSIP	-1
5715	0	CHAT	It's good to be the king!  Now, let's get back to what you were talking about before...	GOSSIP	5708
5721	0	VENDOR	Show me what hooch you've got to sell, Kreeg.	VENDOR	0
5723	0	CHAT	A very sad tale. Thank you, spirit.	GOSSIP	0
5724	0	CHAT	We live in a world of endless tragedy.	GOSSIP	5723
5725	0	CHAT	I'm going to have to kill something, aren't I?	GOSSIP	5724
5726	0	CHAT	Fascinating. Continue, please.	GOSSIP	5725
5727	0	CHAT	Continue, please.	GOSSIP	5726
5728	0	CHAT	I know very little of the Highborne and nothing of the Shen'dralar.	GOSSIP	5727
5729	0	CHAT	What happened here, spirit?	GOSSIP	5728
5739	1	CHAT	So, now that I'm the king... what have you got for me?!	GOSSIP	5744
5740	0	CHAT	Well then... show me the tribute!	GOSSIP	5742
5743	0	CHAT	Mourn the great loss.	GOSSIP	-1
5743	1	CHAT	Mourn the great loss.	GOSSIP	-1
5744	0	CHAT	This sounds like a task worthy of the new king!	GOSSIP	5746
5749	0	CHAT	<Copy the schematic into your engineering notebook.>	GOSSIP	-1
5750	0	CHAT	Transport me to the Molten Core, Lothos.	GOSSIP	-1
5818	0	VENDOR	Gorzeeki, I wish to make a purchase.	VENDOR	0
5845	0	CHAT	I am in search of a great and powerful Warlock.	GOSSIP	0
5849	1	CHAT	Well what do you know, this is Children's Week!  What can I do to help?	GOSSIP	60000
5851	0	CHAT	Chief Bloodhoof, this may sound like an odd request... but I have a young ward who is quite shy.  You are a hero to him, and he asked me to get your hoofprint.	GOSSIP	20021
5853	0	TRAINER	Train me.	TRAINER	0
5853	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
5854	0	TRAINER	Train me.	TRAINER	0
5855	0	TRAINER	Train me.	TRAINER	0
5856	0	TRAINER	Train me.	TRAINER	0
5962	0	VENDOR	I wish to browse your wares.	VENDOR	0
5967	0	TAXI	I need a ride.	TAXIVENDOR	0
5968	0	TAXI	I need a ride.	TAXIVENDOR	0
6001	0	CHAT	<Put your hand on the sphere.>	GOSSIP	-1
6021	0	CHAT	I can not Vaelastrasz ! Surely there must be some way to heal you!	GOSSIP	6101
6023	0	TAXI	I need a ride.	TAXIVENDOR	0
6059	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
6059	3	CHAT	What can I do at an inn?	GOSSIP	1221
6059	4	VENDOR	Let me browse your goods.	VENDOR	0
6059	0	CHAT	Trick or Treat!	GOSSIP	-1
6083	0	VENDOR	I want to browse your goods.	VENDOR	0
6085	0	VENDOR	I want to browse your goods.	VENDOR	0
6086	0	VENDOR	I would like to buy from you.	VENDOR	0
6092	0	CHAT	This Dimensional Imploder sounds dangerous!  How can I make one?	GOSSIP	-1
6094	0	CHAT	I must build a beacon for this marvelous device!	GOSSIP	-1
6101	0	CHAT	Vaelastrasz, no!!!	GOSSIP	0
6162	0	TAXI	I need a ride.	TAXIVENDOR	0
6182	0	CHAT	Silas, why is most everything at the fair free?  How do you make a profit?	GOSSIP	6181
6185	0	CHAT	I slay the man on the spot as my liege would expect me to do, as he is nothing more than a thief and a liar.	GOSSIP	6187
6185	1	CHAT	I turn over the man to my liege for punishment, as he has broken the law of the land and it is my sworn duty to enforce it.	GOSSIP	6208
6185	2	CHAT	I confiscate the corn he has stolen, warn him that stealing is a path towards doom and destruction, but I let him go to return to his family.	GOSSIP	6209
6185	3	CHAT	I allow the man to take enough corn to feed his family for a couple of days, encouraging him to leave the land.	GOSSIP	6210
6186	0	CHAT	I am ready to discover where my fortune lies!	GOSSIP	6185
6187	0	CHAT	I execute him as per my liege's instructions, and do it in such a manner that he suffers painfully before he dies as retribution for his crimes against my people.	GOSSIP	6211
6187	1	CHAT	I execute him as per my liege's instructions, but doing so in as painless of a way as possible.  Justice must be served, but I can show some compassion.\n	GOSSIP	6211
6187	2	CHAT	I risk my own life and free him so that he may prove his innocence.  If I can, I'll help him in any way.	GOSSIP	6211
6202	0	VENDOR	Let me browse your goods.	VENDOR	0
6202	1	CHAT	Tell me more about these Darkmoon Cards.	GOSSIP	6207
6207	0	CHAT	Tell me about the Beasts Deck.	GOSSIP	6203
6207	1	CHAT	Tell me about the Portals Deck.	GOSSIP	6204
6207	2	CHAT	Tell me about the Elementals Deck.	GOSSIP	6205
6207	3	CHAT	Tell me about the Warlords Deck.	GOSSIP	6206
6208	0	CHAT	I confront the ruler on his malicious behavior, upholding my liege's honor at the risk of any future diplomacy.	GOSSIP	6211
6208	1	CHAT	I not-so-quietly ignore the insult, hoping to instill a fear in the ruler that he may have gaffed.  I then inform my liege of the insult when I return.	GOSSIP	6211
6208	2	CHAT	I quietly ignore the insult.  I will not tell my liege, as I am to secure peace at all costs.  It's only an insult - not a declaration of war.	GOSSIP	6211
6209	0	CHAT	I would speak against my brother joining the order, rushing a permanent breech in our relationship.  He would be a danger to himself and those around him, and that is too great a risk hoping he would improve over time.	GOSSIP	6211
6209	1	CHAT	I would speak for my brother joining the order, potentially risking the safety of the order.  I could help him with the order's regimens, and I'd have faith in his ability to adapt and learn.	GOSSIP	6211
6209	2	CHAT	I would create some surreptitious means to keep my brother out of the order.  I can keep him out without him being any bit wiser, thereby saving our familial bonds.	GOSSIP	6211
6210	0	CHAT	I would show my liege the beast's ear and claim the beast's death as my own, taking the reward for my own use.  It is wrong to claim a deed as your own that someone else in fact did.\n	GOSSIP	6211
6210	1	CHAT	I would show my liege the beast's ear and claim the beast's death as my own - after all, I did slay it.  I would then offer some of the reward to the destitute knight to help his family.	GOSSIP	6211
6210	2	CHAT	I would remain silent about the kill and allow the knight to claim the reward to aid his family.	GOSSIP	6211
6211	0	CHAT	I'd love to get one of those written fortunes you mentioned!  I've got the space in my inventory for it.	GOSSIP	6212
6213	0	CHAT	The Darkmoon Faire has arrived, you say? And where is she now?	GOSSIP	6222
6214	0	CHAT	When the Darkmoon Faire arrives, where will it be located?	GOSSIP	6221
6230	0	VENDOR	Show me the drinks!	VENDOR	0
6233	0	VENDOR	What do you have for sale?	VENDOR	0
6234	0	VENDOR	Mmm... food.	VENDOR	0
6282	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6342	0	VENDOR	Let me browse your selection of fireworks.	VENDOR	0
6343	0	VENDOR	Let me browse your selection of fireworks.	VENDOR	0
6443	0	CHAT	[ph]Learn recipe...	GOSSIP	-1
6445	0	VENDOR	I want to browse your goods.	VENDOR	0
6459	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6460	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6461	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6462	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6463	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6464	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6465	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6466	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6467	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6468	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6469	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6470	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6471	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6472	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6473	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6474	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6475	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6478	0	BATTLE	I wish to join the battle!	BATTLEFIELD	0
6484	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6490	0	BATTLE	I wish to join the battle!	BATTLEFIELD	0
6500	0	BATTLE	I wish to join the battle!	BATTLEFIELD	0
6504	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
6508	0	BATTLE	I wish to join the battle!	BATTLEFIELD	0
6525	4	VENDOR	I wish to browse your wares, Calandrath.	VENDOR	0
6525	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
6526	0	VENDOR	Let me browse your goods.	VENDOR	0
6527	0	VENDOR	Let me browse your goods.	VENDOR	0
6528	0	VENDOR	Let me browse your goods.	VENDOR	0
6533	0	CHAT	Hello, Frankal. I've heard that you might have some information as to the whereabouts of Mistress Natalia Mar'alith.	GOSSIP	6558
6534	0	CHAT	Hello, Rutgar. The Commander has sent me here to gather some information about his missing wife.	GOSSIP	6551
6540	0	CHAT	I am no cultist, you monster!  Come to me and face your destruction!	GOSSIP	-1
6540	1	CHAT	Crimson Templar! I hold your signet! Heed my call!	GOSSIP	-1
6540	2	CHAT	Earthen Templar! I hold your signet! Heed my call!	GOSSIP	-1
6540	3	CHAT	Hoary Templar! I hold your signet! Heed my call!	GOSSIP	-1
6540	4	CHAT	Azure Templar! I hold your signet! Heed my call!	GOSSIP	-1
6542	0	CHAT	You will listen to this, vile duke!  I am not your Twilight's Hammer lapdog!  I am here to challenge you!  Come!  Come, and meet your death...	GOSSIP	-1
6542	1	CHAT	Duke of Cynders! I hold your signet!  Heed my call!	GOSSIP	-1
6542	2	CHAT	Duke of Shards! I hold your signet!  Heed my call!	GOSSIP	-1
6542	3	CHAT	Duke of Zephyrs! I hold your signet!  Heed my call!	GOSSIP	-1
6542	4	CHAT	Duke of Fathoms! I hold your signet!  Heed my call!	GOSSIP	-1
6543	0	CHAT	The day of judgement has come, fiend!  I challenge you to battle!	GOSSIP	-1
6543	1	CHAT	Skaldrenox!  I hold your scepter, and charge you to enter this world!	GOSSIP	-1
6543	2	CHAT	Kazum!  I hold your scepter!  I command you to enter this world!	GOSSIP	-1
6543	3	CHAT	Whirlaxis!  I hold your scepter!  I command you to enter this world!	GOSSIP	-1
6543	4	CHAT	Duke of Shards! I hold your signet!  Heed my call!	GOSSIP	-1
6545	0	CHAT	I'll be back once I straighten this mess out.	GOSSIP	-1
6546	0	CHAT	Possessed by what?	GOSSIP	6545
6547	0	CHAT	Lost it? What do you mean?	GOSSIP	6546
6548	0	CHAT	What demands?	GOSSIP	6547
6549	0	CHAT	Natalia?	GOSSIP	6548
6550	0	CHAT	What happened to her after that?	GOSSIP	6549
6551	0	CHAT	That sounds dangerous.	GOSSIP	6550
6552	0	CHAT	Thanks for the information, Frankal.	GOSSIP	-1
6553	0	CHAT	What a story! So she went into Hive'Regal and that was the last you saw of her?	GOSSIP	6552
6554	0	CHAT	Then what?	GOSSIP	6553
6555	0	CHAT	I've been meaning to ask you about that monkey.	GOSSIP	6554
6556	0	CHAT	You couldn't handle a lone night elf priestess?	GOSSIP	6555
6557	0	CHAT	That's odd.	GOSSIP	6556
6558	0	CHAT	That's what I like to hear.	GOSSIP	6557
6559	0	CHAT	<Use the transcription device to gather a rubbing.>	GOSSIP	-1
6560	0	CHAT	<Use the transcription device to gather a rubbing.>	GOSSIP	-1
6561	0	CHAT	<Use the transcription device to gather a rubbing.>	GOSSIP	-1
6563	0	TAXI	I need a ride.	TAXIVENDOR	0
6565	0	CHAT	I would like to enter the secret code to receive my Murloc pet.	GOSSIP	0
6565	1	CHAT	I would like to enter the secret code to receive my Murloc costume.	GOSSIP	0
6565	2	CHAT	I would like to enter the secret code to receive my Big Blizzard Bear.	GOSSIP	0
6568	0	VENDOR	I want to browse your goods.	VENDOR	0
6575	0	CHAT	Tell me how to use the Blastenheimer 5000 Ultra Cannon.	GOSSIP	6574
6579	0	CHAT	<more>	GOSSIP	8848
6581	0	CHAT	What are these Tonk Control Consoles?	GOSSIP	7093
6581	1	CHAT	Tell me about the cannon.	GOSSIP	7095
6582	0	CHAT	What can I purchase?	GOSSIP	6577
6582	1	CHAT	What are Darkmoon Faire Prize Tickets and how do I get them?	GOSSIP	6578
6582	2	CHAT	What are Darkmoon Cards?	GOSSIP	6579
6582	3	CHAT	What other things can I do at the faire?	GOSSIP	6581
6586	0	CHAT	And what do you say?	GOSSIP	6585
6587	0	CHAT	What do they say?	GOSSIP	6586
6588	0	CHAT	How do you know?	GOSSIP	6587
6597	0	VENDOR	Redeem Battleground Marks for Honor.	VENDOR	0
6598	0	VENDOR	Redeem Battleground Marks for Honor.	VENDOR	0
6599	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6700
6602	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6702
6603	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6704
6604	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	0
6605	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6708
6606	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6710
6607	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6696
6608	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6712
6609	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6714
6610	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6716
6612	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6718
6613	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6720
6614	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6722
6615	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6724
6616	0	CHAT	What is an Alliance Commendation Signet?	GOSSIP	6726
6629	0	CHAT	Let's find out.	GOSSIP	0
6644	0	CHAT	Teleport me to the lair of the Twin Emperors, please.	GOSSIP	0
6644	1	CHAT	Please teleport me to the final chamber.	GOSSIP	0
6665	0	CHAT	What is the Ahn'Qiraj war effort?	GOSSIP	6671
6665	1	CHAT	How many metal bars have the Horde collected so far?	GOSSIP	6672
6665	2	CHAT	How many herbs have the Horde collected so far?	GOSSIP	6673
6665	3	CHAT	How many leather skins have the Horde collected so far?	GOSSIP	6674
6665	4	CHAT	How many bandages have the Horde collected so far?	GOSSIP	6675
6665	5	CHAT	How many cooked goods have the Horde collected so far?	GOSSIP	6676
6668	0	CHAT	<Take this book for the good of Azeroth!>	GOSSIP	-1
6669	0	CHAT	<Take this book for the good of Azeroth!>	GOSSIP	-1
6670	0	CHAT	<Take this book for the good of Azeroth!>	GOSSIP	-1
6671	0	CHAT	I want to ask you about something else.	GOSSIP	6665
6672	0	CHAT	I want to ask you about something else.	GOSSIP	6665
6673	0	CHAT	I want to ask you about something else.	GOSSIP	6665
6674	0	CHAT	I want to ask you about something else.	GOSSIP	6665
6675	0	CHAT	I want to ask you about something else.	GOSSIP	6665
6676	0	CHAT	I want to ask you about something else.	GOSSIP	6665
6690	0	CHAT	May I have your report?	GOSSIP	-1
6691	0	CHAT	May I have your report?	GOSSIP	-1
6692	0	CHAT	May I have your report?	GOSSIP	-1
6696	0	CHAT	I want to ask you about something else.	GOSSIP	6607
6700	0	CHAT	I want to ask you about something else.	GOSSIP	6599
6702	0	CHAT	I want to ask you about something else.	GOSSIP	6602
6704	0	CHAT	I want to ask you about something else.	GOSSIP	6603
6708	0	CHAT	I want to ask you about something else.	GOSSIP	6605
6710	0	CHAT	I want to ask you about something else.	GOSSIP	6606
6712	0	CHAT	I want to ask you about something else.	GOSSIP	6608
6714	0	CHAT	I want to ask you about something else.	GOSSIP	6609
6716	0	CHAT	I want to ask you about something else.	GOSSIP	6610
6718	0	CHAT	I want to ask you about something else.	GOSSIP	0
6720	0	CHAT	I want to ask you about something else.	GOSSIP	6613
6722	0	CHAT	I want to ask you about something else.	GOSSIP	6614
6724	0	CHAT	I want to ask you about something else.	GOSSIP	6615
6726	0	CHAT	I want to ask you about something else.	GOSSIP	6616
6763	0	CHAT	Sprinkle some of the reindeer dust onto Metzen.	GOSSIP	6761
6768	0	VENDOR	Let me browse your seasonal fare.	VENDOR	0
6769	0	VENDOR	Let me browse your seasonal fare.	VENDOR	0
6771	0	CHAT	I want to ask you about something else.	GOSSIP	6772
6772	0	CHAT	What is the Ahn'Qiraj war effort?	GOSSIP	6771
6772	1	CHAT	How many metal bars have the Alliance collected so far?	GOSSIP	6773
6772	2	CHAT	How many herbs have the Alliance collected so far?	GOSSIP	6774
6772	3	CHAT	How many leather skins have the Alliance collected so far?	GOSSIP	6775
6772	4	CHAT	How many bandages have the Alliance collected so far?	GOSSIP	6776
6772	5	CHAT	How many cooked goods have the Alliance collected so far?	GOSSIP	6777
6773	0	CHAT	I want to ask you about something else.	GOSSIP	6772
6774	0	CHAT	I want to ask you about something else.	GOSSIP	6772
6775	0	CHAT	I want to ask you about something else.	GOSSIP	6772
6776	0	CHAT	I want to ask you about something else.	GOSSIP	6772
6777	0	CHAT	I want to ask you about something else.	GOSSIP	6772
6791	0	CHAT	I'd like to stable my pet here	STABLEPET	0
6814	1	CHAT	Where is Elder High Mountain?	GOSSIP	50077
6814	2	CHAT	Where is Elder Moonwarden?	GOSSIP	50087
6814	3	CHAT	Where is Elder Ezra Wheathoof?	GOSSIP	6895
6814	4	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6815	1	CHAT	Where is Elder Darkhorn?	GOSSIP	6896
6815	2	CHAT	Where is Elder High Mountain?	GOSSIP	50077
6815	3	CHAT	Where is Elder Moonwarden?	GOSSIP	50087
6815	4	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6816	1	CHAT	Where is Elder Darkcore?	GOSSIP	50066
6816	2	CHAT	Where is Elder Meadowrun?	GOSSIP	50084
6816	3	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6816	4	CHAT	Where is Elder Obsidian?	GOSSIP	50095
6816	5	CHAT	Where is Elder Snowcrown?	GOSSIP	50110
6817	1	CHAT	Where is Elder Bloodhoof?	GOSSIP	50061
6817	2	CHAT	Where is Elder High Mountain?	GOSSIP	50077
6817	3	CHAT	Where is Elder Morningdew?	GOSSIP	50089
6817	4	CHAT	Where is Elder Runetotem?	GOSSIP	50132
6817	5	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6818	1	CHAT	Where is Elder Bloodhoof?	GOSSIP	50061
6818	2	CHAT	Where is Elder Moonwarden?	GOSSIP	50087
6818	3	CHAT	Where is Elder Morningdew?	GOSSIP	50089
6818	4	CHAT	Where is Elder Runetotem?	GOSSIP	50132
6818	5	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6819	1	CHAT	Where is Elder Graveborn?	GOSSIP	6842
6819	2	CHAT	Where is Elder Highpeak?	GOSSIP	50078
6819	3	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6820	1	CHAT	Where is Elder Dreamseer?	GOSSIP	50069
6820	2	CHAT	Where is Elder Morningdew?	GOSSIP	50089
6820	3	CHAT	Where is Elder Ragetotem?	GOSSIP	50099
6820	4	CHAT	Where is Elder Wildmane?	GOSSIP	50125
6821	4	CHAT	Where is Elder Starsong?	GOSSIP	6867
6821	3	CHAT	Where is Elder Skychaser?	GOSSIP	50106
6821	2	CHAT	Where is Elder Rumblerock?	GOSSIP	6865
6821	1	CHAT	Where is Elder Hammershout?	GOSSIP	6873
6822	1	CHAT	Where is Elder Bladeswift?	GOSSIP	6876
6822	2	CHAT	Where is Elder Skygleam?	GOSSIP	6877
6823	3	CHAT	Where is Elder Silvervein?	GOSSIP	50105
6823	2	CHAT	Where is Elder Ironband?	GOSSIP	6854
6823	1	CHAT	Where is Elder Bronzebeard?	GOSSIP	6858
6824	0	CHAT	Where is Elder Ironband?	GOSSIP	6854
6825	3	CHAT	Where is Elder Winterhoof?	GOSSIP	50128
6825	2	CHAT	Where is Elder Stormbrow?	GOSSIP	6868
6825	1	CHAT	Where is Elder Starsong?	GOSSIP	6867
6826	3	CHAT	Where is Elder Riversong?	GOSSIP	50130
6826	2	CHAT	Where is Elder Nightwind?	GOSSIP	50092
6826	1	CHAT	Where is Elder Bladeswift?	GOSSIP	6876
6827	2	CHAT	Where is Elder Skygleam?	GOSSIP	6877
6827	1	CHAT	Where is Elder Nightwind?	GOSSIP	50092
6827	3	CHAT	Where is Elder Starweave?	GOSSIP	6879
6827	4	CHAT	Where is Elder Stonespire?	GOSSIP	50117
6828	1	CHAT	Where is Elder Bloodhoof?	GOSSIP	50061
6828	2	CHAT	Where is Elder Darkhorn?	GOSSIP	6896
6828	3	CHAT	Where is Elder High Mountain?	GOSSIP	50077
6828	4	CHAT	Where is Elder Moonwarden?	GOSSIP	50087
6828	5	CHAT	Where is Elder Morningdew?	GOSSIP	50089
6828	6	CHAT	Where is Elder Ezra Wheathoof?	GOSSIP	6895
6828	7	CHAT	Where is Elder Runetotem?	GOSSIP	50132
6829	1	CHAT	Where is Elder Rumblerock?	GOSSIP	6865
6829	2	CHAT	Where is Elder Skychaser?	GOSSIP	50106
6829	3	CHAT	Where is Elder Starglade?	GOSSIP	50112
6829	4	CHAT	Where is Elder Starsong?	GOSSIP	6867
6830	1	CHAT	Where is Elder Grimtotem?	GOSSIP	50075
6830	2	CHAT	Where is Elder High Mountain?	GOSSIP	50077
6830	3	CHAT	Where is Elder Mistwalker?	GOSSIP	50085
6830	4	CHAT	Where is Elder Moonwarden?	GOSSIP	50087
6830	5	CHAT	Where is Elder Skyseer?	GOSSIP	50108
6830	6	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6831	1	CHAT	Where is Elder Ragetotem?	GOSSIP	50099
6831	2	CHAT	Where is Elder Skyseer?	GOSSIP	50108
6831	3	CHAT	Where is Elder Thunderhorn?	GOSSIP	50121
6831	4	CHAT	Where is Elder Wildmane?	GOSSIP	50125
6832	1	CHAT	Where is Elder Darkhorn?	GOSSIP	6896
6832	2	CHAT	Where is Elder Graveborn?	GOSSIP	6842
6832	3	CHAT	Where is Elder Ironband?	GOSSIP	6854
6832	4	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6832	5	CHAT	Where is Elder Ezra Wheathoof?	GOSSIP	6895
6833	1	CHAT	Where is Elder Bladeswift?	GOSSIP	6876
6833	2	CHAT	Where is Elder Bronzebeard?	GOSSIP	6858
6833	3	CHAT	Where is Elder Rumblerock?	GOSSIP	6865
6833	4	CHAT	Where is Elder Stormbrow?	GOSSIP	6868
6834	1	CHAT	Where is Elder Graveborn?	GOSSIP	6842
6834	2	CHAT	Where is Elder Farwhisper?	GOSSIP	50071
6834	3	CHAT	Where is Elder Meadowrun?	GOSSIP	50084
6834	4	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6834	5	CHAT	Where is Elder Windrun?	GOSSIP	50126
6835	1	CHAT	Where is Elder Primestone?	GOSSIP	50098
6835	2	CHAT	Where is Elder Thunderhorn?	GOSSIP	50121
6841	1	CHAT	Where is Elder Bladeswift?	GOSSIP	6876
6841	2	CHAT	Where is Elder Hammershout?	GOSSIP	6873
6841	3	CHAT	Where is Elder Goldwell?	GOSSIP	50072
6841	4	CHAT	Where is Elder Ironband?	GOSSIP	6854
6848	0	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6849	1	CHAT	Where is Elder Darkcore?	GOSSIP	50066
6849	2	CHAT	Where is Elder Graveborn?	GOSSIP	6842
6849	3	CHAT	Where is Elder Highpeak?	GOSSIP	50078
6849	4	CHAT	Where is Elder Meadowrun?	GOSSIP	50084
6849	5	CHAT	Where is Elder Obsidian?	GOSSIP	50095
6849	6	CHAT	Where is Elder Snowcrown?	GOSSIP	50110
6849	7	CHAT	Where is Elder Windrun?	GOSSIP	50126
6852	1	CHAT	Where is Elder Farwhisper?	GOSSIP	50071
6852	2	CHAT	Where is Elder Meadowrun?	GOSSIP	50084
6852	3	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6852	4	CHAT	Where is Elder Snowcrown?	GOSSIP	50110
6853	1	CHAT	Where is Elder Snowcrown?	GOSSIP	50110
6853	2	CHAT	Where is Elder Windrun?	GOSSIP	50126
6855	0	CHAT	Where is Elder Ironband?	GOSSIP	6854
6856	1	CHAT	Where is Elder Goldwell?	GOSSIP	50072
6856	2	CHAT	Where is Elder Ironband?	GOSSIP	6854
6861	1	CHAT	Where is Elder Bronzebeard?	GOSSIP	6858
6861	2	CHAT	Where is Elder Goldwell?	GOSSIP	50072
6861	3	CHAT	Where is Elder Morndeep?	GOSSIP	50088
6861	4	CHAT	Where is Elder Silvervein?	GOSSIP	50105
6861	5	CHAT	Where is Elder Stonefort?	GOSSIP	50116
6864	0	CHAT	Where is Elder Rumblerock?	GOSSIP	6865
6866	0	CHAT	Where is Elder Starsong?	GOSSIP	6867
6872	1	CHAT	Where is Elder Dawnstrider?	GOSSIP	50068
6872	2	CHAT	Where is Elder Hammershout?	GOSSIP	6873
6872	3	CHAT	Where is Elder Stormbrow?	GOSSIP	6868
6872	4	CHAT	Where is Elder Winterhoof?	GOSSIP	50128
6874	1	CHAT	Where is Elder Bellowrage?	GOSSIP	50057
6874	2	CHAT	Where is Elder Starglade?	GOSSIP	50112
6874	3	CHAT	Where is Elder Skychaser?	GOSSIP	50106
6874	4	CHAT	Where is Elder Stormbrow?	GOSSIP	6868
6874	5	CHAT	Where is Elder Winterhoof?	GOSSIP	50128
6880	1	CHAT	Where is Elder Bladeleaf?	GOSSIP	6878
6880	2	CHAT	Where is Elder Bronzebeard?	GOSSIP	6858
6880	3	CHAT	Where is Elder Hammershout?	GOSSIP	6873
6880	4	CHAT	Where is Elder Skygleam?	GOSSIP	6877
6880	5	CHAT	Where is Elder Starweave?	GOSSIP	6879
6885	1	CHAT	Where is Elder Brightspear?	GOSSIP	50063
6885	2	CHAT	Where is Elder Nightwind?	GOSSIP	50092
6885	3	CHAT	Where is Elder Riversong?	GOSSIP	50130
6887	1	CHAT	Where is Elder Brightspear?	GOSSIP	50063
6887	2	CHAT	Where is Elder Riversong?	GOSSIP	50130
6887	3	CHAT	Where is Elder Skygleam?	GOSSIP	6877
6887	4	CHAT	Where is Elder Starweave?	GOSSIP	6879
6887	5	CHAT	Where is Elder Stonespire?	GOSSIP	50117
6888	1	CHAT	Where is Elder Nightwind?	GOSSIP	50092
6888	2	CHAT	Where is Elder Stonespire?	GOSSIP	50117
6889	1	CHAT	Where is Elder Bladeleaf?	GOSSIP	6878
6889	2	CHAT	Where is Elder Bladeswift?	GOSSIP	6876
6889	3	CHAT	Where is Elder Nightwind?	GOSSIP	50092
6889	4	CHAT	Where is Elder Riversong?	GOSSIP	50130
6890	1	CHAT	Where is Elder Bloodhoof?	GOSSIP	50061
6890	2	CHAT	Where is Elder Darkcore?	GOSSIP	50066
6890	3	CHAT	Where is Elder Darkhorn?	GOSSIP	6896
6890	4	CHAT	Where is Elder Ironband?	GOSSIP	6854
6890	5	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6899	1	CHAT	Where is Elder Darkcore?	GOSSIP	50066
6899	2	CHAT	Where is Elder Ironband?	GOSSIP	6854
6899	3	CHAT	Where is Elder Ezra Wheathoof?	GOSSIP	6895
6899	4	CHAT	Where is Elder Runetotem?	GOSSIP	50132
6899	5	CHAT	Where is Elder Windtotem?	GOSSIP	50127
6903	1	CHAT	Where is Elder Grimtotem?	GOSSIP	50075
6903	2	CHAT	Where is Elder Morningdew?	GOSSIP	50089
6903	3	CHAT	Where is Elder Splitrock?	GOSSIP	50111
6905	1	CHAT	Where is Elder Mistwalker?	GOSSIP	50085
6905	2	CHAT	Where is Elder Morningdew?	GOSSIP	50089
6905	3	CHAT	Where is Elder Splitrock?	GOSSIP	50111
6906	1	CHAT	Where is Elder Grimtotem?	GOSSIP	50075
6906	2	CHAT	Where is Elder Mistwalker?	GOSSIP	50085
6911	1	CHAT	Where is Elder Dreamseer?	GOSSIP	50069
6911	2	CHAT	Where is Elder Skyseer?	GOSSIP	50108
6911	3	CHAT	Where is Elder Thunderhorn?	GOSSIP	50121
6911	4	CHAT	Where is Elder Wildmane?	GOSSIP	50125
6912	1	CHAT	Where is Elder Dreamseer?	GOSSIP	50069
6912	2	CHAT	Where is Elder Ragetotem?	GOSSIP	50099
6912	3	CHAT	Where is Elder Skyseer?	GOSSIP	50108
6912	4	CHAT	Where is Elder Thunderhorn?	GOSSIP	50121
6914	1	CHAT	Where is Elder Bladesing?	GOSSIP	50059
6914	2	CHAT	Where is Elder Dreamseer?	GOSSIP	50069
6914	3	CHAT	Where is Elder Primestone?	GOSSIP	50098
6914	4	CHAT	Where is Elder Ragetotem?	GOSSIP	50099
6914	5	CHAT	Where is Elder Wildmane?	GOSSIP	50125
6916	1	CHAT	Where is Elder Bladesing?	GOSSIP	50059
6916	2	CHAT	Where is Elder Thunderhorn?	GOSSIP	50121
6917	0	CHAT	How can I summon Omen?	GOSSIP	6936
6917	2	VENDOR	I want to browse your goods.	VENDOR	0
6917	3	CHAT	Farewell.	GOSSIP	-1
6918	0	CHAT	I'd like a new invitation to the Lunar Festival.	GOSSIP	-1
6919	1	CHAT	Where is Elder Graveborn?	GOSSIP	6842
6919	2	CHAT	Where is Elder Moonstrike?	GOSSIP	6843
6919	3	CHAT	Where is Elder Snowcrown?	GOSSIP	50110
6919	4	CHAT	Where is Elder Windrun?	GOSSIP	50126
6921	1	CHAT	Where is Elder Starsong?	GOSSIP	6867
6921	2	CHAT	Where is Elder Winterhoof?	GOSSIP	50128
6924	0	VENDOR	I want to browse your goods.	VENDOR	0
6924	1	CHAT	Good luck.	GOSSIP	-1
6928	0	CHAT	I have lost my Band of Unending Life. Are you able to replace it for me?	GOSSIP	-1
6928	1	CHAT	I have lost my Band of Vaulted Secrets. Are you able to replace it for me?	GOSSIP	-1
6928	2	CHAT	I have lost my Band of Veiled Shadows. Are you able to replace it for me?	GOSSIP	-1
6928	3	CHAT	I have lost my Ring of Eternal Justice. Are you able to replace it for me?	GOSSIP	-1
6928	4	CHAT	I have lost my Ring of Infinite Wisdom. Are you able to replace it for me?	GOSSIP	-1
6928	5	CHAT	I have lost my Ring of the Gathering Storm. Are you able to replace it for me?	GOSSIP	-1
6928	6	CHAT	I have lost my Ring of Unspoken Names. Are you able to replace it for me?	GOSSIP	-1
6928	7	CHAT	I have lost my Signet of the Unseen Path. Are you able to replace it for me?	GOSSIP	-1
6928	8	CHAT	I have lost my Signet of Unyielding Strength. Are you able to replace it for me?	GOSSIP	-1
6944	0	TAXI	Show me where I can fly.	TAXIVENDOR	0
6944	1	CHAT	GOSSIP_OPTION_QUESTGIVER	QUESTGIVER	0
6954	0	VENDOR	I want to browse your goods.	VENDOR	0
6954	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6955	0	TRAINER	I'd like some weapon training	TRAINER	0
6955	1	CHAT	What can other weapon masters teach?	GOSSIP	0
6957	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6957	1	CHAT	Auction House	GOSSIP	0
6957	2	CHAT	Bank of Stormwind	GOSSIP	0
6957	3	CHAT	Deeprun Tram	GOSSIP	0
6957	4	CHAT	The inn	GOSSIP	0
6957	5	CHAT	Gryphon Master	GOSSIP	0
6957	6	CHAT	Guild Master	GOSSIP	0
6957	7	CHAT	Mailbox	GOSSIP	0
6957	8	CHAT	Stable Master	GOSSIP	0
6957	9	CHAT	Weapons Trainer	GOSSIP	0
6957	10	CHAT	Officers' Lounge	GOSSIP	0
6957	11	CHAT	Battlemaster	GOSSIP	0
6957	13	CHAT	Lexicon of Power	GOSSIP	0
6957	14	CHAT	Class Trainer	GOSSIP	0
6957	15	CHAT	Profession Trainer	GOSSIP	0
6958	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6958	1	CHAT	Auction House	GOSSIP	0
6958	2	CHAT	Bank of Stormwind	GOSSIP	0
6958	3	CHAT	Deeprun Tram	GOSSIP	0
6958	4	CHAT	The inn	GOSSIP	0
6958	5	CHAT	Gryphon Master	GOSSIP	0
6958	6	CHAT	Guild Master	GOSSIP	0
6958	7	CHAT	Mailbox	GOSSIP	0
6958	8	CHAT	Stable Master	GOSSIP	0
6958	9	CHAT	Weapons Trainer	GOSSIP	0
6958	10	CHAT	Officers' Lounge	GOSSIP	0
6958	11	CHAT	Battlemaster	GOSSIP	0
6958	13	CHAT	Lexicon of Power	GOSSIP	0
6958	14	CHAT	Class Trainer	GOSSIP	0
6958	15	CHAT	Profession Trainer	GOSSIP	0
6959	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6964	0	TRAINER	Train me.	TRAINER	0
6976	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6979	0	VENDOR	I want to browse your goods.	VENDOR	0
6981	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6984	2	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6986	2	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6990	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6994	0	VENDOR	I want to browse your goods.	VENDOR	0
6994	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6997	2	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6999	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
6999	1	CHAT	Auction House	GOSSIP	0
6999	2	CHAT	The bank	GOSSIP	0
6999	3	CHAT	Hippogryph Master	GOSSIP	0
6999	4	CHAT	Guild Master	GOSSIP	0
6999	5	CHAT	The inn	GOSSIP	0
6999	6	CHAT	Mailbox	GOSSIP	0
6999	7	CHAT	Stable Master	GOSSIP	0
6999	8	CHAT	Weapons Trainer	GOSSIP	0
6999	9	CHAT	Battlemaster	GOSSIP	0
6999	10	CHAT	Class Trainer	GOSSIP	0
6999	11	CHAT	Profession Trainer	GOSSIP	0
6999	12	CHAT	Lexicon of Power	GOSSIP	0
7000	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
7002	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
7003	2	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
7034	0	CHAT	I would like to enter the secret code to receive my Murloc pet.	GOSSIP	0
7035	0	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
7035	1	CHAT	Auction House	GOSSIP	0
7035	2	CHAT	Bank of Ironforge	GOSSIP	0
7035	3	CHAT	Deeprun Tram	GOSSIP	0
7035	4	CHAT	Gryphon Master	GOSSIP	0
7035	5	CHAT	Guild Master	GOSSIP	0
7035	6	CHAT	The inn	GOSSIP	0
7035	7	CHAT	Mailbox	GOSSIP	0
7035	8	CHAT	Stable Master	GOSSIP	0
7035	9	CHAT	Weapons Trainer	GOSSIP	0
7035	10	CHAT	Battlemaster	GOSSIP	0
7035	12	CHAT	Class Trainer	GOSSIP	0
7035	13	CHAT	Profession Trainer	GOSSIP	0
7035	14	CHAT	Lexicon of Power	GOSSIP	0
7046	0	VENDOR	Hey Vi'el, show me your wares!	VENDOR	0
7047	0	VENDOR	Let's see what you have.	VENDOR	0
7049	0	CHAT	You're selling cologne and perfume?	GOSSIP	7051
7049	1	CHAT	What are love tokens?	GOSSIP	7050
7049	2	CHAT	If I make a gift collection, what do I do with it?	GOSSIP	7056
7050	0	CHAT	What can I do with these gifts?	GOSSIP	7056
7050	2	CHAT	You're selling cologne and perfume?	GOSSIP	7051
7051	0	CHAT	What can I do with these gifts?	GOSSIP	7056
7051	2	CHAT	What are love tokens?	GOSSIP	7050
7054	0	CHAT	How are the gift standings?  Who's the most popular?	GOSSIP	7053
7056	0	CHAT	You're selling cologne and perfume?	GOSSIP	7051
7056	1	CHAT	What are love tokens?	GOSSIP	7050
7078	0	VENDOR	I want to browse your goods.	VENDOR	0
7078	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
7080	0	VENDOR	I want to browse your goods.	VENDOR	0
7080	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
7081	0	VENDOR	I want to browse your goods.	VENDOR	0
7096	0	CHAT	What is Atiesh?	GOSSIP	7135
7096	1	CHAT	Where can I find core of elements?	GOSSIP	7150
7099	1	CHAT	Korfax, where can I find Dark Iron scraps?	GOSSIP	7151
7101	1	CHAT	Where can I find bone fragments?	GOSSIP	7145
7102	1	CHAT	Where can I find crypt fiend parts, Leopold?	GOSSIP	7144
7104	1	CHAT	Rayne, where should I look for savage fronds?	GOSSIP	7152
7127	0	CHAT	Is there anything else?	GOSSIP	7126
7128	0	CHAT	Please, tell me more.	GOSSIP	7127
7129	0	CHAT	This is disturbing. Please continue.	GOSSIP	7128
7130	0	CHAT	What?	GOSSIP	7129
7131	0	CHAT	Please continue.	GOSSIP	7130
7132	0	CHAT	Please continue.	GOSSIP	7131
7133	0	CHAT	What corruption?	GOSSIP	7132
7134	0	CHAT	Please continue.	GOSSIP	7133
7135	0	CHAT	What Guardian? I don't understand any of this.	GOSSIP	7134
7146	0	VENDOR	Let me browse your goods.	VENDOR	0
7173	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
7173	3	CHAT	What can I do at an inn?	GOSSIP	1221
7173	4	VENDOR	Let me browse your goods.	VENDOR	0
7173	0	CHAT	Trick or Treat!	GOSSIP	-1
7208	0	CHAT	Friendly	GOSSIP	7213
7208	1	CHAT	Honored	GOSSIP	7209
7208	2	CHAT	Revered	GOSSIP	7210
7208	3	CHAT	Exalted	GOSSIP	7212
7219	0	VENDOR	Show me your wares, Wilhelm.	VENDOR	0
7379	0	CHAT	Take me to Northpass Tower.	GOSSIP	0
7379	1	CHAT	Take me to Eastwall Tower.	GOSSIP	0
7379	2	CHAT	Take me to Crown Guard Tower.	GOSSIP	0
7396	0	VENDOR	I want to browse your goods.	VENDOR	0
7401	0	CHAT	We have much in common, night elf. I can't help but feel that perhaps it was fate that brought us together. Let me help you, Cowlen. Let my people help. We will right the wrongs. This I vow.	GOSSIP	7403
7402	0	CHAT	I fear that my people are somewhat responsible for this destruction. We are refugees, displaced from our homes by the Burning Legion. This tragedy is a result of our latest evacuation. Our vessel crashed - this debris is a part of that vessel.	GOSSIP	7401
7403	0	CHAT	I have not come to kill you, night elf. And the gods did not do this...	GOSSIP	7402
7446	0	VENDOR	I want to browse your goods.	VENDOR	0
7459	0	TRAINER	Train me in the ways of herbalism.	TRAINER	0
7475	0	CHAT	So why are you still here?	GOSSIP	7474
7476	0	CHAT	Until what?	GOSSIP	7475
7477	0	CHAT	What is Ysera and how were you blessed?	GOSSIP	7476
7478	0	CHAT	Why do you suffer?	GOSSIP	7477
7487	0	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
7487	1	TALK	How do I form a guild?	PETITIONER	0
7524	0	VENDOR	I want to browse your goods.	VENDOR	0
7611	0	VENDOR	I would like to buy from you.	VENDOR	0
7628	0	VENDOR	I would like to buy from you.	VENDOR	0
7690	0	TRAINER	Train me.	TRAINER	0
7759	0	CHAT	What are you doing there?	GOSSIP	7758
7810	0	TRAINER	I would like to train.	TRAINER	0
7810	1	VENDOR	Let me browse your goods.	VENDOR	0
7811	0	MONEY_BAG	I would like to check my deposit box.	BANKER	0
7816	0	TRAINER	I would like to train.	TRAINER	0
7816	1	VENDOR	Let me browse your goods.	VENDOR	0
7817	0	TRAINER	I would like to train.	TRAINER	0
7817	1	VENDOR	Let me browse your goods.	VENDOR	0
7818	0	TRAINER	I would like to train.	TRAINER	0
7818	1	VENDOR	Let me browse your goods.	VENDOR	0
7820	0	TRAINER	I would like to train.	TRAINER	0
7820	1	VENDOR	I want to browse your goods.	VENDOR	0
7842	0	TRAINER	Train me.	TRAINER	0
7849	0	CHAT	Strange wizard?	GOSSIP	0
7866	0	CHAT	Who is Talon King Ikiss?	GOSSIP	7876
7866	1	CHAT	Who are the Sethekk?	GOSSIP	7874
7866	3	CHAT	Who is this Terokk you keep mentioning?	GOSSIP	7877
7866	2	CHAT	Where can I find the relics of Terokk?	GOSSIP	0
7868	0	CHAT	I'll have you out of there in just a moment.	GOSSIP	7866
7879	0	TRAINER	I would like to train.	TRAINER	0
7879	1	VENDOR	Let me browse your goods.	VENDOR	0
7883	0	VENDOR	I want to browse your goods.	VENDOR	0
7884	0	VENDOR	I want to browse your goods.	VENDOR	0
7888	0	VENDOR	What do you have for sale?	VENDOR	0
7890	0	VENDOR	What do you have for sale?	VENDOR	0
7900	0	VENDOR	Let me browse your goods.	VENDOR	0
7937	0	VENDOR	I would like to buy from you.	VENDOR	0
7952	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
7952	2	VENDOR	Let me browse your goods.	VENDOR	0
7957	0	VENDOR	What do you have for sale?	VENDOR	0
7984	0	CHAT	Read on, if you dare...	GOSSIP	7985
7985	0	CHAT	Read on, if you dare...	GOSSIP	7986
7986	0	CHAT	Read on, if you dare...	GOSSIP	7987
7987	0	CHAT	Read on, if you dare...	GOSSIP	7988
7988	0	CHAT	Read on, if you dare...	GOSSIP	7989
7989	0	CHAT	Read on, if you dare...	GOSSIP	7990
8002	0	VENDOR	I wish to browse your wares.	VENDOR	0
8058	0	VENDOR	I need some reagents and poisons, lady.	VENDOR	0
8077	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
8094	0	VENDOR	What do you have for sale?	VENDOR	0
8227	0	VENDOR	Alright, muffin man, show me your muffins!	VENDOR	0
8243	0	VENDOR	I want to browse your goods.	VENDOR	0
8249	0	VENDOR	I want to browse your goods.	VENDOR	0
8382	0	TRAINER	Train me.	TRAINER	0
8387	0	VENDOR	I wish to browse your wares.	VENDOR	0
7222	0	CHAT	What happened to the staff?	GOSSIP	7233
7224	0	CHAT	What staff?	GOSSIP	7223
7225	0	CHAT	You are talking nonsense, mage. 	GOSSIP	7224
8453	0	BATTLE	I would like to go to the battleground.	BATTLEFIELD	0
8460	0	TRAINER	Tell me more about this thing you call \\"cooking?\\"	TRAINER	0
8462	0	BATTLE	I wish to join the battle!	BATTLEFIELD	0
8494	1	TALK	How do I form an arena team?	PETITIONER	0
8519	0	TRAINER	Train me.	TRAINER	0
8522	0	TRAINER	Train me.	TRAINER	0
8530	0	VENDOR	Show me what you have for sale.	VENDOR	0
8531	0	VENDOR	Show me what you have for sale.	VENDOR	0
8540	0	TRAINER	I would like to train.	TRAINER	0
8545	0	VENDOR	I won't challenge you, but I'd like to see your wares.	VENDOR	0
8560	0	TAXI	Show me where I can fly.	TAXIVENDOR	0
8622	0	TRAINER	I seek training to ride a steed.	TRAINER	0
8629	0	VENDOR	Let me see the wyverns, Dama.	VENDOR	0
8648	0	VENDOR	What do you have for sale?	VENDOR	0
8662	0	CHAT	Let's go!	GOSSIP	0
8760	1	VENDOR	Let me browse your goods.	VENDOR	0
8760	3	TRAINER	Train me	TRAINER	0
8763	0	CHAT	Who is the Headless Horseman?	GOSSIP	8880
3667	0	CHAT	With all due respect, Warchief - why not allow them to be destroyed? Does this not strengthen our position?	GOSSIP	3668
3666	0	CHAT	Usurper?	GOSSIP	3667
8770	0	VENDOR	I want to browse your goods.	VENDOR	0
8771	0	VENDOR	I want to browse your goods.	VENDOR	0
8772	0	VENDOR	I want to browse your goods.	VENDOR	0
8784	0	VENDOR	I'd like a drink.	VENDOR	0
8784	1	CHAT	I hear you're quite the cook.	GOSSIP	8785
8785	0	TRAINER	I'd love to learn more.	TRAINER	0
3665	0	CHAT	What discoveries?	GOSSIP	3666
3664	0	CHAT	Please share your wisdom with me, Warchief.	GOSSIP	3665
8802	0	TRAINER	I would like to train.	TRAINER	0
8803	0	VENDOR	I need some booze, Coot.	VENDOR	0
8820	0	VENDOR	Finlay, let me see what you have for sale.	VENDOR	0
8826	0	VENDOR	Show me what you have for sale.	VENDOR	0
8868	0	TRAINER	Train me.	TRAINER	0
8884	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
8884	3	VENDOR	Let me browse your goods.	VENDOR	0
8886	0	CHAT	Sergeant, loan me your spyglass.	GOSSIP	0
8934	0	CHAT	Do you still need some help shipping kegs from Kharanos?	GOSSIP	0
8953	0	CHAT	I'm ready to work for you today!  Give me the good stuff!	GOSSIP	0
8954	0	CHAT	Sir, I need another flying machine...	GOSSIP	0
8955	0	CHAT	I have another question.	GOSSIP	0
8958	1	CHAT	Do I get a free mount?	GOSSIP	0
8958	2	CHAT	How do I make my ram go faster?	GOSSIP	0
8958	3	CHAT	What's with the different speeds?	GOSSIP	0
8958	4	CHAT	Can I tire my ram out?	GOSSIP	0
8958	5	CHAT	That all sounds very complicated...	GOSSIP	0
8958	6	CHAT	Say, you wouldn't happen to have an extra set of reins...	GOSSIP	0
8959	2	CHAT	I have another question.	GOSSIP	0
8960	0	CHAT	Say, you wouldn't happen to have an extra set of reins...	GOSSIP	0
8960	1	CHAT	I have another question.	GOSSIP	0
8961	0	CHAT	I have another question.	GOSSIP	0
8962	0	CHAT	I have another question.	GOSSIP	0
8963	0	CHAT	I have another question.	GOSSIP	0
8967	0	CHAT	I have another question.	GOSSIP	0
8971	0	VENDOR	I want to browse your goods.	VENDOR	0
8972	0	VENDOR	I want to browse your goods.	VENDOR	0
8982	0	CHAT	Um... what was that?	GOSSIP	8983
9006	0	CHAT	What if I don't like drinking...  Is there another way I can help out?	GOSSIP	10604
9014	0	CHAT	Here's a gold, buy yourself something nice.	GOSSIP	-1
9015	0	CHAT	I'd like to buy Jack a drink.  Perhaps something... extra strong.	GOSSIP	9014
9023	0	CHAT	Yarp.	GOSSIP	0
9046	7	CHAT	What do you know about the magical gates at the Sunwell Plateau being brought down?	GOSSIP	9307
9123	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
9123	3	VENDOR	I want to browse your goods.	VENDOR	0
9131	0	TRAINER	Train me.	TRAINER	0
9131	1	CHAT	I wish to unlearn Armorsmithing!	GOSSIP	0
9132	0	TRAINER	Train me.	TRAINER	0
9132	1	CHAT	I wish to unlearn Armorsmithing!	GOSSIP	0
9171	0	CHAT	Tell me what's going on out here, Fizzcrank.	GOSSIP	9174
9171	1	CHAT	Tell me your story again, Fizzcrank.	GOSSIP	9174
9174	0	CHAT	Go on.	GOSSIP	9175
9175	0	CHAT	Go on.	GOSSIP	9176
9175	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9174
9176	0	CHAT	Go on.	GOSSIP	9177
9176	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9175
9177	0	CHAT	Go on.	GOSSIP	9178
9177	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9176
9178	0	CHAT	Go on.	GOSSIP	9179
9178	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9177
9179	0	CHAT	Go on.	GOSSIP	9180
9179	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9178
9180	0	CHAT	Go on.	GOSSIP	9181
9180	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9179
9181	0	CHAT	Go on.	GOSSIP	9182
9181	1	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9180
9182	0	CHAT	Wait, back up. What was that last thing you said?	GOSSIP	9181
9217	0	CHAT	What do you know about the Cult of the Damned?	GOSSIP	0
9218	0	CHAT	I have reason to believe you're involved in cultist activity.	GOSSIP	0
9218	1	VENDOR	Let me browse your goods.	VENDOR	0
9219	0	CHAT	How long have you worked for the Cult of the Damned?	GOSSIP	0
9245	0	INTERACT_2	Make this inn your home.	INNKEEPER	0
9245	1	VENDOR	Let me browse your goods.	VENDOR	0
9245	2	CHAT	Trick or Treat!	GOSSIP	0
9253	0	CHAT	What is the cause of this conflict?	GOSSIP	9283
9283	0	CHAT	Who is Malygos?	GOSSIP	9284
9299	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
9299	3	VENDOR	I wish to buy from you.	VENDOR	0
9307	0	CHAT	I have something else to ask you about.	GOSSIP	9046
9427	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
9427	3	VENDOR	Let me browse your goods.	VENDOR	0
9453	0	VENDOR	Let me browse your goods.	VENDOR	0
9476	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
9476	2	VENDOR	I want to browse your goods.	VENDOR	0
9478	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
9478	3	VENDOR	Let me browse your goods.	VENDOR	0
9480	0	VENDOR	I would like to buy from you.	VENDOR	0
9492	0	CHAT	Use the outhouse.	GOSSIP	0
9495	0	VENDOR	Let me browse your goods.	VENDOR	0
9537	0	CHAT	One of the cultists seems to have stumbled onto my blade and died... can I have a new disguise? I promise that I will be more careful this time.	GOSSIP	9537
9541	0	CHAT	Sorry to have bothered you, friend. Carry on!	GOSSIP	0
9568	0	CHAT	We need to get into the fight. Are you ready?	GOSSIP	9569
9573	0	CHAT	What should we do next?	GOSSIP	9787
9573	3	CHAT	I want to exchange my Ruby Essence for Emerald Essence.	GOSSIP	9573
9573	4	CHAT	What abilities do Emerald Drakes have?	GOSSIP	9703
9573	5	CHAT	What is the ultimate ability of the Emerald Drake?	GOSSIP	0
9573	1	CHAT	I want to fly on the wings of the Green Flight.	GOSSIP	9725
9573	2	CHAT	I want to exchange my Amber Essence for Emerald Essence.	GOSSIP	0
9575	0	CHAT	I want to fly on the wings of the Red Flight.	GOSSIP	9575
9575	3	CHAT	What abilities do Ruby Drakes have?	GOSSIP	9699
9575	4	CHAT	What is the ultimate ability of the Ruby Drake?	GOSSIP	9700
9575	1	CHAT	I want to exchange my Amber Essence for Ruby Essence.	GOSSIP	0
9575	2	CHAT	I want to exchange my Emerald Essence for Ruby Essence.	GOSSIP	9573
9584	0	TAXI	Show me where I can fly.	TAXIVENDOR	0
9586	0	CHAT	Why have I been sent back to this particular place and time?	GOSSIP	0
9586	1	CHAT	Yes, please!	GOSSIP	0
9586	2	CHAT	Chromie, you and I both know what's going to happen in this time stream. We've seen this all before. Can you just skip us ahead to all the real action?	GOSSIP	0
9594	0	CHAT	What was this decision?	GOSSIP	0
9610	0	CHAT	What do you think they're up to?	GOSSIP	0
9632	0	VENDOR	Let me browse your goods.	VENDOR	0
9640	0	CHAT	Soldier, you have new orders. You're to pull back and report to the sergeant!	GOSSIP	0
9648	0	CHAT	May I help you taste?	GOSSIP	9652
9648	1	CHAT	Let's taste more!	GOSSIP	-1
9648	2	CHAT	Another drink!	GOSSIP	-1
9652	0	CHAT	Cheers!	GOSSIP	-1
9674	0	CHAT	You look safe enough... let's do this.	GOSSIP	0
9711	0	BATTLE	I wish to join the battle!	BATTLEFIELD	0
9714	0	CHAT	Stefan told me you would demonstrate the purpose of this item.	GOSSIP	0
9724	0	CHAT	Can you spare an orange?	GOSSIP	0
9724	1	CHAT	Have a spare bunch of bananas?	GOSSIP	0
9724	2	CHAT	I could really use a papaya.	GOSSIP	0
9733	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
9733	2	VENDOR	Let me browse your goods.	VENDOR	0
9733	0	CHAT	Trick or Treat!	GOSSIP	0
9750	0	TRAINER	Train me.	TRAINER	0
9763	1	INTERACT_2	Make this inn your home.	INNKEEPER	0
9763	2	VENDOR	Let me browse your goods.	VENDOR	0
9763	0	INTERACT_2	Make this inn your home.	INNKEEPER	0
9772	0	TRAINER	I'm here for cooking training.	TRAINER	0
9777	0	TRAINER	Please teach me.	TRAINER	0
9791	0	CHAT	I am certain. Please proceed.	GOSSIP	0
9798	0	VENDOR	I would like to buy from you.	VENDOR	0
9806	0	CHAT	Lord-Commander, I would hear your tale.	GOSSIP	9807
9807	0	CHAT	<You nod slightly but do not complete the motion as the lord-commander narrows his eyes before he continues.>	GOSSIP	9808
9808	0	CHAT	I thought that they now called themselves the Scarlet Onslaught?	GOSSIP	9809
9808	1	CHAT	Lord-Commander, would you repeat what you said before?	GOSSIP	9807
9809	0	CHAT	Where did the grand admiral go?	GOSSIP	9810
9809	1	CHAT	Lord-Commander, would you repeat what you said before?	GOSSIP	9808
9810	0	CHAT	That's fine. When do I start?	GOSSIP	9811
9810	1	CHAT	Lord-Commander, would you repeat what you said before?	GOSSIP	9809
9811	0	CHAT	Let's finish this!	GOSSIP	9812
9811	1	CHAT	Lord-Commander, would you repeat what you said before?	GOSSIP	9810
9812	0	CHAT	That's quite a tale, lord-commander.	GOSSIP	9806
9812	1	CHAT	Lord-Commander, would you repeat what you said before?	GOSSIP	9811
9821	1	CHAT	I'd like to stable my pet here	STABLEPET	0
9832	0	VENDOR	Let me browse your goods.	VENDOR	0
9833	0	TRAINER	Train me.	TRAINER	0
9833	1	VENDOR	I want to browse your goods.	VENDOR	0
9866	0	CHAT	Trick or Treat!	GOSSIP	-1
9866	2	INTERACT_2	Make this inn your home.	INNKEEPER	0
9866	3	VENDOR	Let me browse your goods.	VENDOR	0
9879	0	TRAINER	Train me.	TRAINER	0
9879	1	VENDOR	Let me browse your goods.	VENDOR	0
9907	0	CHAT	Tell me about this proposal.	GOSSIP	9908
9908	0	CHAT	What happened then?	GOSSIP	9909
9909	0	CHAT	You want me to take part in the Hyldsmeet to end the war?	GOSSIP	9910
9910	0	CHAT	Very well.  I'll take part in this competition.	GOSSIP	9907
10115	0	TRAINER	Train me.	TRAINER	0
10116	0	TRAINER	Train me.	TRAINER	0
10122	0	VENDOR	I want to browse your goods.	VENDOR	0
10181	0	VENDOR	I want to browse your goods.	VENDOR	0
10188	0	VENDOR	I want to browse your goods.	VENDOR	0
10209	0	VENDOR	Let me browse your goods.	VENDOR	0
10265	0	CHAT	Auction House	GOSSIP	3101
10265	1	CHAT	The bank	GOSSIP	2322
10265	2	CHAT	Hippogryph Master	GOSSIP	10266
10265	3	CHAT	Guild Master	GOSSIP	2324
10265	4	CHAT	The inn	GOSSIP	2325
10265	5	CHAT	Mailbox	GOSSIP	2326
10265	6	CHAT	Stable Master	GOSSIP	4921
10265	7	CHAT	Weapons Trainer	GOSSIP	3722
10265	8	CHAT	Battlemaster	GOSSIP	8221
10265	9	CHAT	Class Trainer	GOSSIP	2343
10265	10	CHAT	Profession Trainer	GOSSIP	2351
10311	0	VENDOR	I want to browse your goods	VENDOR	0
7058	2	CHAT	I am 100% confident that I wish to learn in the ways of gnomish engineering.	GOSSIP	-1
10351	0	TRAINER	Train me.	TRAINER	0
10351	1	VENDOR	Let me browse your goods.	VENDOR	0
10359	0	TRAINER	Train me.	TRAINER	0
10359	1	VENDOR	Let me browse your goods.	VENDOR	0
10360	0	TRAINER	Train me.	TRAINER	0
10360	1	VENDOR	Let me browse your goods.	VENDOR	0
10361	0	TRAINER	Train me.	TRAINER	0
10361	1	VENDOR	Let me browse your goods.	VENDOR	0
10362	0	TRAINER	Train me.	TRAINER	0
10362	1	VENDOR	Let me browse your goods.	VENDOR	0
10363	0	TRAINER	Train me.	TRAINER	0
10363	1	VENDOR	Let me browse your goods.	VENDOR	0
10364	0	TRAINER	Train me.	TRAINER	0
10364	1	VENDOR	Let me browse your goods.	VENDOR	0
10365	0	TRAINER	Train me.	TRAINER	0
10365	1	VENDOR	Let me browse your goods.	VENDOR	0
10392	0	VENDOR	I want to browse your goods.	VENDOR	0
10392	1	TABARD	I want to create a guild crest.	TABARDDESIGNER	0
10482	0	CHAT	Tharnariun, the trap is lost. Do you have another?	GOSSIP	-1
10526	0	VENDOR	Let me browse your goods.	VENDOR	0
10604	0	CHAT	I'd like a pair of Synthebrew Goggles.	GOSSIP	-1
10604	1	CHAT	What did you say earlier?	GOSSIP	9006
10723	0	TRAINER	I seek training to ride a steed.	TRAINER	0
11361	0	VENDOR	Let me browse your goods.	VENDOR	0
11573	0	VENDOR	I want to browse your goods.	VENDOR	0
11743	0	VENDOR	I want to browse your goods.	VENDOR	0
11778	1	VENDOR	Show me what you have for sale.	VENDOR	0
12056	0	VENDOR	I want to browse your goods.	VENDOR	0
12237	0	TAXI	I need a ride.	TAXIVENDOR	0
12449	0	VENDOR	I want to browse your goods.	VENDOR	0
12726	0	VENDOR	I want to browse your goods.	VENDOR	0
15000	0	CHAT	I am a treasure hunter in search of powerful artifacts. Give them to me and you will not be harmed.	GOSSIP	0
15000	1	CHAT	How did you know? I mean, yes... Yes I am looking for that shard. Do you have it?	GOSSIP	15001
15001	0	CHAT	Alright. Where?	GOSSIP	15002
15002	0	CHAT	By Bronzbeard's... um, beard! What are you talking about?	GOSSIP	15003
15003	0	CHAT	Fish? You gave a piece of what could be the key to saving all life on Kalimdor to a fish?	GOSSIP	15004
15004	0	CHAT	A minnow? The oceans are filled with minnows! There could be a hundred million minnows out there!	GOSSIP	15005
15005	0	CHAT	...	GOSSIP	15006
15006	0	CHAT	You put the piece on a minnow and placed the minnow somewhere in the waters of the sea between here and the Eastern Kingdoms? And this minnow has special powers?	GOSSIP	15007
15007	0	CHAT	You're insane.	GOSSIP	15008
15008	0	CHAT	I'm all ears.	GOSSIP	15009
15009	0	CHAT	Come again.	GOSSIP	15010
15010	0	CHAT	Ok, let me get this straight. You put the scepter shard entrusted to your Flight by Anachronos on a minnow of your own making and now you expect me to build an... an arcanite buoy or something... to force your minnow out of hiding? AND potentially incur the wrath of an Elemental Lord? Did I miss anything? Perhaps I am to do this without any clothes on, during a solar eclipse, on a leap year?	GOSSIP	15011
15011	0	CHAT	FINE! And how, dare I ask, am I supposed to acquire an arcanite buoy?	GOSSIP	15012
15012	0	CHAT	But...	GOSSIP	-1
15013	1	CHAT	How did you know? I mean, yes... Yes I am looking for that shard. Do you have it?	GOSSIP	15001
15014	0	CHAT	Do you mean you are a dragon?	GOSSIP	15015
15015	0	CHAT	Yes, please.	GOSSIP	15016
15016	0	CHAT	Tell me.	GOSSIP	15017
15017	0	CHAT	But Deathwing is gone now.	GOSSIP	15018
15018	0	CHAT	Continue...	GOSSIP	15019
15019	0	CHAT	Why don't you do it?	GOSSIP	15020
15020	0	CHAT	Unless?	GOSSIP	15021
15021	0	CHAT	What must I do?	GOSSIP	15022
15022	0	CHAT	Continue...	GOSSIP	15023
20005	1	CHAT	It is good to see the Burning Blade is taking over where the Shadow Council once failed.	GOSSIP	20006
20006	1	CHAT	So the Searing Blade is expendable?	GOSSIP	20007
20007	1	CHAT	If there is anything you would have of me...	GOSSIP	20008
20013	0	CHAT	Yes, please do.	UNLEARN_PET_SKILLS	0
20015	0	CHAT	My apologies, I did not realize that you could understand what I was saying. What is it you are doing out here?	GOSSIP	20016
20016	0	CHAT	Do you? Perhaps you should tell me what it is that is bothering you.	GOSSIP	20017
20017	0	CHAT	What deal?	GOSSIP	20018
20018	0	CHAT	So how did he break the deal?	GOSSIP	20019
20019	0	CHAT	Perhaps I can be of some assistance. I will make a deal with you, Satyr. I shall recover this unforged breastplate and slay the beast, Goraluk Anvilcrack. In exchange for this task, you will teach me how to create the breastplate.	GOSSIP	-1
24400	1	CHAT	Thank you, Omarion. You have taken a fatal blow for the team on this day.	GOSSIP	-1
24401	1	CHAT	Glacial Cloak.	GOSSIP	24401
24401	2	CHAT	Glacial Gloves.	GOSSIP	24401
24401	3	CHAT	Glacial Wrists.	GOSSIP	24401
24401	4	CHAT	Glacial Vest.	GOSSIP	24401
24401	5	CHAT	I need to go. Evil stirs. Die well, Omarion.	GOSSIP	-1
24402	1	CHAT	Icebane Bracers.	GOSSIP	24402
24402	2	CHAT	Icebane Gauntlets.	GOSSIP	24402
24402	3	CHAT	Icebane Breastplate.	GOSSIP	24402
24402	4	CHAT	I need to go. Evil stirs. Die well, Omarion.	GOSSIP	-1
24403	1	CHAT	Polar Bracers.	GOSSIP	24403
24403	2	CHAT	Polar Gloves.	GOSSIP	24403
24403	3	CHAT	Polar Tunic.	GOSSIP	24403
24403	4	CHAT	Icy Scale Bracers.	GOSSIP	24403
24403	5	CHAT	Icy Scale Gauntlets.	GOSSIP	24403
24403	6	CHAT	Icy Scale Breastplate.	GOSSIP	24403
24403	7	CHAT	I need to go. Evil stirs. Die well, Omarion.	GOSSIP	-1
24404	1	CHAT	I am a master leatherworker, Omarion.	GOSSIP	24403
24404	2	CHAT	I am a master blacksmith, Omarion.	GOSSIP	24402
24404	3	CHAT	I am a master tailor, Omarion.	GOSSIP	24401
24404	4	CHAT	Omarion, I am not a craftsman. Can you still help me?	GOSSIP	24400
50151	0	CHAT	Please unlock the courtyard door.	GOSSIP	0
50260	0	CHAT	What roles?	GOSSIP	50304
50304	0	CHAT	Dreams?	GOSSIP	50305
50305	0	CHAT	I pray for such things.	GOSSIP	50306
50306	0	CHAT	I do not deserve such praise, Warlord Goretooth.	GOSSIP	50307
50307	0	CHAT	Sir! Until my body ceases to function!	GOSSIP	50308
50308	0	CHAT	Yes, sir. Thank you, sir!	GOSSIP	-1
6799	0	CHAT	 Decipher the pattern and learn its content.	GOSSIP	-1
4509	0	TRAINER	I require warrior training.	TRAINER	0
4509	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4511	0	TRAINER	I require warrior training.	TRAINER	0
4511	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4548	0	TRAINER	I require warrior training.	TRAINER	0
4548	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4546	0	TRAINER	I require warrior training.	TRAINER	0
4546	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4547	0	TRAINER	I require warrior training.	TRAINER	0
4547	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
50199	0	TRAINER	Can you train me how to use rogue skills?	TRAINER	0
50199	4	CHAT	<Take the letter>	GOSSIP	-1
50199	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4542	0	TRAINER	an you train me how to use rogue skills?	TRAINER	0
4542	4	CHAT	<Take the letter>	GOSSIP	-1
4542	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4540	0	TRAINER	an you train me how to use rogue skills?	TRAINER	0
4540	4	CHAT	<Take the letter>	GOSSIP	-1
4540	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4541	0	TRAINER	an you train me how to use rogue skills?	TRAINER	0
4541	4	CHAT	<Take the letter>	GOSSIP	-1
4541	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
3645	0	TRAINER	I seek more training in the priestly ways.	TRAINER	0
3645	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4545	1	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4545	2	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4543	1	TRAINER	I seek more training in the priestly ways.	TRAINER	0
4543	2	CHAT	I wish to unlearn my talents.	GOSSIP	4461
4515	0	TRAINER	Teach me the ways of the spirits.	TRAINER	0
4515	1	CHAT	I wish to unlearn my talents.	GOSSIP	4461
2060	0	CHAT	So what did you do?	GOSSIP	2059
2059	0	CHAT	Start making sense, dwarf. I don't want to have anything to do with your cracker, your pappy, or any sort of 'discreditin.'	GOSSIP	2058
2058	0	CHAT	Ironfoe?	GOSSIP	2057
2057	0	CHAT	Interesting... continue, John.	GOSSIP	2056
2056	0	CHAT	So that's how Windsor died...	GOSSIP	2055
2055	0	CHAT	So how did he die?	GOSSIP	2054
2054	0	CHAT	Ok, so where the hell is he? Wait a minute! Are you drunk?	GOSSIP	2053
2053	0	CHAT	WHY is he in Blackrock Depths?	GOSSIP	2052
2052	0	CHAT	300? So the Dark Irons killed him and dragged him into the Depths?	GOSSIP	2051
2051	0	CHAT	Ahhh... Ironfoe.	GOSSIP	2050
2050	0	CHAT	Thanks, Ragged John. Your story was very uplifting and informative. 	GOSSIP	-1
1822	1	CHAT	All is not lost, Kharan!	GOSSIP	1828
1830	0	CHAT	Gor'shak is my friend, you can trust me.	GOSSIP	1829
1829	0	CHAT	Not enough, you need to tell me more.	GOSSIP	1828
1828	0	CHAT	So what happened?	GOSSIP	1827
1827	0	CHAT	Continue...	GOSSIP	1826
1826	0	CHAT	So you suspect that someone on the inside was involved? They were tipped off?	GOSSIP	1825
1825	0	CHAT	Continue with your story please.	GOSSIP	1824
1824	0	CHAT	Indeed.	GOSSIP	1823
1823	0	CHAT	The door is open, Kharan. You are a free man.	GOSSIP	-1
1053	0	CHAT	Continue...	GOSSIP	1054
2871	0	CHAT	I inspect the body further.	GOSSIP	2872
6535	0	CHAT	Smear the ash on my face like war paint!	GOSSIP	-1
6537	0	VENDOR	I want to buy another stink bomb!	VENDOR	0
56000	0	CHAT	Dreadlords?  Perhaps you mean Lord Banehollow.  He sends his regards, and has a message for you...	GOSSIP	56001
56001	0	CHAT	No, Ulathek.  He knows your secret.  He knows you plot with Lord Hel'nurath of Xoroth.	GOSSIP	56002
56002	0	CHAT	It's no lie, traitor.  Banehollow wants your heart, and I'm going to get it for him.	GOSSIP	0
5731	0	CHAT	Call me \\"Boss\\".  What have you got for me!	GOSSIP	5730
5733	0	CHAT	Yeah, you're a real brainiac.  Just how smart do you think you are, Slip'kik?	GOSSIP	5732
5735	0	CHAT	So, now that I'm the king... what have you got for me?!	GOSSIP	5734
5847	0	CHAT	You've got my attention.	GOSSIP	5846
5846	0	CHAT	Give me the contract.	GOSSIP	-1
2184	3	CHAT	I lost my Crystal Pylon User's Manual and need another one.	GOSSIP	2205
0	16	CHAT	GOSSIP_OPTION_BOT	BOT	0
6088	1	CHAT	I'd like to stable my pet here	STABLEPET	0
56003	0	CHAT	What does Dadanga like to eat?	GOSSIP	56004
3651	0	CHAT	May I have another Dawn's Gambit, Betina?  I want to test it again...	GOSSIP	-1
3651	1	CHAT	Betina, I'd like a replacement Seal of the Dawn please!	GOSSIP	-1
3651	2	CHAT	Betina, I'd like a replacement Rune of the Dawn please!	GOSSIP	-1
1628	0	CHAT	I have lost my Goblin Transponder. I need another one.	GOSSIP	-1
5667	2	CHAT	Please teach me how to make a Gordok Ogre Suit!	GOSSIP	-1
5667	3	CHAT	Please teach me how to make a Gordok Ogre Suit!	GOSSIP	-1
5739	0	CHAT	Um, I'm taking some prisoners we found outside before the king for punishment.	GOSSIP	5738
5738	0	CHAT	Er... that's how I found them.  I wanted to show the king that they were a threat!  Say Captain... I overheard Guard Fengus calling you a fat, useless gnoll lover!	GOSSIP	-1
5747	0	CHAT	Fascinating, Lorekeeper. Continue please.	GOSSIP	50004
50004	0	CHAT	(Continue.)	GOSSIP	50005
50005	0	CHAT	(Continue.)	GOSSIP	50006
50006	0	CHAT	(Continue.)	GOSSIP	50007
50007	0	CHAT	Eh?	GOSSIP	50008
50008	0	CHAT	Maybe... What do I do now?	GOSSIP	-1
3670	0	CHAT	Of course, Warchief!	GOSSIP	-1
6658	0	CHAT	That would be wonderful! Thank you, Meridith.	GOSSIP	-1
50309	0	CHAT	Are you the Earthshaper capable of creating Elementium?	GOSSIP	50310
50310	0	CHAT	What do you know of it, Franzahl?	GOSSIP	50311
50311	0	CHAT	A fissure?	GOSSIP	50312
50312	0	CHAT	So what happened?	GOSSIP	50313
50313	0	CHAT	Goodbye.	GOSSIP	-1
841	0	CHAT	Continue with your story.	GOSSIP	842
842	0	CHAT	Tragic...	GOSSIP	-1
880	0	CHAT	What could be worse than death?	GOSSIP	884
881	0	CHAT	I shall.	GOSSIP	-1
882	0	CHAT	You can count on me, Hero.	GOSSIP	881
883	0	CHAT	What are the stones of binding?	GOSSIP	882
884	0	CHAT	Subordinates?	GOSSIP	883
2061	1	CHAT	Milk me, John.	GOSSIP	2062
2062	0	CHAT	Do it... Do it now.	GOSSIP	-1
1290	0	CHAT	Trick or Treat!	GOSSIP	0
344	0	CHAT	Trick or Treat!	GOSSIP	0
345	0	CHAT	Trick or Treat!	GOSSIP	0
349	0	CHAT	Trick or Treat!	GOSSIP	0
6525	0	CHAT	Trick or Treat!	GOSSIP	0
1294	0	CHAT	Trick or Treat!	GOSSIP	0
342	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1290	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1581	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
344	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
345	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1296	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1293	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
347	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
349	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
6525	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
2890	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1294	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1291	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
1297	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
7173	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
6059	2	CHAT	Does that heart mean you're looking for love?	GOSSIP	7049
7049	3	CHAT	What can I do with these gifts?	GOSSIP	7057
7057	0	CHAT	You're selling cologne and perfume?	GOSSIP	7051
7057	1	CHAT	What are love tokens?	GOSSIP	7050
7050	1	CHAT	What can I do with these gifts?	GOSSIP	7057
7051	1	CHAT	What can I do with these gifts?	GOSSIP	7057
721	11	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
721	12	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12867	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
10265	11	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12866	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
2121	13	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12865	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12870	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12871	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
1951	14	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
1951	15	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12864	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
435	16	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
435	17	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
2849	14	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12861	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12862	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12850	0	VENDOR	I want to browse your goods.	VENDOR	0
12850	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12851	0	VENDOR	I want to browse your goods.	VENDOR	0
12851	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12852	0	VENDOR	I want to browse your goods.	VENDOR	0
12852	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12853	0	VENDOR	I want to browse your goods.	VENDOR	0
12853	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12854	0	VENDOR	I want to browse your goods.	VENDOR	0
12854	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12855	0	VENDOR	I want to browse your goods.	VENDOR	0
12855	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
681	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
682	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
685	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
686	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
691	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
692	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
693	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
694	0	VENDOR	I want to browse your goods.	VENDOR	0
694	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
697	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
698	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
688	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
689	0	VENDOR	I want to browse your goods.	VENDOR	0
689	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12856	0	VENDOR	I want to browse your goods.	VENDOR	0
12856	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12857	0	VENDOR	I want to browse your goods.	VENDOR	0
12857	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12858	0	VENDOR	I want to browse your goods.	VENDOR	0
12858	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12859	0	VENDOR	I want to browse your goods.	VENDOR	0
12859	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12868	0	VENDOR	I want to browse your goods.	VENDOR	0
12868	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12869	0	VENDOR	I want to browse your goods.	VENDOR	0
12869	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12863	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12872	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12873	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12874	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
12875	1	CHAT	Here, I'd like to give you this token of my love.	GOSSIP	0
592	0	CHAT	Can you give me directions?	GOSSIP	591
5848	1	CHAT	Well what do you know, this is Children's Week!  What can I do to help?	GOSSIP	60001
7104	0	CHAT	Hello, Rayne. What brings the Cenarion Circle to the Plaguelands?	GOSSIP	7123
7123	0	CHAT	Are these lands not beyond healing? They look pretty beat up.	GOSSIP	7124
7124	0	CHAT	What kind of services?	GOSSIP	7125
7102	0	CHAT	What is Cryptstalker armor?	GOSSIP	7110
7110	0	CHAT	Continue please.	GOSSIP	7111
7101	0	CHAT	What is it that you do exactly, Rohan?	GOSSIP	7118
7118	0	CHAT	So what brings you to Light's Hope?	GOSSIP	7119
7119	0	CHAT	What? Bonescythe?	GOSSIP	7120
7120	0	CHAT	Wow, you're insane, aren't you?	GOSSIP	7121
7121	0	CHAT	Hey wait, Gadgetzan has a disco?	GOSSIP	7122
7099	0	CHAT	What is Dreadnaught armor?	GOSSIP	7106
7106	0	CHAT	Continue please.	GOSSIP	7107
7107	0	CHAT	Anything else?	GOSSIP	7108
1970	0	CHAT	Your family says hello, Ribbly.  And they want your head!	GOSSIP	-1
7283	0	CHAT	Curse? What's going on here, Fairbanks?	GOSSIP	7282
4826	0	TRAINER	Please teach me.	TRAINER	0
4825	0	TRAINER	Please teach me.	TRAINER	0
4824	0	TRAINER	Please teach me.	TRAINER	0
4823	0	TRAINER	Please teach me.	TRAINER	0
4822	0	TRAINER	Please teach me.	TRAINER	0
7223	0	CHAT	You said you would have it back. What does that mean?	GOSSIP	7222
7226	0	CHAT	I still do not understand.	GOSSIP	7225
7227	0	CHAT	Why have you done such horrible things?	GOSSIP	7226
7228	1	CHAT	What is it Tarsis? I don't know what to do!	GOSSIP	0
7228	0	CHAT	What are you talking about, mage?	GOSSIP	7227
4821	0	TRAINER	Please teach me.	TRAINER	0
2207	0	CHAT	I need a Cenarion beacon.	GOSSIP	-1
7058	3	CHAT	I am 100% confident that I wish to learn in the ways of goblin engineering.	GOSSIP	-1
2703	2	CHAT	I lost the Cache of Mau'ari. What can I do?	GOSSIP	-1
7282	0	CHAT	Mograine?	GOSSIP	7281
7281	0	CHAT	What do you mean?	GOSSIP	7280
7280	0	CHAT	I still do not fully understand.	GOSSIP	7279
7279	0	CHAT	Incredible story. So how did he die?	GOSSIP	7278
7278	0	CHAT	You mean...	GOSSIP	7277
7277	0	CHAT	How do you know all of this?	GOSSIP	7276
7276	0	CHAT	A thousand? For one man?	GOSSIP	7275
7275	0	CHAT	Yet? Yet what??	GOSSIP	7274
7274	0	CHAT	And did he?	GOSSIP	7273
7273	0	CHAT	Continue please, Fairbanks.	GOSSIP	7272
7272	0	CHAT	You mean...	GOSSIP	7271
7271	0	CHAT	You were right, Fairbanks. That is tragic.	GOSSIP	7270
7270	0	CHAT	And you did...	GOSSIP	7269
7269	0	CHAT	You tell an incredible tale, Fairbanks. What of the blade? Is it beyond redemption?	GOSSIP	7268
7268	0	CHAT	But his son is dead.	GOSSIP	7284
1470	0	CHAT	Yes.  Give me the spell to summon the avatar.	GOSSIP	-1
524	1	CHAT	Press the red button labeled 'E.C.A.C.'	GOSSIP	-1
2207	1	CHAT	What plants are in Felwood that might be corrupted?	GOSSIP	2361
4827	0	TRAINER	Please teach me.	TRAINER	0
6678	0	CHAT	What is the Ahn'Qiraj war effort?	GOSSIP	6759
6678	1	CHAT	How many metal bars have the Alliance collected so far?	GOSSIP	6679
6678	2	CHAT	How many herbs have the Alliance collected so far?	GOSSIP	6680
6678	3	CHAT	How many leather skins have the Alliance collected so far?	GOSSIP	6681
6678	4	CHAT	How many bandages have the Alliance collected so far?	GOSSIP	6682
6678	5	CHAT	How many cooked goods have the Alliance collected so far?	GOSSIP	6683
6679	0	CHAT	I want to ask you about something else.	GOSSIP	6678
6680	0	CHAT	I want to ask you about something else.	GOSSIP	6678
6681	0	CHAT	I want to ask you about something else.	GOSSIP	6678
6682	0	CHAT	I want to ask you about something else.	GOSSIP	6678
6683	0	CHAT	I want to ask you about something else.	GOSSIP	6678
6759	0	CHAT	I want to ask you about something else.	GOSSIP	6678
6778	0	CHAT	What is the Ahn'Qiraj war effort?	GOSSIP	6779
6778	1	CHAT	How many metal bars have the Horde collected so far?	GOSSIP	6780
6778	2	CHAT	How many herbs have the Horde collected so far?	GOSSIP	6781
6778	3	CHAT	How many leather skins have the Horde collected so far?	GOSSIP	6782
6778	4	CHAT	How many bandages have the Horde collected so far?	GOSSIP	6783
6778	5	CHAT	How many cooked goods have the Horde collected so far?	GOSSIP	6784
6779	0	CHAT	I want to ask you about something else.	GOSSIP	6778
6780	0	CHAT	I want to ask you about something else.	GOSSIP	6778
6781	0	CHAT	I want to ask you about something else.	GOSSIP	6778
6782	0	CHAT	I want to ask you about something else.	GOSSIP	6778
6783	0	CHAT	I want to ask you about something else.	GOSSIP	6778
6784	0	CHAT	I want to ask you about something else.	GOSSIP	6778
7233	0	CHAT	So what has led you to Naxxramas?	GOSSIP	7232
7232	0	CHAT	So Kel'Thuzad holds all of the pieces?	GOSSIP	7231
7166	0	CHAT	Use 8 necrotic runes and disrupt his ritual.	GOSSIP	-1
7164	0	CHAT	What's happening?	GOSSIP	7193
7164	1	CHAT	What can I do?	GOSSIP	7203
7164	2	CHAT	Where are we battling the Scourge?	GOSSIP	7254
7164	3	CHAT	How many battles have we won?	GOSSIP	7246
7193	0	CHAT	I have another question.	GOSSIP	7164
7199	0	CHAT	Where else are we battling the Scourge?	GOSSIP	7254
7199	1	CHAT	I have another question.	GOSSIP	7164
7200	0	CHAT	Where else are we battling the Scourge?	GOSSIP	7254
7200	1	CHAT	I have another question.	GOSSIP	7164
7201	0	CHAT	Where else are we battling the Scourge?	GOSSIP	7254
7201	1	CHAT	I have another question.	GOSSIP	7164
7202	0	CHAT	Where else are we battling the Scourge?	GOSSIP	7254
7202	1	CHAT	I have another question.	GOSSIP	7164
7203	0	CHAT	I have another question.	GOSSIP	7164
7246	0	CHAT	I have another question.	GOSSIP	7164
7254	0	CHAT	Is Azshara currently under attack?	GOSSIP	7266
7254	1	CHAT	Are the Blasted Lands currently under attack?	GOSSIP	7201
7254	2	CHAT	Are the Burning Steppes currently under attack?	GOSSIP	7202
7254	3	CHAT	Are the Eastern Plaguelands currently under attack?	GOSSIP	7267
7254	4	CHAT	Is Tanaris currently under attack?	GOSSIP	7200
7254	5	CHAT	Is Winterspring currently under attack?	GOSSIP	7199
7254	6	CHAT	I have another question.	GOSSIP	7164
7266	0	CHAT	Where else are we battling the Scourge?	GOSSIP	7254
7266	1	CHAT	I have another question.	GOSSIP	7164
7267	0	CHAT	Where else are we battling the Scourge?	GOSSIP	7254
7267	1	CHAT	I have another question.	GOSSIP	7164
6141	1	VENDOR	What goods have I earned the right to purchase for use in Warsong Gulch?	VENDOR	0
6142	1	VENDOR	What goods have I earned the right to purchase for use in Warsong Gulch?	VENDOR	0
1202	0	CHAT	Another way? Do tell...	GOSSIP	1203
1203	0	CHAT	Orcs? Badlands? I'm invulnerable!	GOSSIP	1204
1204	0	CHAT	Absolutely!	GOSSIP	1205
1205	0	CHAT	My apologies, Pebblebitty.	GOSSIP	1206
1206	0	CHAT	Done, done, and done.	GOSSIP	-1
50238	0	CHAT	Ragefire	GOSSIP	50237
50238	1	CHAT	Deadmines	GOSSIP	50200
50238	2	CHAT	Wailing Caverns	GOSSIP	50202
50238	3	CHAT	Shadowfang Keep	GOSSIP	50204
50238	4	CHAT	Blackfathom Deeps	GOSSIP	50206
50238	5	CHAT	Stormwind Stockade	GOSSIP	50208
50238	6	CHAT	Razorfen Kraul	GOSSIP	50210
50238	7	CHAT	Gnomeregan	GOSSIP	50212
50238	8	CHAT	Scarlet Monastery	GOSSIP	50214
50238	9	CHAT	Razorfen Downs	GOSSIP	50216
50238	10	CHAT	Maraudon	GOSSIP	50218
50238	11	CHAT	Uldaman	GOSSIP	50220
50238	12	CHAT	Zul'Farrak	GOSSIP	50222
50238	13	CHAT	Blackrock Depths	GOSSIP	50224
50238	14	CHAT	Sunken Temple	GOSSIP	50226
50238	15	CHAT	Blackrock Spire	GOSSIP	50228
50238	16	CHAT	Dire Maul	GOSSIP	50230
50238	17	CHAT	Stratholme	GOSSIP	50232
50238	18	CHAT	Scholomance	GOSSIP	50234
50237	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50237	1	CHAT	Can you tell me more about this place?	GOSSIP	50236
50200	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50200	1	CHAT	Can you tell me more about this place?	GOSSIP	50201
50202	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50202	1	CHAT	Can you tell me more about this place?	GOSSIP	50203
50204	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50204	1	CHAT	Can you tell me more about this place?	GOSSIP	50205
50206	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50206	1	CHAT	Can you tell me more about this place?	GOSSIP	50207
50208	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50208	1	CHAT	Can you tell me more about this place?	GOSSIP	50209
50210	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50210	1	CHAT	Can you tell me more about this place?	GOSSIP	50211
50212	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50212	1	CHAT	Can you tell me more about this place?	GOSSIP	50213
50214	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50214	1	CHAT	Can you tell me more about this place?	GOSSIP	50215
50216	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50216	1	CHAT	Can you tell me more about this place?	GOSSIP	50217
50218	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50218	1	CHAT	Can you tell me more about this place?	GOSSIP	50219
50220	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50220	1	CHAT	Can you tell me more about this place?	GOSSIP	50221
50222	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50222	1	CHAT	Can you tell me more about this place?	GOSSIP	50223
50224	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50224	1	CHAT	Can you tell me more about this place?	GOSSIP	50225
50226	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50226	1	CHAT	Can you tell me more about this place?	GOSSIP	50227
50228	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50228	1	CHAT	Can you tell me more about this place?	GOSSIP	50229
50230	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50230	1	CHAT	Can you tell me more about this place?	GOSSIP	50231
50232	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50232	1	CHAT	Can you tell me more about this place?	GOSSIP	50233
50234	0	INTERACT_2	Join a group going to this dungeon.    <This choice will place you in a meetingstone queue>    	GOSSIP	-1
50234	1	CHAT	Can you tell me more about this place?	GOSSIP	50235
342	4	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
344	4	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
345	4	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
347	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
349	4	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1290	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1291	6	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1293	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1294	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1296	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1297	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1581	4	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
2890	6	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
6059	5	CHAT	Tell me about dungeons I could explore.	GOSSIP	50238
1802	0	CHAT	Can you tell me how I can get a Videre Elixir?	GOSSIP	1801
1802	1	VENDOR	Buy somethin', will ya?	VENDOR	0
6687	0	CHAT	Reporting for duty, sir.	GOSSIP	6686
6686	0	CHAT	I'm ready!	GOSSIP	-1
6623	0	CHAT	I'm here to aid the Captain.	GOSSIP	6622
6622	0	CHAT	I'll wait.	GOSSIP	-1
7336	0	CHAT	I require flagging.	GOSSIP	-1
7336	1	CHAT	I require a teleport to Naxxramas.	GOSSIP	-1
\.
